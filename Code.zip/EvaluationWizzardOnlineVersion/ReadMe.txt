Built under Windows 7 with Visual Studio 2012, tested on a GTX 1080 Ti machine.
Execute from within the bin directory.
The surface geometry is needed in obj. format
The scripts for generating the online evaluation are stored in the "Webpage" folder
#!/usr/bin/env python
import numpy as np
import matplotlib.pyplot as plt
import os

scriptpath = os.path.realpath(__file__)
path = scriptpath.replace('automaticcharts.py','')
print(path)
# Take a peek at how many vis methods were tested, and how many tasks were performed in total.
gtdata = np.loadtxt(path+'groundtruth.csv', delimiter=',')
nvismethods = gtdata[0].astype(np.int)
mtasks = gtdata[1].astype(np.int)
n_combinations = nvismethods*4

# The rest of this file will have the correct answers
answers = np.delete(gtdata,0)
answers = np.delete(answers, 0)

# Let's see what we can learn from the metadata
metadatacolumns = np.arange(0,5)
metadata = np.genfromtxt(path+'results.csv', delimiter=',', dtype='str', usecols = metadatacolumns)
backgrounds = list(metadata[:,0])
occurances = {}
for word in backgrounds:
    if word in occurances.keys():
        occurances[word] = occurances[word]+1
    else:
        occurances[word] = 1
experienced = np.count_nonzero(metadata[:,1] == 'yes')
male = np.count_nonzero(metadata[:,4] == 'male')
female = np.count_nonzero(metadata[:,4] == 'female')
color = np.count_nonzero(metadata[:,2] == 'yes')
ages = metadata[:,3].astype(np.int)

# # Output textual report to Output.txt file
text_file = open(path+'MetaInformation.txt', "w")
text_file.write('This evaluation tested '+str(nvismethods)+' visualization methods. Each participant had to perform a total of '+str(mtasks)+' tasks.\n')
text_file.write('There were a total of '+str(len(backgrounds))+' participants ('+str(female)+' female,'+str(male)+' male, age range from '+str(np.min(ages))+' to '+str(np.max(ages))+').\n')
text_file.write('Their backgrounds were in: ')
count = 0
for o in occurances:
    if count == (len(occurances)-1):
        text_file.write('and '+str(o) + ' (' + str(occurances[o]) + ').\n')
    else:
        count += 1
        text_file.write(str(o) + ' (' + str(occurances[o]) + '), ')
text_file.write(str(experienced)+' participants stated they had experience in vessel visualization.\n')
text_file.write(str(color)+' participants reported color vision deficiencies.\n')
text_file.close()

# Uncomment below if you would rather see a console print
# print('There were', nvismethods, 'visualization methods tested, each participant had to perform a total of',mtasks, 'tasks.')
# print('There were a total of',len(backgrounds), 'participants (',female,' female,', male,'male, age range from',np.min(ages),'to',np.max(ages),').')
# print(experienced,'participants stated they had experience in vessel visualization.')
# print(color,'participants reported color vision deficiencies.')

# since the first 5 colums are metadata, and the last is reserved for comments, the numerical values are in here:
resultcolumns = np.arange(5,mtasks*3+5)
# slurp the numerical csv data files into numpy, and skip the metadata
data = np.loadtxt(path+'results.csv', delimiter=',', usecols = resultcolumns)

#now for the chart generation
width = 0.2       # the width of the bars, can adjust if unsatisfactory
ind = np.arange(nvismethods) # number of methods tested determine the x-tick locations
titles = ['Correctness Ratio by Visualization Method and Category','Confidence by Visualization Method and Category', 'Time by Visualization Method and Category']
captions = ['Correctness','Confidence','Time']
colors = ['#ffc8ad','#63d6b9','#bccdff','#ffc2ff']
filenames = ['1_correctness.png','2_confidence.png','3_time.png']
legend = ('NF', 'FF', 'NN', 'FN')
xticklabs = []
for x in range(1,nvismethods+1):
    xticklabs.append('Method '+str(x))


for i in range(3): # we want to make 3 charts: correctness, confidence, and time
    fig, ax = plt.subplots(figsize=(6, 6))
    rects = []
    currentdata = data[:, i::3]
    means = np.empty([nvismethods, 4])
    sems = np.empty([nvismethods, 4])
    for n in range(nvismethods): # for every vis method tested
        methodn = currentdata[:, n::nvismethods]  # get answers for specific method
        for m in range(4): # for the 4 scene types: NF FF NN FN
            condition = methodn[:,m::4]
            if i == 0: # we want to check correctness ratio in this case, rather than M and SEM
                # check against ground truth
                correctdata = np.tile(answers[4+n::4*nvismethods], (np.size(condition,0), 1))
                check = condition == correctdata
                cdata = check.astype(np.int)
                means[n, m] = np.count_nonzero(cdata)/cdata.size
                sems[n, m] = np.std(cdata) / np.sqrt(mtasks)
            else:
                means[n,m]= np.average(condition)
                sems[n,m] = np.std(condition)/np.sqrt(mtasks)
    # now that the calculations are done for this current measure, let's create the bars
    for j in range(4):
        rect = ax.bar(ind+j*width, means[:,j], width, color=colors[j], yerr=sems[:,j], edgecolor='black')
        rects.append(rect)

    # add some relevant captions too
    ax.set_ylabel(captions[i])
    ax.set_title(titles[i])
    ax.set_xticks(ind + 1.5 * width)
    ax.set_xticklabels(xticklabs)
    ax.legend((rects[0][0], rects[1][0], rects[2][0], rects[3][0]), ('NF', 'FF', 'NN', 'FN'))

    # save our chart as a .png
    plt.savefig(path+filenames[i])

# uncomment if you would like to adjust the figure size outside of the system interface
# plt.show()

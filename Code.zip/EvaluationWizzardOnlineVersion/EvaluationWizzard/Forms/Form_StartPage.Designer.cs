﻿namespace EvaluationWizzard
{
    partial class Form_StartPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_StartPage));
            this.Pnl_StartPage = new System.Windows.Forms.Panel();
            this.TlStrp_StartPage = new System.Windows.Forms.ToolStrip();
            this.ToolStripDropDown_Evaluation = new System.Windows.Forms.ToolStripDropDownButton();
            this.createNewEvaluation_ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadExistingEvaluationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripDropDown_Export = new System.Windows.Forms.ToolStripDropDownButton();
            this.Image_ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TlStrp_StartPage.SuspendLayout();
            this.SuspendLayout();
            // 
            // Pnl_StartPage
            // 
            this.Pnl_StartPage.BackColor = System.Drawing.SystemColors.ControlLight;
            this.Pnl_StartPage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Pnl_StartPage.Location = new System.Drawing.Point(0, 30);
            this.Pnl_StartPage.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Pnl_StartPage.Name = "Pnl_StartPage";
            this.Pnl_StartPage.Size = new System.Drawing.Size(1233, 706);
            this.Pnl_StartPage.TabIndex = 0;
            // 
            // TlStrp_StartPage
            // 
            this.TlStrp_StartPage.BackColor = System.Drawing.SystemColors.MenuBar;
            this.TlStrp_StartPage.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripDropDown_Evaluation,
            this.ToolStripDropDown_Export});
            this.TlStrp_StartPage.Location = new System.Drawing.Point(0, 0);
            this.TlStrp_StartPage.Name = "TlStrp_StartPage";
            this.TlStrp_StartPage.Padding = new System.Windows.Forms.Padding(0, 0, 2, 0);
            this.TlStrp_StartPage.Size = new System.Drawing.Size(1233, 30);
            this.TlStrp_StartPage.TabIndex = 1;
            this.TlStrp_StartPage.Text = "toolStrip1";
            // 
            // ToolStripDropDown_Evaluation
            // 
            this.ToolStripDropDown_Evaluation.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.ToolStripDropDown_Evaluation.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.createNewEvaluation_ToolStripMenuItem,
            this.loadExistingEvaluationToolStripMenuItem});
            this.ToolStripDropDown_Evaluation.Font = new System.Drawing.Font("Segoe UI", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ToolStripDropDown_Evaluation.Image = ((System.Drawing.Image)(resources.GetObject("ToolStripDropDown_Evaluation.Image")));
            this.ToolStripDropDown_Evaluation.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ToolStripDropDown_Evaluation.Name = "ToolStripDropDown_Evaluation";
            this.ToolStripDropDown_Evaluation.Size = new System.Drawing.Size(102, 27);
            this.ToolStripDropDown_Evaluation.Text = "Evaluation";
            // 
            // createNewEvaluation_ToolStripMenuItem
            // 
            this.createNewEvaluation_ToolStripMenuItem.Name = "createNewEvaluation_ToolStripMenuItem";
            this.createNewEvaluation_ToolStripMenuItem.Size = new System.Drawing.Size(264, 28);
            this.createNewEvaluation_ToolStripMenuItem.Text = "Create new evaluation";
            this.createNewEvaluation_ToolStripMenuItem.Click += new System.EventHandler(this.Create_New_EvaluationToolStripMenuItem_Click);
            // 
            // loadExistingEvaluationToolStripMenuItem
            // 
            this.loadExistingEvaluationToolStripMenuItem.Name = "loadExistingEvaluationToolStripMenuItem";
            this.loadExistingEvaluationToolStripMenuItem.Size = new System.Drawing.Size(264, 28);
            this.loadExistingEvaluationToolStripMenuItem.Text = "Load existing evaluation";
            this.loadExistingEvaluationToolStripMenuItem.Click += new System.EventHandler(this.Load_Existing_EvaluationToolStripMenuItem_Click);
            // 
            // ToolStripDropDown_Export
            // 
            this.ToolStripDropDown_Export.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.ToolStripDropDown_Export.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Image_ToolStripMenuItem});
            this.ToolStripDropDown_Export.Font = new System.Drawing.Font("Segoe UI", 12.75F);
            this.ToolStripDropDown_Export.Image = ((System.Drawing.Image)(resources.GetObject("ToolStripDropDown_Export.Image")));
            this.ToolStripDropDown_Export.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ToolStripDropDown_Export.Name = "ToolStripDropDown_Export";
            this.ToolStripDropDown_Export.Size = new System.Drawing.Size(72, 27);
            this.ToolStripDropDown_Export.Text = "Export";
            // 
            // Image_ToolStripMenuItem
            // 
            this.Image_ToolStripMenuItem.Name = "Image_ToolStripMenuItem";
            this.Image_ToolStripMenuItem.Size = new System.Drawing.Size(152, 28);
            this.Image_ToolStripMenuItem.Text = "Images";
            this.Image_ToolStripMenuItem.Click += new System.EventHandler(this.Image_ToolStripMenuItem_Click);
            // 
            // Form_StartPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1233, 736);
            this.Controls.Add(this.Pnl_StartPage);
            this.Controls.Add(this.TlStrp_StartPage);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form_StartPage";
            this.TlStrp_StartPage.ResumeLayout(false);
            this.TlStrp_StartPage.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel Pnl_StartPage;
        private System.Windows.Forms.ToolStrip TlStrp_StartPage;
        private System.Windows.Forms.ToolStripDropDownButton ToolStripDropDown_Evaluation;
        private System.Windows.Forms.ToolStripMenuItem createNewEvaluation_ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadExistingEvaluationToolStripMenuItem;
        private System.Windows.Forms.ToolStripDropDownButton ToolStripDropDown_Export;
        private System.Windows.Forms.ToolStripMenuItem Image_ToolStripMenuItem;
    }
}


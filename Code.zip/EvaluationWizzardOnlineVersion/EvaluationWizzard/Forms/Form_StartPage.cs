﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EvaluationWizzard
{
    public partial class Form_StartPage : Form
    {
        #region - Private Variables -

        private Control_NewEvaluation new_eval_control;

        private Control_LoadEvaluation load_eval_control;

        #endregion

        #region - Constructors -

        public Form_StartPage()
        {
            this.InitializeComponent();
        }

        #endregion

        #region - Properties -

        #endregion

        #region - Methods -

        #region - Load -

        private void Create_New_EvaluationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.load_eval_control != null)
            {
                this.Pnl_StartPage.Controls.Remove(this.load_eval_control);

                this.load_eval_control = null;
            }

            this.new_eval_control = new Control_NewEvaluation();

            this.new_eval_control.Dock = DockStyle.Fill;

            this.Pnl_StartPage.Controls.Add(this.new_eval_control);
        }

        private void Load_Existing_EvaluationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.new_eval_control != null)
            {
                this.Pnl_StartPage.Controls.Remove(this.new_eval_control);

                this.new_eval_control = null;
            }

            this.load_eval_control = new Control_LoadEvaluation();

            this.load_eval_control.Dock = DockStyle.Fill;

            this.Pnl_StartPage.Controls.Add(this.load_eval_control);
        }

        #endregion

        #region - Export

        private void Image_ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.new_eval_control.Export_Images();
        }

        #endregion

        #endregion
    }
}

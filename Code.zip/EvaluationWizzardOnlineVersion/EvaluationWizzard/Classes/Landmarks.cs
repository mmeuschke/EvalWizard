﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenTK;
using OpenTK.Graphics.OpenGL;
using EvaluationWizzard.Properties;
using System.Drawing;

namespace EvaluationWizzard
{
    public class Landmarks : RenderItem
    {
        #region - Private Variables -

        private List<Vector3> act_positions;

        private List<Vector3> act_normals;

        private List<float> pair_distances; // pairwise distance between landmarks

        private List<Point> pair_index_list; // indices of landmark pairs

        private List<int> pair_indices; // index list with an unambiguous index per pair

        private List<float> sorted_distances; // pairwise distance between landmarks

        private List<int> sorted_pair_indices; // index permutation of sorting

        private float max_dist_quartile; // quartile for used maximum distance --set to 80 % of maximum occurring distance
        private float min_dist_quartile; // quartile for used minimum distance --set to 5 % of maximum occurring distance
         
        private float max_dist; // distance threshold used for conditional viewpoint calculation (set to the value of max_dist_quarile as quartile value of sorted_distances)
        private float min_dist; // distance threshold used for viewpoint calculation (set to the value of min_dist_quartile as quartile value of sorted_distances)
        private float half_dist;
        private float square_dist;

        private int start_index; // neglect the 5% closest pairs 
        private int start_index_half_dist;
        private int start_index_square_dist;

        private int counter; // act landmark pair

        private Matrix4 inital_transformation_xyplane;

        private Matrix4 condition_transformation;

        private Matrix4 rotation_transformation;

        private Matrix4 bounding_box_transformation;

        private Point act_pair; // indices of currently considered landmark pair 

        private enum VBONames { Pos, Norm};

        private int number_vbo = Enum.GetNames(typeof(VBONames)).Length;

        #endregion

        #region - Constructors -

        public Landmarks(List<Vector3> Vertices, List<Vector3> Normals)
            : base( Settings.Default.LandmarksName)
        {
            this.positions = Vertices;

            this.normals = Normals;

            this.act_positions = new List<Vector3>();

            this.act_normals = new List<Vector3>();

            this.pair_distances = new List<float>();

            this.pair_index_list = new List<Point>();

            this.pair_indices = new List<int>();

            this.sorted_distances = new List<float>();

            this.sorted_pair_indices = new List<int>();

            this.min_dist_quartile = 0.05f;
            this.max_dist_quartile = 0.9f;

            this.max_dist = 0;
            this.min_dist = 0;
            this.half_dist = 0;
            this.square_dist = 0;

            this.start_index = 0;
            this.start_index_half_dist = 0;
            this.start_index_square_dist = 0;

            this.counter = 0;

            this.inital_transformation_xyplane = Matrix4.Identity;

            this.condition_transformation = Matrix4.Identity;

            this.rotation_transformation = Matrix4.Identity;

            this.bounding_box_transformation = Matrix4.Identity;

            this.act_pair = new Point(0,0);

            this.Sort_Landmarks();

            this.Set_Initial_Pair();

            this.vao = new uint[1];

            this.vbo = new uint[this.number_vbo];
        }

        #endregion

        #region - Properties -

        public Matrix4 Transformation_XYPlane
        {
            get { return this.inital_transformation_xyplane; }
            set { this.inital_transformation_xyplane = value; }
        }

        public Matrix4 Transformation_Condition
        {
            get { return this.condition_transformation; }
            set { this.condition_transformation = value; }
        }

        public Matrix4 Transformation_Rotation
        {
            get { return this.rotation_transformation; }
            set { this.rotation_transformation = value; }
        }

        public Matrix4 TransformationBounding_Box
        {
            get { return this.bounding_box_transformation; }
            set { this.bounding_box_transformation = value; }
        }

        public int Pair_Counter
        {
            get { return this.counter; }
            set { this.counter = value; }
        }

        public float Max_Dist
        {
            get { return this.max_dist; }
            set { this.max_dist = value; }
        }

        public int Start_Index
        {
            get { return this.start_index; }
            set { this.start_index = value; }
        }

        public int Number_Pairs
        {
            get { return this.sorted_pair_indices.Count; }
        }

        public Vector3 P2
        {
            get { return this.act_positions[1]; }
        }

        public Point Act_Pair
        {
            get { return this.act_pair; }
        }

        public int Start_Index_Half_Dist
        {
            get { return this.start_index_half_dist; }
        }

        public int Start_Index_Square_Dist
        {
            get { return this.start_index_square_dist; }
        }

        #endregion

        #region - Methods -

        #region - Init Landmarks -

        /// <summary>
        /// Start sorting of landmark pairs
        /// </summary>
        private void Sort_Landmarks()
        {
            this.Calculate_Pair_Distances(out this.pair_distances, out this.pair_indices, out this.pair_index_list);

            this.Sort_End_Points(this.pair_distances, this.pair_indices, out this.sorted_distances, out this.sorted_pair_indices);
        }

        /// <summary>
        /// Calcualates Euclidean distance for each landmark pair
        /// </summary>
        private void Calculate_Pair_Distances(out List<float> pair_distances, out List<int> pair_indices, out List<Point> pair_index_list)
        {
            pair_distances = new List<float>();
            pair_indices = new List<int>();
            pair_index_list = new List<Point>();

            float dist;
            int counter = 0;

            for (int i = 0; i < this.positions.Count; i++)
            {
                for (int j = 0; j < this.positions.Count; j++)
                {
                    if ((i != j) && (j > i)) // upper triangular matrix
                    {
                        dist = Math.Abs((this.positions[i] - this.positions[j]).Length);

                        pair_distances.Add(dist);

                        pair_indices.Add(counter);

                        pair_index_list.Add(new Point(i, j));

                        counter++;
                    }
                }
            }
        }

        /// <summary>
        /// Sorts landmark pairs according to their Euclidean distance in ascending order
        /// </summary>
        private void Sort_End_Points(List<float> distances, List<int> pair_indices, out List<float> sorted_distances, out List<int> sorted_pair_indices)
        {
            sorted_distances = new List<float>();
            sorted_pair_indices = new List<int>();

            int N = distances.Count;

            int[] index = Enumerable.Range(0, N).ToArray<int>();

            Array.Sort<int>(index, (a, b) => distances[a].CompareTo(distances[b]));

            int act_insert_index;

            for (int i = 0; i < index.Length; i++)
            {
                act_insert_index = index[i];

                sorted_distances.Add(distances[act_insert_index]);
                sorted_pair_indices.Add(pair_indices[act_insert_index]);
            }

            if (this.sorted_distances.Count > 0)
            {
                this.max_dist = this.Calculate_Distance_Quantil(this.max_dist_quartile);
                this.min_dist = this.Calculate_Distance_Quantil(this.min_dist_quartile);
                this.half_dist = this.max_dist / 2.0f;
                this.square_dist = (float)Math.Sqrt(0.5) * this.max_dist;

                this.Get_Start_Indices();
            }
        }

        /// <summary>
        /// Determines the index of the first consiered landmark pair for image calculation
        /// The 5% cloestest pairs according to their Euclidean distance are neglected to ensure an appropriate label placement
        /// </summary>
        private void Get_Start_Indices()
        {
            bool set_start_index = false;
            bool set_start_half_index = false;
            bool set_start_square_index = false;

            for (int i = 0; i < this.sorted_distances.Count; i++)
            {
                if ((this.sorted_distances[i] >= this.min_dist) && !(set_start_index))
                {
                    this.start_index = i;

                    set_start_index = true;
                }

                if ((this.sorted_distances[i] >= this.half_dist) && !(set_start_half_index))
                {
                    this.start_index_half_dist = i;

                    set_start_half_index = true;
                }

                if ((this.sorted_distances[i] >= this.square_dist) && !(set_start_square_index))
                {
                    this.start_index_square_dist = i;

                    set_start_square_index = true;
                }
            }
        }

        /// <summary>
        /// Init rendering with first landmark pair
        /// </summary>
        private void Set_Initial_Pair()
        {
            int pair_index = this.sorted_pair_indices[this.counter];

            Point act_pair = pair_index_list[pair_index];

            this.Set_Landmark_Pair(act_pair);
        }

        private float Calculate_Distance_Quantil(float p)
        {
            float quantil_value = Utility.GetQuantile(this.sorted_distances, p);

            return quantil_value;
        }

        #endregion

        #region - Init Transformation

        public void Init_Landmark_Transformation(int index)
        {
            this.counter = index;

            if (index >= this.sorted_pair_indices.Count)
            {
                this.counter = 0;
            }

            int pair_index = this.sorted_pair_indices[this.counter];

            this.act_pair = pair_index_list[pair_index];

            Vector3 p1 = this.positions[(int)act_pair.X];
            Vector3 p2 = this.positions[(int)act_pair.Y];

            this.Set_Landmark_Pair(act_pair);

            this.inital_transformation_xyplane = this.Calculate_Transformation_To_XYPlane(p1, p2);
        }

        /// <summary>
        /// Calculates initial transformation for a pair (p1 and p2) such that p1 and p2 lies within the xy-plane
        /// </summary>
        private Matrix4 Calculate_Transformation_To_XYPlane(Vector3 p1, Vector3 p2)
        {
            Matrix4 translation = Calculate_Translation_To_Origin(p1);

            float rot_angle = this.Calculate_Rot_Angle_To_XPPlane(p1, p2);

            Matrix4 rotation = Matrix4.CreateRotationY(rot_angle);

            Matrix4 transformation = translation * rotation;

            return transformation;
        }

        /// <summary>
        /// Determines rotation angle such that landmarks p1 and p2 lies within the xy-plane
        /// </summary>
        private float Calculate_Rot_Angle_To_XPPlane(Vector3 p1, Vector3 p2)
        {
            float rot_angle = 0;

            Vector3 p2_trans = p2 - p1;

            rot_angle = (float)Math.Atan2(p2_trans.Z, p2_trans.X);

            return rot_angle;
        }

        /// <summary>
        /// Translates a landmark p1 to orgin 
        /// </summary>
        private Matrix4 Calculate_Translation_To_Origin(Vector3 p1)
        {
            Matrix4 translation = Matrix4.CreateTranslation(-p1);

            return translation;
        }

        #endregion

        #region - Transformation -

        /// <summary>
        /// Returns Euclidean distance of current pair
        /// </summary>
        public float Get_Current_Dist()
        {
             float act_dist = this.sorted_distances[this.counter];

             return act_dist;
        }

        public void Get_Act_Landmarks_ScreenPos(out int pixel_xp1, out int pixel_yp1, out float depth_p1, out int pixel_xp2, out int pixel_yp2, out float depth_p2)
        {
            Vector3 p1 = this.act_positions[0];
            Vector3 p2 = this.act_positions[1];

            this.Get_Pixel_Info(p1, Utility.Trans_Mat_ModelView, Utility.Trans_Mat_Projection, out pixel_xp1, out pixel_yp1, out depth_p1);
            this.Get_Pixel_Info(p2, Utility.Trans_Mat_ModelView, Utility.Trans_Mat_Projection, out pixel_xp2, out pixel_yp2, out depth_p2);
        }

        public void Get_Landmarks_ScreenPos(int fst_vert_id, int snd_vert_id, Matrix4 mv,  Matrix4 pr, out Vector2 pixel_p1, out Vector2 pixel_p2)
        {
            int pixel_xp1, pixel_yp1, pixel_xp2, pixel_yp2;
            
            float depth_p1, depth_p2;

            Vector3 p1 = this.positions[fst_vert_id];
            Vector3 p2 = this.positions[snd_vert_id];

            this.Get_Pixel_Info(p1, mv, pr, out pixel_xp1, out pixel_yp1, out depth_p1);
            this.Get_Pixel_Info(p2, mv, pr, out pixel_xp2, out pixel_yp2, out depth_p2);

            pixel_p1 = new Vector2(pixel_xp1, pixel_yp1);
            pixel_p2 = new Vector2(pixel_xp2, pixel_yp2);
        }

        private void Get_Pixel_Info(Vector3 point, Matrix4 mv,  Matrix4 pr, out int pixel_x, out int pixel_y, out float pixel_z)
        {
            Vector4 new_point = new Vector4(point, 1.0f);

            Vector4 hom_point_mv;

            Vector4.Transform(ref new_point, ref mv, out hom_point_mv);

            Vector4 hom_point_pr;

            Vector4.Transform(ref hom_point_mv, ref pr, out hom_point_pr);

            Vector4 hom_point = hom_point_pr / hom_point_pr.W;

            pixel_x = (int)((Utility.Viewport.Z / 2.0) * hom_point.X + (Utility.Viewport.Z / 2.0) + Utility.Viewport.X);
            pixel_y = (int)((Utility.Viewport.W / 2.0) * hom_point.Y + (Utility.Viewport.W / 2.0) + Utility.Viewport.Y);
            pixel_z = (0.5f * (hom_point.Z + 1.0f));
        }

        public void Reset_Transformation()
        {
            this.inital_transformation_xyplane = Matrix4.Identity;
            this.condition_transformation = Matrix4.Identity;
            this.rotation_transformation = Matrix4.Identity;
            this.bounding_box_transformation = Matrix4.Identity;
        }

        public List<Point> Get_Nearest_Landmarks_Screenspace(int vert_id, int img_width, int img_height)
        {
            // Get positions of all landmarks in screen space
            List<Point> landmarks_screenpos = this.Get_Landmarks_Screen_Pos();

            // Get Voronoi diagram from landmark positions in screenspace
            List<VoronoiObject.GraphEdge> vor_edges = this.MakeVoronoiGraph(landmarks_screenpos, img_width, img_height);

            // Get direkt neighbors to current landmark 
            List<Point> nearest_neighbors = this.Get_Neighbors(vert_id, landmarks_screenpos, vor_edges); 

            return nearest_neighbors;
        }

        private List<Point> Get_Landmarks_Screen_Pos()
        {
            List<Point> landmarks_screenpos = new List<Point>();

            for (int i = 0; i < this.positions.Count; i++)
            {
                landmarks_screenpos.Add(this.Get_Landmarks_ScreenPos(this.positions[i]));
            }

            return landmarks_screenpos;
        }

        public Point Get_Landmarks_ScreenPos(Vector3 p1)
        {
            int pixel_xp1, pixel_yp1;

            float depth_p1;

            this.Get_Pixel_Info(p1, Utility.Trans_Mat_ModelView, Utility.Trans_Mat_Projection, out pixel_xp1, out pixel_yp1, out depth_p1);

            Point pixel_p1 = new Point(pixel_xp1, pixel_yp1);

            return pixel_p1;
        }

        private List<VoronoiObject.GraphEdge> MakeVoronoiGraph(List<Point> sites, int width, int height)
        {
            VoronoiObject.Voronoi voroObject = new VoronoiObject.Voronoi(0.1);

            double[] xVal = new double[sites.Count];
            double[] yVal = new double[sites.Count];

            for (int i = 0; i < sites.Count; i++)
            {
                xVal[i] = sites[i].X;
                yVal[i] = sites[i].Y;
            }

            return voroObject.generateVoronoi(xVal, yVal, 0, width, 0, height);
        }

        private List<Point> Get_Neighbors(int vert_id, List<Point> landmarks_screenpos, List<VoronoiObject.GraphEdge> vor_edges)
        {
            List<Point> neighbors = new List<Point>();

            List<int> neighbor_indices = new List<int>();

            for (int i = 0; i < vor_edges.Count; i++)
            {
                if (vert_id == vor_edges[i].site1)
                {
                    if (!neighbor_indices.Contains(vor_edges[i].site2))
                    {
                        neighbor_indices.Add(vor_edges[i].site2);
                    }
                }
                else if (vert_id == vor_edges[i].site2)
                {
                    if (!neighbor_indices.Contains(vor_edges[i].site1))
                    {
                        neighbor_indices.Add(vor_edges[i].site1);
                    }
                }
            }

            for (int i = 0; i < neighbor_indices.Count; i++)
            {
                neighbors.Add(landmarks_screenpos[neighbor_indices[i]]);
            }

            return neighbors;
        }

        #endregion

        #region - Rendering -

        public override bool Renderable()
        {
            if (this.vao == null)
            {
                return false;
            }

            if (this.shaderprog == null)
            {
                return false;
            }

            if (this.shaderprog.Prog == 0)
            {
                return false;
            }

            return true;
        }

        public override void SetupRender()
        {
            // Init VAO
            GL.GenVertexArrays(1, out vao[0]);
            GL.BindVertexArray(vao[0]);

            // vbo [0] = position
            GL.GenBuffers(vbo.Length, vbo);
            GL.BindBuffer(BufferTarget.ArrayBuffer, this.vbo[(uint)VBONames.Pos]);
            GL.BufferData<Vector3>(BufferTarget.ArrayBuffer, (IntPtr)(this.act_positions.Count * Vector3.SizeInBytes), this.act_positions.ToArray(), BufferUsageHint.StaticDraw);

            GL.VertexAttribPointer(0, 3, VertexAttribPointerType.Float, false, 0, 0);
            GL.EnableVertexAttribArray(0);

            // vbo [1] = normal
            GL.BindBuffer(BufferTarget.ArrayBuffer, this.vbo[(uint)VBONames.Norm]);
            GL.BufferData<Vector3>(BufferTarget.ArrayBuffer, (IntPtr)(this.act_normals.Count * Vector3.SizeInBytes), this.act_normals.ToArray(), BufferUsageHint.StaticDraw);

            GL.VertexAttribPointer(1, 3, VertexAttribPointerType.Float, false, 0, 0);
            GL.EnableVertexAttribArray(1);

            // Unbind Buffer
            GL.BindVertexArray(0);
            GL.BindBuffer(BufferTarget.ArrayBuffer, 0);

            this.Init_Setup = true;

            Console.WriteLine("-> Landmarks created");
        }

        public override void Render()
        {
            if (!Renderable())
            {
                return;
            }

            GL.PushMatrix();
            {
                GL.Enable(EnableCap.Blend);
                GL.Disable(EnableCap.DepthTest);

                GL.MultMatrix(ref this.transformationMatrix);

                this.shaderprog.EnableShader();
                {
                    GL.BindVertexArray(vao[0]);
                    {
                        GL.PointSize(10);
                        GL.DrawArrays(PrimitiveType.Points, 0, this.act_positions.Count);
                    }
                    GL.BindVertexArray(0);
                }

                this.shaderprog.DisableShader();
            }

            GL.PopMatrix();

            GL.Disable(EnableCap.Blend);
            GL.Enable(EnableCap.DepthTest);
        }

        /// <summary>
        /// Set landmark pair for rendering
        /// </summary>
        public void Set_Landmark_Pair(Point act_pair)
        {
            if (this.act_positions.Count > 0)
            {
                this.act_positions.Clear();
            }

            if (this.act_normals.Count > 0)
            {
                this.act_normals.Clear();
            }

            act_positions.Add(this.positions[(int)act_pair.X]);
            act_positions.Add(this.positions[(int)act_pair.Y]);

            act_normals.Add(this.normals[(int)act_pair.X]);
            act_normals.Add(this.normals[(int)act_pair.Y]);

            this.Clear_Rendering_Members();

            this.Init_Setup = false;
        }

        #endregion

        #endregion 
    }
}

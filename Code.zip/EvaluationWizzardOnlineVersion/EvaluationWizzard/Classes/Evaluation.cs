﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EvaluationWizzard.Properties;
using MathWorks.MATLAB.NET.Arrays;
using OpenTK;
using OpenTK.Graphics;
using OpenTK.Graphics.OpenGL;
using VesselTree;
using System.IO;
using RegionStatistics;
using System.Drawing.Imaging;
using System.Drawing;
using System.Diagnostics;

namespace EvaluationWizzard
{
    public class Optimal_Viewpoints
    {
        #region - Private Variables -

        private Control_NewEvaluation parent_control;

        private List<Mesh> vessel_objects;

        private List<Landmarks> vessel_objects_landmarks;

        private int act_dataset_index;

        private List<Dataset_Image_Info> datasets;

        private Dataset_Image_Info act_dataset;

        private int num_tasks; // number of tasks selected by the user

        private int max_num_condition_Iterations; // maximal number of iterations over all point pairs to find selected number of viewpoints for each condition

        private Point act_pixel_pos_p1; // current pixel position of first landmark of current landmark pair
        private Point act_pixel_pos_p2; // current pixel position of second landmark of current landmark pair

        private int pixel_radius;
        private int pixel_offset;
        private int pixel_transl;

        private float thres_back_pixel;

        private float step_size;

        private int grad_descent_iterations;

        private bool set_start_index_half;
        private bool set_start_index_square;

        private List<Vector4> final_sequence; // final image sequence

        #endregion

        #region - Constructors -

        public Optimal_Viewpoints( List<Mesh> Vessel_Tree, List<Landmarks> Vessel_Landmarks, int Num_Tasks, int Label_Radius)
        {
            this.vessel_objects = Vessel_Tree;

            this.vessel_objects_landmarks = Vessel_Landmarks;

            this.act_dataset_index = 0;

            this.datasets = new List<Dataset_Image_Info>();

            this.num_tasks = Num_Tasks;

            this.max_num_condition_Iterations = 0;

            this.act_pixel_pos_p1 = new Point(0,0);
            this.act_pixel_pos_p2 = new Point(0,0);

            this.pixel_radius = 18;
            this.pixel_offset = 9;
            this.pixel_transl = 2;

            this.thres_back_pixel = 99.0f;

            this.step_size = 0.1f;

            this.grad_descent_iterations = 10;

            this.set_start_index_half = false;
            this.set_start_index_square = false;
        }

        #endregion

        #region - Properties -

        public Control_NewEvaluation Parent_Control
        {
            get { return this.parent_control; }
            set { this.parent_control = value; }
        }

        public int Act_Dataset
        {
            get { return this.act_dataset_index; }
            set { this.act_dataset_index = value; }
        }

        public List<Mesh> Vessel_Trees
        {
            get { return this.vessel_objects; }
            set { this.vessel_objects = value; }
        }

        public List<Landmarks> Vessel_Endpoints
        {
            get { return this.vessel_objects_landmarks; }
            set { this.vessel_objects_landmarks = value; }
        }

        public Mesh Act_Vessel_Tree
        {
            get { return this.vessel_objects[this.act_dataset_index]; }
        }

        public Landmarks Act_Vessel_Tree_Landmarks
        {
            get { return this.vessel_objects_landmarks[this.act_dataset_index]; }
        }

        #endregion

        #region - Methods -

        #region - Image Calculation -

        public void Determine_Study_images()
        {
            for (int i = 0; i < this.vessel_objects.Count; i++)
            {
                this.act_dataset_index = i;

                // reset parameters before new dataset is processed
                this.Reset_Image_Generation();

                // add new dataset
                this.act_dataset = new Dataset_Image_Info(this.act_dataset_index, this.num_tasks);

                this.Determine_OptimalView_Position();

                this.set_start_index_half = false;
                this.set_start_index_square = false;
            }
        }

        /// <summary>
        /// Determines an optimal viewpoint for the current pair of landmarks depending on their condition (NN, NF, FN or FF)
        /// </summary>
        private void Determine_OptimalView_Position()
        {
            // image calculation
            for (int i = this.vessel_objects_landmarks[this.act_dataset_index].Start_Index; i < this.vessel_objects_landmarks[this.act_dataset_index].Number_Pairs; i++)
            {
                if (this.act_dataset.All_Images_Calculated()) // all images could be created
                {
                    break;
                }

                this.vessel_objects_landmarks[this.act_dataset_index].Init_Landmark_Transformation(i);

                this.Set_Transformation(this.vessel_objects_landmarks[this.act_dataset_index].Transformation_XYPlane);

                float act_dist = this.vessel_objects_landmarks[this.act_dataset_index].Get_Current_Dist();

                if ((act_dist < (this.vessel_objects_landmarks[this.act_dataset_index].Max_Dist / 2.0f)) && !this.act_dataset.reached_NN_cases)
                {
                    this.Determine_NN_Case();

                    this.Set_Transformation(this.Update_Transformation_Matrix());

                    this.Determine_Final_Viewpoint("NN");
                }
                else if (act_dist >= (this.vessel_objects_landmarks[this.act_dataset_index].Max_Dist / 2.0f) && act_dist < (float)Math.Sqrt(0.5) * this.vessel_objects_landmarks[this.act_dataset_index].Max_Dist)
                {
                    if (!this.act_dataset.reached_FN_cases)
                    {
                        this.Determine_FN_Case(act_dist);

                        this.Set_Transformation(this.Update_Transformation_Matrix());

                        this.Determine_Final_Viewpoint("FN");
                    }

                    this.Set_Transformation(Matrix4.Identity);

                    this.vessel_objects_landmarks[this.act_dataset_index].Reset_Transformation();

                    this.vessel_objects_landmarks[this.act_dataset_index].Init_Landmark_Transformation(i);

                    this.vessel_objects_landmarks[this.act_dataset_index].Init_Landmark_Transformation(i);

                    this.Set_Transformation(this.vessel_objects_landmarks[this.act_dataset_index].Transformation_XYPlane);

                    if (!this.act_dataset.reached_NF_cases)
                    {
                        this.Determine_NF_Case(act_dist);

                        this.Set_Transformation(this.Update_Transformation_Matrix());

                        this.Determine_Final_Viewpoint("NF");
                    }
                }
                else if ((act_dist > (float)Math.Sqrt(0.5) * this.vessel_objects_landmarks[this.act_dataset_index].Max_Dist) && !this.act_dataset.reached_FF_cases)
                {
                    this.Determine_FF_Case(act_dist);

                    this.Set_Transformation(this.Update_Transformation_Matrix());

                    this.Determine_Final_Viewpoint("FF");
                }

                i = this.Update_Iteration_Index(i);

                this.Set_Transformation(Matrix4.Identity);

                this.vessel_objects_landmarks[this.act_dataset_index].Reset_Transformation();

                if (i == (this.vessel_objects_landmarks[this.act_dataset_index].Number_Pairs - 1))
                {
                    if (!this.act_dataset.All_Images_Calculated())
                    {
                        i = this.vessel_objects_landmarks[this.act_dataset_index].Start_Index;

                        this.max_num_condition_Iterations++;

                        if (this.max_num_condition_Iterations > 2)
                        {
                            // todo handle case if not enough images could be produced for each condition 
                            return;
                        }
                    }
                }
            }

            this.act_dataset.Combine_All_Image_Information();

            this.datasets.Add(this.act_dataset);
        }

        private void Set_Transformation(Matrix4 transformation)
        {
            this.vessel_objects_landmarks[this.act_dataset_index].TransformationMatrix = transformation;

            this.Vessel_Trees[this.act_dataset_index].TransformationMatrix = transformation;

            this.parent_control.PaintControl.Refresh();
        }

        /// <summary>
        /// Determines an optimal viewpoint for the current pair of landmarks that are near to each other in screenspace and depth
        /// </summary>
        private void Determine_NN_Case()
        {
            this.vessel_objects_landmarks[this.act_dataset_index].Transformation_Condition = this.Determine_Transformation_NN_Case();
        }

        private Matrix4 Determine_Transformation_NN_Case()
        {
            float min_eps = 30.0f;

            float max_eps = 90.0f - min_eps;

            Random random = new Random();

            float angle_offset = (float)random.NextDouble() * (max_eps - min_eps) + min_eps;

            angle_offset = Utility.Degrees_to_Radians(angle_offset);

            Matrix4 transformation = Matrix4.CreateRotationY(angle_offset);

            return transformation;
        }

        /// <summary>
        /// Determines an optimal viewpoint for the current pair of landmarks that are far to each other in screenspace and near to each other in depth
        /// </summary>
        private void Determine_FN_Case(float act_dist)
        {
            this.vessel_objects_landmarks[this.act_dataset_index].Transformation_Condition = this.Determine_Transformation_FN_Case(act_dist);
        }

        private Matrix4 Determine_Transformation_FN_Case(float act_dist)
        {
            Matrix4 transformation = Matrix4.Identity;

            float min_eps = this.vessel_objects_landmarks[this.act_dataset_index].Max_Dist / 2.0f;

            float max_eps = act_dist;

            Random random_1 = new Random();

            float s = (float)random_1.NextDouble() * (max_eps - min_eps) + min_eps;

            float t = (float)Math.Sqrt((Math.Pow(act_dist, 2.0) - Math.Pow(s, 2.0)));

            float val = (float)(s/act_dist);

            float angle = (float)(Math.Acos(val));

            transformation = Matrix4.CreateRotationY(angle);
      
            return transformation;
        }

        /// <summary>
        /// Determines an optimal viewpoint for the current pair of landmarks that are near to each other in screenspace and far to each other in depth
        /// </summary>
        private void Determine_NF_Case(float act_dist)
        {
            this.vessel_objects_landmarks[this.act_dataset_index].Transformation_Condition = this.Determine_Transformation_NF_Case(act_dist);
        }

        private Matrix4 Determine_Transformation_NF_Case(float act_dist)
        {
            Matrix4 transformation = Matrix4.Identity;

            float min_eps = this.vessel_objects_landmarks[this.act_dataset_index].Max_Dist / 2.0f;

            float max_eps = act_dist;

            Random random_1 = new Random();

            float t = (float)random_1.NextDouble() * (max_eps - min_eps) + min_eps;

            float s = (float)Math.Sqrt((Math.Pow(act_dist, 2.0) - Math.Pow(t, 2.0)));

            float val = (float)(s / act_dist);

            float angle = (float)(Math.Acos(val));

            transformation = Matrix4.CreateRotationY(angle);

            return transformation;
        }

        /// <summary>
        /// Determines the final viewpoint by controlling if the landsmarks are visible and stores the resultant matrix
        /// </summary>
        private void Determine_Final_Viewpoint(string condition)
        {
            Point org_label_pos1, org_label_pos2;

            Point act_label_pos1, act_label_pos2;

            Point new_label_pos1, new_label_pos2;

            int far_point;

            if (this.Are_Landmarks_Positions_Visible(out org_label_pos1, out org_label_pos2, out far_point)) // store modelview, projection matrix and point indices
            {
                if (this.Determine_Final_Landmark_Label_Position(org_label_pos1, org_label_pos2, out new_label_pos1, out new_label_pos2))
                {
                    this.Transform_Bounding_Box_to_Origin();

                    Point offset_pos1 = new Point((new_label_pos1.X - org_label_pos1.X), (new_label_pos1.Y - org_label_pos1.Y));
                    Point offset_pos2 = new Point((new_label_pos2.X - org_label_pos2.X), (new_label_pos2.Y - org_label_pos2.Y));

                    this.act_dataset.Store_Viewpoint(condition, this.vessel_objects_landmarks[this.act_dataset_index].Act_Pair, offset_pos1, offset_pos2, far_point);
                }
                else
                {
                    if (this.Rotate_Pair_Around_Their_Connection(org_label_pos1, org_label_pos2, out act_label_pos1, out act_label_pos2, out new_label_pos1, out new_label_pos2, out far_point))
                    {
                        Point offset_pos1 = new Point((new_label_pos1.X - act_label_pos1.X), (new_label_pos1.Y - act_label_pos1.Y));
                        Point offset_pos2 = new Point((new_label_pos2.X - act_label_pos2.X), (new_label_pos2.Y - act_label_pos2.Y));

                        this.act_dataset.Store_Viewpoint(condition, this.vessel_objects_landmarks[this.act_dataset_index].Act_Pair, offset_pos1, offset_pos2, far_point);
                    }
                    else
                    {
                        Console.WriteLine("No point found");
                    }
                }
            }
            else
            {
                if (this.Rotate_Pair_Around_Their_Connection(org_label_pos1, org_label_pos2, out act_label_pos1, out act_label_pos2, out new_label_pos1, out new_label_pos2, out far_point))
                {
                    Point offset_pos1 = new Point((new_label_pos1.X - act_label_pos1.X), (new_label_pos1.Y - act_label_pos1.Y));
                    Point offset_pos2 = new Point((new_label_pos2.X - act_label_pos2.X), (new_label_pos2.Y - act_label_pos2.Y));

                    this.act_dataset.Store_Viewpoint(condition, this.vessel_objects_landmarks[this.act_dataset_index].Act_Pair, offset_pos1, offset_pos2, far_point);
                }
                else
                {
                    Console.WriteLine("No point found"); 
                }
            }
        }

        /// <summary>
        /// Determines an optimal viewpoint for the current pair of landmarks that are far to each other in screenspace and far to each other in depth
        /// </summary>
        private void Determine_FF_Case(float act_dist)
        {
            this.vessel_objects_landmarks[this.act_dataset_index].Transformation_Condition = this.Determine_Transformation_FF_Case(act_dist);
        }

        private Matrix4 Determine_Transformation_FF_Case(float act_dist)
        {
            Matrix4 transformation = Matrix4.Identity;

            float min_eps = 0;

            float half_max = this.vessel_objects_landmarks[this.act_dataset_index].Max_Dist / 2.0f;
            float sq_dist = (float)Math.Pow(act_dist,2);
            float sq_max_dist = (float)Math.Pow(this.vessel_objects_landmarks[this.act_dataset_index].Max_Dist, 2) / 4.0f;

            float max_eps = (-half_max) + (float)Math.Sqrt((sq_dist - sq_max_dist));

            Random random_1 = new Random();

            float eps = (float)random_1.NextDouble() * (max_eps - min_eps) + min_eps;

            float s = half_max + eps;

            float t = (float)Math.Sqrt((Math.Pow(act_dist, 2.0) - Math.Pow(s, 2.0)));

            float val = (float)(s / act_dist);

            float angle = (float)(Math.Acos(val));

            transformation = Matrix4.CreateRotationY(angle);

            return transformation;
        }

        private Matrix4 Update_Transformation_Matrix()
        {
            Matrix4 act_trafo = this.vessel_objects_landmarks[this.act_dataset_index].Transformation_XYPlane * this.vessel_objects_landmarks[this.act_dataset_index].Transformation_Condition * this.vessel_objects_landmarks[this.act_dataset_index].Transformation_Rotation * this.vessel_objects_landmarks[this.act_dataset_index].TransformationBounding_Box;

            return act_trafo;
        }

        /// <summary>
        /// Controls if the positions of landsmarks are visible from the current camera position
        /// far_point defines if p1 or p2 is further away --> far_point = 0 (p1 is further away), far_point=1 (p2 is further away), far_point = -1 (p1 and/or p2 not visible)
        /// </summary>
        private bool Are_Landmarks_Positions_Visible(out Point act_pixel_pos1, out Point act_pixel_pos2, out int far_point)
        {
            bool p1_visible = false;
            bool p2_visible = false;

            far_point = 0;

            int pixel_xp1, pixel_yp1, pixel_xp2, pixel_yp2;

            float depth_p1, depth_p2, depth_p1_screen, depth_p2_screen;

            this.vessel_objects_landmarks[this.act_dataset_index].Get_Act_Landmarks_ScreenPos(out pixel_xp1, out pixel_yp1, out depth_p1, out pixel_xp2, out pixel_yp2, out depth_p2);

            this.parent_control.Get_Pixels_Depth(pixel_xp1, pixel_yp1, pixel_xp2, pixel_yp2, out depth_p1_screen, out depth_p2_screen);

            act_pixel_pos1 = new Point(pixel_xp1, pixel_yp1);
            act_pixel_pos2 = new Point(pixel_xp2, pixel_yp2);

            float thres = 0.002f;

            if (Math.Abs(depth_p1 - depth_p1_screen) <= thres)
            {
                p1_visible = true;
            }

            if (Math.Abs(depth_p2 - depth_p2_screen) <= thres)
            {
                p2_visible = true;
            }
  
            if (p1_visible && p2_visible)
            {
                if (depth_p1 < depth_p2)
                {
                     far_point = 1; // first landmark is closer to camera (plus)
                }
                else
                {
                    far_point = 2; // second landmark is closer to camera
                }

                return true;
            }

            return false;
        }

        /// <summary>
        /// Rotates landsmarks around their connecting line until both landmarks are visible
        /// </summary>
        private bool Rotate_Pair_Around_Their_Connection(Point org_label_pos1, Point org_label_pos2, out Point act_label_pos1, out Point act_label_pos2, out Point new_label_pos1, out Point new_label_pos2, out int far_point)
        {
            Vector3 rot_axis = this.vessel_objects_landmarks[this.act_dataset_index].P2.Normalized();

            float angle;

            act_label_pos1 = org_label_pos1;
            act_label_pos2 = org_label_pos2;

            new_label_pos1 = act_label_pos1;
            new_label_pos2 = act_label_pos2;

            far_point = -1;

            float offset = 0;

            bool visible = false;

            for (int i = 0; i < 360; i += 10)
            {
                offset = (float)i;

                angle = Utility.Degrees_to_Radians(offset);

                Matrix4 rot_mat = Utility.Get_Rotation_Matrix(rot_axis, angle);

                this.vessel_objects_landmarks[this.act_dataset_index].Transformation_Rotation = rot_mat;

                this.Set_Transformation(this.Update_Transformation_Matrix());

                if (this.Are_Landmarks_Positions_Visible(out act_label_pos1, out act_label_pos2, out far_point))
                {
                    if (this.Determine_Final_Landmark_Label_Position(act_label_pos1, act_label_pos2, out new_label_pos1, out new_label_pos2))
                    {
                        this.Transform_Bounding_Box_to_Origin();

                        visible = true;

                        break;
                    }
                }
            }

            return visible;
        }

        private bool Determine_Final_Landmark_Label_Position(Point act_label_pos1, Point act_label_pos2, out Point new_label_pos1, out Point new_label_pos2)
        {
            bool fst_label_visible = false;
            bool snd_label_visible = false;

            new_label_pos1 = act_label_pos1;
            new_label_pos2 = act_label_pos2;

            if (this.Is_Landmark_Labels_Visible(act_label_pos1))
            {
                if (this.Label_Position_Within_Voronoi(this.vessel_objects_landmarks[this.act_dataset_index].Act_Pair.X, act_label_pos1))
                {
                    fst_label_visible = true;
                }
            }
            else
            {
                if (this.Gradient_Descent_on_Image(this.vessel_objects_landmarks[this.act_dataset_index].Act_Pair.X, act_label_pos1, out new_label_pos1))
                {
                    fst_label_visible = true;
                }
                else
                {
                    fst_label_visible = false;
                }
            }

            if (this.Is_Landmark_Labels_Visible(act_label_pos2))
            {
                if (this.Label_Position_Within_Voronoi(this.vessel_objects_landmarks[this.act_dataset_index].Act_Pair.Y, act_label_pos2))
                {
                    snd_label_visible = true;
                }
            }
            else
            {
                if (this.Gradient_Descent_on_Image(this.vessel_objects_landmarks[this.act_dataset_index].Act_Pair.Y, act_label_pos2, out new_label_pos2))
                {
                    snd_label_visible = true;
                }
                else
                {
                    snd_label_visible = false;
                }
            }

            if (fst_label_visible && snd_label_visible)
            {
                return true;
            }

            return false;
        }

        private bool Is_Landmark_Labels_Visible(Point act_pixel)
        {
            float back_pixel = this.Calculate_Percentaged_Background_Part(act_pixel.X, act_pixel.Y, this.pixel_offset);

            if (back_pixel >= this.thres_back_pixel)
            {
                return true;
            }

            return false;
        }

        /// <summary>
        /// Calculates how many pixels are background pixels (pixel_radius) around a given pixel position (pixel_xp1, pixel_yp1) --> percentage
        /// </summary>
        private float Calculate_Percentaged_Background_Part(int pixel_xp, int pixel_yp, int pixel_offset)
        {
            float perc_value = 0;

            float[] pixels = this.parent_control.Get_Framebuffer_Content();

            int start_x = pixel_xp - pixel_offset;
            int end_x = pixel_xp + pixel_offset;

            int start_y = pixel_yp - pixel_offset;
            int end_y = pixel_yp + pixel_offset;

            int backgr_counter = 0;
            int pixel_counter = 0;

            if (start_x < 0)
            {
                start_x = 0;
            }
            if (start_y < 0)
            {
                start_y = 0;
            }

            if (end_x >= this.parent_control.PaintControl.ClientSize.Width)
            {
                end_x = this.parent_control.PaintControl.ClientSize.Width-2;
            }
            if (end_y >= this.parent_control.PaintControl.ClientSize.Height)
            {
                end_y = this.parent_control.PaintControl.ClientSize.Height-2;
            }

            int pixel_index;
            float pixel_val;

            for (int i = start_x; i <= end_x; i++)
            {
                for (int j = start_y; j <= end_y; j++)
                {
                    pixel_index = ((j) * this.parent_control.PaintControl.ClientSize.Width) + (i);

                    pixel_val = pixels[pixel_index];

                    if (pixel_val == 1.0f)
                    {
                        backgr_counter++;
                    }

                    pixel_counter++;
                }
            }

            perc_value = ((float)backgr_counter * 100.0f) / (float)pixel_counter;

            return perc_value;
        }

        private bool Gradient_Descent_on_Image(int vert_id, Point act_label_pos, out Point new_label_pos)
        {
            Point org_pos = act_label_pos;
            Point act_pos = act_label_pos;

            new_label_pos = act_label_pos;

            bool terminate;

            for (int i = 0; i < this.grad_descent_iterations; i++)
            {
                new_label_pos = this.Gradient_Descent_Step(vert_id, org_pos, act_pos, out terminate);

                if (terminate)
                {
                    return false;
                }
                else if (this.Is_Landmark_Labels_Visible(new_label_pos))
                {
                    return true;
                }

                act_pos = new_label_pos; 
            }

            return false;
        }

        private Point Gradient_Descent_Step(int vert_id, Point org_label_pos, Point act_label_pos, out bool terminate)
        {
            terminate = false;

            float back_pixel_act = this.Calculate_Percentaged_Background_Part((int)act_label_pos.X, (int)act_label_pos.Y, this.pixel_offset);
            float back_pixel_x_trans = this.Calculate_Percentaged_Background_Part((int)(act_label_pos.X + this.pixel_transl), (int)act_label_pos.Y, this.pixel_offset);
            float back_pixel_y_trans = this.Calculate_Percentaged_Background_Part((int)act_label_pos.X, (int)(act_label_pos.Y + this.pixel_transl), this.pixel_offset);

            float grad_x = back_pixel_x_trans - back_pixel_act;
            float grad_y = back_pixel_y_trans - back_pixel_act;

            Vector2 grad = new Vector2(grad_x, grad_y);

            if (grad.Length < 0.001)
            {
                terminate = true;

                return act_label_pos;
            }

            int step_size_count = 5;
            float lambda = this.step_size;

            float[] lambda_values = new float[this.grad_descent_iterations];
            float[] back_count_values = new float[step_size_count];
            Point[] positions = new Point[step_size_count];

            float new_pos_x, new_pos_y;
            int new_x, new_y;
            float back_pixel;

            for (int i = 0; i < step_size_count; i++)
            {
                lambda = lambda + ((float)i * this.step_size);

                new_pos_x = act_label_pos.X + (lambda * grad_x);
                new_pos_y = act_label_pos.Y + (lambda * grad_y);

                new_x = (int)new_pos_x;
                new_y = (int)new_pos_y;

                if ((Math.Abs(new_x-org_label_pos.X) <= this.pixel_radius) && (Math.Abs(new_y-org_label_pos.Y) <= this.pixel_radius))
                {
                    if (this.Label_Position_Within_Voronoi(vert_id, new Point(new_x, new_y)))
                    {
                        if ((new_x > 0) && (new_x <this.parent_control.PaintControl.ClientSize.Width) && ((new_y > 0) && (new_y <this.parent_control.PaintControl.ClientSize.Height)))
                        {
                            back_pixel = this.Calculate_Percentaged_Background_Part(new_x, new_y, this.pixel_offset);

                            back_count_values[i] = back_pixel;

                            positions[i] = new Point(new_x, new_y);
                        }
                    }
                }
                else
                {
                    break;
                }
            }

            int optimal_lambda = this.Determine_Optimal_Stepsize(back_count_values);

            Point new_label_pos = positions[optimal_lambda];

            if (new_label_pos.X == 0 && new_label_pos.Y == 0)
            {
                new_label_pos = act_label_pos;

                terminate = true;
            }

            return new_label_pos;
        }

        private int Determine_Optimal_Stepsize(float[] back_count_values)
        {
            float max = back_count_values.Max();

            // Index max
            int index = Array.IndexOf(back_count_values, max);

            return index;
        }

        private bool Label_Position_Within_Voronoi(int vert_id, Point act_label_pos)
        {
            List<Point> neighbors = this.vessel_objects_landmarks[this.act_dataset_index].Get_Nearest_Landmarks_Screenspace(vert_id, this.parent_control.ClientSize.Width, this.parent_control.ClientSize.Height);

            Vector3 act_pos = this.vessel_objects_landmarks[this.act_dataset_index].Positions[vert_id];

            Point act_landmark_pixel_pos = this.vessel_objects_landmarks[this.act_dataset_index].Get_Landmarks_ScreenPos(act_pos);

            Vector2 dist_vec = new Vector2((act_landmark_pixel_pos.X- act_label_pos.X), (act_landmark_pixel_pos.Y- act_label_pos.Y));

            float dist = dist_vec.Length;

            float neigh_dist;

            for (int i = 0; i < neighbors.Count; i++)
            {
                dist_vec = new Vector2((neighbors[i].X- act_label_pos.X), (neighbors[i].Y- act_label_pos.Y));

                neigh_dist = dist_vec.Length;

                if (neigh_dist < dist)
                {
                    return false;
                }
            }

            return true;
        }

        private void Transform_Bounding_Box_to_Origin()
        {
            // Translate tree center to origin
            List<Vector4> transformed_vertices = new List<Vector4>();

            Matrix4 m1 = this.vessel_objects[this.act_dataset_index].TransformationMatrix;

            m1.Transpose();

            for (int i = 0; i < this.vessel_objects[this.act_dataset_index].Positions.Count; i++)
            {
                Vector4 pos = Utility.Vector_Matrix_Multiplikation(m1, new Vector4(this.vessel_objects[this.act_dataset_index].Positions[i], 1));

                transformed_vertices.Add(pos);
            }

            Vector4 center = this.vessel_objects[this.act_dataset_index].Calculate_Center(transformed_vertices);

            Matrix4 translation = Matrix4.CreateTranslation(-center.Xyz);

            this.vessel_objects_landmarks[this.act_dataset_index].TransformationBounding_Box = translation;

            this.Set_Transformation(this.Update_Transformation_Matrix());

            // Scale mesh to screen size
            transformed_vertices.Clear();

            Matrix4 mod_trans = Utility.Trans_Mat_ModelView;
            Matrix4 pro_trans = Utility.Trans_Mat_Projection;

            mod_trans.Transpose();
            pro_trans.Transpose();

            for (int i = 0; i < this.vessel_objects[this.act_dataset_index].Positions.Count; i++)
            {
                Vector4 pos = Utility.Vector_Matrix_Multiplikation(mod_trans, new Vector4(this.vessel_objects[this.act_dataset_index].Positions[i], 1));

                pos = Utility.Vector_Matrix_Multiplikation(pro_trans, pos);

                transformed_vertices.Add(pos);
            }

            List<Vector4> bound_box = this.vessel_objects[this.act_dataset_index].Determine_Bounding_Box(transformed_vertices);

            float min_x, max_x, min_y, max_y, min_z, max_z;

            this.Get_Projection_Bounds(bound_box, out min_x, out max_x, out min_y, out max_y, out min_z, out max_z);

            List<float> lambdas = new List<float>();

            if (min_x < -1.0f || min_x > 1.0f)
            {
                lambdas.Add(this.Calculate_Scaling_Factor_X(min_x));
            }
            if (max_x < -1.0f || max_x > 1.0f)
            {
                lambdas.Add(this.Calculate_Scaling_Factor_X(max_x));
            }
            if (min_y < -1.0f || min_y > 1.0f)
            {
                lambdas.Add(this.Calculate_Scaling_Factor_Y(min_y));
            }
            if (max_y < -1.0f || max_y > 1.0f)
            {
                lambdas.Add(this.Calculate_Scaling_Factor_Y(max_y));
            }

            if (min_z < -1.0f || min_z > 1.0f)
            {
                lambdas.Add(this.Calculate_Scaling_Factor_Z(min_z));
            }
            if (max_z < -1.0f || max_z > 1.0f)
            {
                lambdas.Add(this.Calculate_Scaling_Factor_Z(max_z));
            }

            if (lambdas.Count > 0)
            {
                float scale = Math.Abs(lambdas.Min()) * 1.025f;

                float dif = scale - Math.Abs(lambdas.Min());

                float real_scale = Math.Abs(lambdas.Min()) - dif;

                Matrix4 scaling = Matrix4.CreateScale(real_scale);

                Matrix4 transform = translation * scaling;

                this.vessel_objects_landmarks[this.act_dataset_index].TransformationBounding_Box = transform;

                this.Set_Transformation(this.Update_Transformation_Matrix());
            }
        }

        private void Get_Projection_Bounds(List<Vector4> proj_vertices, out float min_x, out float max_x, out float min_y, out float max_y, out float min_z, out float max_z)
        {
            min_x = float.MaxValue;
            max_x = -float.MaxValue;
            min_y = float.MaxValue;
            max_y = -float.MaxValue;
            min_z = float.MaxValue;
            max_z = -float.MaxValue;


            for (int i = 0; i < proj_vertices.Count; i++)
            {
                if (proj_vertices[i].X < min_x)
                {
                    min_x = proj_vertices[i].X;
                }
                if (proj_vertices[i].X > max_x)
                {
                    max_x = proj_vertices[i].X;
                }

                if (proj_vertices[i].Y < min_y)
                {
                    min_y = proj_vertices[i].Y;
                }
                if (proj_vertices[i].Y > max_y)
                {
                    max_y = proj_vertices[i].Y;
                }

                if (proj_vertices[i].Z < min_z)
                {
                    min_z = proj_vertices[i].Z;
                }
                if (proj_vertices[i].Z > max_z)
                {
                    max_z = proj_vertices[i].Z;
                }
            }
        }

        private float Calculate_Scaling_Factor_X(float proj_bound_val)
        {
            float lambda_x = 1;

            Matrix4 MP = Utility.Trans_Mat_ModelView * Utility.Trans_Mat_Projection;

            if (proj_bound_val < 0)
            {
                lambda_x = (-1.0f - MP.M41)/ (proj_bound_val - MP.M41);
            }
            else
            {
                lambda_x = (1.0f - MP.M41) / (proj_bound_val - MP.M41);
            }

            return lambda_x;
        }

        private float Calculate_Scaling_Factor_Y(float proj_bound_val)
        {
            float lambda_y = 1;

            Matrix4 MP = Utility.Trans_Mat_ModelView * Utility.Trans_Mat_Projection;

            if (proj_bound_val < 0)
            {
                lambda_y = (-1.0f - MP.M42) / (proj_bound_val - MP.M42);
            }
            else
            {
                lambda_y = (1.0f - MP.M42) / (proj_bound_val - MP.M42);
            }

            return lambda_y;
        }

        private float Calculate_Scaling_Factor_Z(float proj_bound_val)
        {
            float lambda_z = 1;

            Matrix4 MP = Utility.Trans_Mat_ModelView * Utility.Trans_Mat_Projection;

            if (proj_bound_val < 0)
            {
                lambda_z = (-1.0f - MP.M43) / (proj_bound_val - MP.M43);
            }
            else
            {
                lambda_z = (1.0f - MP.M43) / (proj_bound_val - MP.M43);
            }

            return lambda_z;
        }

        private int Update_Iteration_Index(int act_iteration)
        {
            if (this.act_dataset.reached_NN_cases && !(this.act_dataset.reached_FN_cases) && !(this.act_dataset.reached_NF_cases) && !(this.act_dataset.reached_FF_cases))
            {
                if (!this.set_start_index_half)
                {
                    int index = this.vessel_objects_landmarks[this.act_dataset_index].Start_Index_Half_Dist - 1;
                    this.set_start_index_half = true;

                    return index;
                }
               
            }
            else if (this.act_dataset.reached_NN_cases && this.act_dataset.reached_FN_cases && this.act_dataset.reached_NF_cases && !(this.act_dataset.reached_FF_cases))
            {
                if (!this.set_start_index_square)
                {
                    int index = this.vessel_objects_landmarks[this.act_dataset_index].Start_Index_Square_Dist - 1;
                    this.set_start_index_square = true;

                    return index;
                }
                
            }

            return act_iteration;
        }

        private void Reset_Image_Generation()
        {
            this.max_num_condition_Iterations = 0;

            this.act_pixel_pos_p1 = new Point(0, 0);
            this.act_pixel_pos_p2 = new Point(0, 0);

            this.step_size = 0.1f;

            this.Set_Transformation(Matrix4.Identity);

            this.vessel_objects_landmarks[this.act_dataset_index].Reset_Transformation();
        }

        #endregion

        #region - Image Generation -

        public void Generate_Images(string path_images, string path_groundtruth, int num_shaders)
        {
            try
            {
                //check if directory already exists
                if (!Directory.Exists(path_images))
                {
                    Directory.CreateDirectory(path_images);
                }

                this.final_sequence = this.Generate_Image_Sequence(num_shaders);

                this.parent_control.Render_Images = true;

                int dataset_index, cam_index, condition_index, shader_index;

                string ext_path;

                List<int> far_point_indices = new List<int>();

                int far_index;

                for (int i = 0; i < final_sequence.Count; i++)
                {
                    dataset_index = (int)final_sequence[i].X;
                    cam_index = (int)final_sequence[i].Y;
                    condition_index = (int)final_sequence[i].Z;
                    shader_index = (int)final_sequence[i].W;

                    this.act_dataset_index = dataset_index;

                    this.parent_control.Render_MV = this.datasets[dataset_index].all_modelview_matrices[condition_index][cam_index];
                    this.parent_control.Render_PR = this.datasets[dataset_index].all_projection_matrices[condition_index][cam_index];

                    this.vessel_objects_landmarks[dataset_index].Set_Landmark_Pair(this.datasets[dataset_index].all_indices_pointpairs[condition_index][cam_index]);

                    far_index = this.datasets[dataset_index].all_far_points[condition_index][cam_index];

                    far_point_indices.Add(far_index);

                    this.Parent_Control.Act_Shader = shader_index;

                    this.vessel_objects[dataset_index].Init_Shader = false;

                    this.parent_control.Setup_Camera_Mesh();
                    this.parent_control.PaintControl.Refresh();

                    //ext_path = path_images + @"\" + i + "dataset_" + dataset_index + "_image_" + cam_index + "_cond_" + condition_index + "_shad_" + shader_index + ".jpg";
                    ext_path = path_images + @"\" + (1000+ i) + "scene.jpg";

                    Vector2 pixel_p1, pixel_p2;

                    this.vessel_objects_landmarks[dataset_index].Get_Landmarks_ScreenPos((int)this.datasets[dataset_index].all_indices_pointpairs[condition_index][cam_index].X, (int)this.datasets[dataset_index].all_indices_pointpairs[condition_index][cam_index].Y,
                                                                  this.datasets[dataset_index].all_modelview_matrices[condition_index][cam_index], this.datasets[dataset_index].all_projection_matrices[condition_index][cam_index], out pixel_p1, out pixel_p2);

                    Vector2 trans_pixel_p1 = pixel_p1 + new Vector2(this.datasets[dataset_index].all_pixel_label_offset_pairs[condition_index][cam_index].X, this.datasets[dataset_index].all_pixel_label_offset_pairs[condition_index][cam_index].Y);
                    Vector2 trans_pixel_p2 = pixel_p2 + new Vector2(this.datasets[dataset_index].all_pixel_label_offset_pairs[condition_index][cam_index].Z, this.datasets[dataset_index].all_pixel_label_offset_pairs[condition_index][cam_index].W);

                    this.parent_control.Take_Screenshot(ext_path, ImageFormat.Jpeg, trans_pixel_p1, trans_pixel_p2);
                }

                //check if directory already exists
                if (!Directory.Exists(path_groundtruth))
                {
                    Directory.CreateDirectory(path_groundtruth);
                }

                this.Export_Far_Indices(far_point_indices, path_groundtruth, num_shaders);

                this.parent_control.Render_Images = false;
            }
            catch (Exception)
            {
            }
        }

        private List<Vector4> Generate_Image_Sequence(int num_shaders)
        {
            int D = this.vessel_objects.Count; // number datasets
            int S = num_shaders;               // number shaders
            int N = this.num_tasks;            // number required tasks for each of the four categories (NN, FN,NF, FF)

            bool[, ,] bool_check = new bool[S, D, 4*N]; // current scene already used or not

            int i = 0;
            int j = 0;
            int k = 0;

            int new_j;

            List<Vector4> final_sequence = new List<Vector4>();
            Vector4 act_scene; // x= dataset_index, y = cam_index, z = type_index (NN, FN,NF, FF), w = shader_index
            int cam_index, type_index;

            for (int inc = 0; inc < (4*N*D*S); inc++)
            {
                if (!bool_check[k,i,j])
                {
                    cam_index = j%4;
                    type_index = j/4;
                    act_scene = new Vector4(i, cam_index, type_index, k);
                    final_sequence.Add(act_scene);
                    bool_check[k, i, j] = true; 
                }
                else
                {
                    for (int m = 0; m < (4*N); m++)
                    {
                        new_j = (j+m)%(4*N);

                        if (!bool_check[k,i,new_j])
                        {
                            j = new_j;

                            cam_index = j % 4;
                            type_index = j / 4;
                            act_scene = new Vector4(i, cam_index, type_index, k);
                            final_sequence.Add(act_scene);
                            bool_check[k, i, j] = true;

                            break;
                        }
                    }
                }

                i = (i + 1) % D;
                j = (j + N) % (4 * N);
                k = (k + 1) % S;
            }

            return final_sequence;
        }

        /// <summary>
        /// Exports information about which landmark is closer to screen to a csv-file
        /// </summary>
        private void Export_Far_Indices(List<int> indices, string path, int num_shaders)
        {
            string lineindex = num_shaders.ToString() + "," + this.num_tasks + ","; 

            path = path + @"\groundtruth.csv";

            using (StreamWriter sw = File.CreateText(path))
            {
                for (int i = 0; i < indices.Count; i++)
                {
                    if (i < indices.Count - 1)
                    {
                        lineindex += indices[i].ToString() + ",";
                    }
                    else
                    {
                        lineindex += indices[i].ToString();
                    }
                }

                sw.WriteLine(lineindex);

                sw.Flush();

                sw.Close();
            }
        }

        #endregion

        #region - Export -

        public void Export_Image_Information(string path)
        {
            if (this.final_sequence == null)
            {
                return;
            }

            //check if directory already exists
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }

            int dataset_index, cam_index, condition_index, shader_index;

            Matrix4 mv, pr;

            Point act_pair;

            Vector2 pixel_p1, pixel_p2;

            Vector2 trans_pixel_p1, trans_pixel_p2;

            for (int i = 0; i < this.final_sequence.Count; i++)
            {
                dataset_index = (int)this.final_sequence[i].X;
                cam_index = (int)this.final_sequence[i].Y;
                condition_index = (int)this.final_sequence[i].Z;
                shader_index = (int)this.final_sequence[i].W;

                string file_dir = path  + @"\" + i + "dataset_" + "0" + "_image_" + cam_index + "_cond_" + condition_index + "_shad_" + shader_index + ".txt";

                mv = this.datasets[dataset_index].all_modelview_matrices[condition_index][cam_index];
                pr = this.datasets[dataset_index].all_projection_matrices[condition_index][cam_index];

                act_pair = this.datasets[dataset_index].all_indices_pointpairs[condition_index][cam_index];

                this.vessel_objects_landmarks[dataset_index].Get_Landmarks_ScreenPos((int)this.datasets[dataset_index].all_indices_pointpairs[condition_index][cam_index].X, (int)this.datasets[dataset_index].all_indices_pointpairs[condition_index][cam_index].Y,
                                                              this.datasets[dataset_index].all_modelview_matrices[condition_index][cam_index], this.datasets[dataset_index].all_projection_matrices[condition_index][cam_index], out pixel_p1, out pixel_p2);

                trans_pixel_p1 = pixel_p1 + new Vector2(this.datasets[dataset_index].all_pixel_label_offset_pairs[condition_index][cam_index].X, this.datasets[dataset_index].all_pixel_label_offset_pairs[condition_index][cam_index].Y);
                trans_pixel_p2 = pixel_p2 + new Vector2(this.datasets[dataset_index].all_pixel_label_offset_pairs[condition_index][cam_index].Z, this.datasets[dataset_index].all_pixel_label_offset_pairs[condition_index][cam_index].W);

                this.Export_Single_Image_Info(file_dir, mv, pr, act_pair, trans_pixel_p1, trans_pixel_p2);
            }
        }

        private void Export_Single_Image_Info(string file_dir, Matrix4 mv, Matrix4 pr, Point act_pair, Vector2 label_pos_1, Vector2 label_pos_2)
        {
            string entry;

            Vector4 row_0, row_1, row_2, row_3;

            using (StreamWriter sw = File.CreateText(file_dir))
            {
                sw.WriteLine("ModelView Matrix");

                row_0 = mv.Row0;
                row_1 = mv.Row1;
                row_2 = mv.Row2;
                row_3 = mv.Row3;

                entry = this.Get_String_from_Vector(row_0);
                sw.WriteLine(entry);

                entry = this.Get_String_from_Vector(row_1);
                sw.WriteLine(entry);

                entry = this.Get_String_from_Vector(row_2);
                sw.WriteLine(entry);

                entry = this.Get_String_from_Vector(row_3);
                sw.WriteLine(entry);

                sw.WriteLine("Projection Matrix");

                row_0 = pr.Row0;
                row_1 = pr.Row1;
                row_2 = pr.Row2;
                row_3 = pr.Row3;

                entry = this.Get_String_from_Vector(row_0);
                sw.WriteLine(entry);

                entry = this.Get_String_from_Vector(row_1);
                sw.WriteLine(entry);

                entry = this.Get_String_from_Vector(row_2);
                sw.WriteLine(entry);

                entry = this.Get_String_from_Vector(row_3);
                sw.WriteLine(entry);

                sw.WriteLine("Point Indices");

                sw.WriteLine(act_pair.X);
                sw.WriteLine(act_pair.Y);

                sw.WriteLine("First Label Position");
                sw.WriteLine(label_pos_1.X);
                sw.WriteLine(label_pos_1.Y);

                sw.WriteLine("Second Label Position");
                sw.WriteLine(label_pos_2.X);
                sw.WriteLine(label_pos_2.Y);

                sw.Flush();

                sw.Close();
            }
        }

        private string Get_String_from_Vector(Vector4 vec)
        {
            string entry = vec.X.ToString() + " " + vec.Y.ToString() + " " + vec.Z.ToString() + " " + vec.W.ToString();

            return entry;
        }

        #endregion

        #endregion
    }

    public class Dataset_Image_Info
    {
        #region - Private Variables -

        private int index; // index of dataset instance

        private int num_tasks; // number of tasks selected by the user

        private int act_num_NN_tasks;
        private int act_num_FN_tasks;
        private int act_num_NF_tasks;
        private int act_num_FF_tasks;

        private List<Matrix4> modelview_matrices_NN;
        private List<Matrix4> modelview_matrices_FN;
        private List<Matrix4> modelview_matrices_NF;
        private List<Matrix4> modelview_matrices_FF;

        private List<Matrix4> projection_matrices_NN;
        private List<Matrix4> projection_matrices_FN;
        private List<Matrix4> projection_matrices_NF;
        private List<Matrix4> projection_matrices_FF;

        private List<Point> indices_pointpairs_NN;
        private List<Point> indices_pointpairs_FN;
        private List<Point> indices_pointpairs_NF;
        private List<Point> indices_pointpairs_FF;

        public List<Vector4> pixel_label_offset_pairs_NN; // first two components for first label postion offsets in pixxel coordinates and last two commponents for second label position
        public List<Vector4> pixel_label_offset_pairs_FN;
        public List<Vector4> pixel_label_offset_pairs_NF;
        public List<Vector4> pixel_label_offset_pairs_FF;

        private List<int> far_points_NN_cases;
        private List<int> far_points_FN_cases;
        private List<int> far_points_NF_cases;
        private List<int> far_points_FF_cases;

        public List<List<Matrix4>> all_modelview_matrices;
        public List<List<Matrix4>> all_projection_matrices;
        public List<List<Point>> all_indices_pointpairs;
        public List<List<Vector4>> all_pixel_label_offset_pairs;
        public List<List<int>> all_far_points;

        public bool reached_NN_cases;
        public bool reached_FN_cases;
        public bool reached_NF_cases;
        public bool reached_FF_cases;

        #endregion

        #region - Constructors -

        public Dataset_Image_Info(int Dataset_Index, int Num_Tasks)
        {
            this.index = Dataset_Index;

            this.num_tasks = Num_Tasks;

            this.act_num_NN_tasks = 0;
            this.act_num_FN_tasks = 0;
            this.act_num_NF_tasks = 0;
            this.act_num_FF_tasks = 0;

            this.modelview_matrices_NN = new List<Matrix4>();
            this.modelview_matrices_FN = new List<Matrix4>();
            this.modelview_matrices_NF = new List<Matrix4>();
            this.modelview_matrices_FF = new List<Matrix4>();

            this.projection_matrices_NN = new List<Matrix4>();
            this.projection_matrices_FN = new List<Matrix4>();
            this.projection_matrices_NF = new List<Matrix4>();
            this.projection_matrices_FF = new List<Matrix4>();

            this.indices_pointpairs_NN = new List<Point>();
            this.indices_pointpairs_FN = new List<Point>();
            this.indices_pointpairs_NF = new List<Point>();
            this.indices_pointpairs_FF = new List<Point>();

            this.pixel_label_offset_pairs_NN = new List<Vector4>();
            this.pixel_label_offset_pairs_FN = new List<Vector4>();
            this.pixel_label_offset_pairs_NF = new List<Vector4>();
            this.pixel_label_offset_pairs_FF = new List<Vector4>();

            this.far_points_NN_cases = new List<int>();
            this.far_points_FN_cases = new List<int>();
            this.far_points_NF_cases = new List<int>();
            this.far_points_FF_cases = new List<int>();

            this.all_modelview_matrices = new List<List<Matrix4>>();
            this.all_projection_matrices = new List<List<Matrix4>>();
            this.all_indices_pointpairs = new List<List<Point>>();
            this.all_pixel_label_offset_pairs = new List<List<Vector4>>();
            this.all_far_points = new List<List<int>>();

            this.reached_NN_cases = false;
            this.reached_FN_cases = false;
            this.reached_NF_cases = false;
            this.reached_FF_cases = false;
        }

        #endregion

        #region - Properties -

        public int Act_Dataset_Index
        {
            get { return this.index; }
            set { this.index = value; }
        }

        #endregion

        #region - Methods -

        #region - Image Calculation -

        public bool All_Images_Calculated()
        {
            if (this.reached_NN_cases && this.reached_FN_cases && this.reached_NF_cases && this.reached_FF_cases) // all images could be created
            {
                return true;
            }

            return false;
        }

        public void Store_Viewpoint(string condition, Point act_pair, Point offset_label_pos1, Point offset_label_pos2, int far_point)
        {
            switch (condition)
            {
                case "NN":
                    this.modelview_matrices_NN.Add(Utility.Trans_Mat_ModelView);
                    this.projection_matrices_NN.Add(Utility.Trans_Mat_Projection);
                    this.indices_pointpairs_NN.Add(act_pair);
                    this.pixel_label_offset_pairs_NN.Add(new Vector4(offset_label_pos1.X, offset_label_pos1.Y, offset_label_pos2.X, offset_label_pos2.Y));
                    this.far_points_NN_cases.Add(far_point);

                    this.act_num_NN_tasks++;

                    if (this.act_num_NN_tasks == this.num_tasks)
                    {
                        this.reached_NN_cases = true;
                    }

                    break;

                case "FN":
                    this.modelview_matrices_FN.Add(Utility.Trans_Mat_ModelView);
                    this.projection_matrices_FN.Add(Utility.Trans_Mat_Projection);
                    this.indices_pointpairs_FN.Add(act_pair);
                    this.pixel_label_offset_pairs_FN.Add(new Vector4(offset_label_pos1.X, offset_label_pos1.Y, offset_label_pos2.X, offset_label_pos2.Y));
                    this.far_points_FN_cases.Add(far_point);

                    this.act_num_FN_tasks++;

                    if (this.act_num_FN_tasks == this.num_tasks)
                    {
                        this.reached_FN_cases = true;
                    }

                    break;

                case "NF":
                    this.modelview_matrices_NF.Add(Utility.Trans_Mat_ModelView);
                    this.projection_matrices_NF.Add(Utility.Trans_Mat_Projection);
                    this.indices_pointpairs_NF.Add(act_pair);
                    this.pixel_label_offset_pairs_NF.Add(new Vector4(offset_label_pos1.X, offset_label_pos1.Y, offset_label_pos2.X, offset_label_pos2.Y));
                    this.far_points_NF_cases.Add(far_point);

                    this.act_num_NF_tasks++;

                    if (this.act_num_NF_tasks == this.num_tasks)
                    {
                        this.reached_NF_cases = true;
                    }

                    break;

                case "FF":
                    this.modelview_matrices_FF.Add(Utility.Trans_Mat_ModelView);
                    this.projection_matrices_FF.Add(Utility.Trans_Mat_Projection);
                    this.indices_pointpairs_FF.Add(act_pair);
                    this.pixel_label_offset_pairs_FF.Add(new Vector4(offset_label_pos1.X, offset_label_pos1.Y, offset_label_pos2.X, offset_label_pos2.Y));
                    this.far_points_FF_cases.Add(far_point);

                    this.act_num_FF_tasks++;

                    if (this.act_num_FF_tasks == this.num_tasks)
                    {
                        this.reached_FF_cases = true;
                    }

                    break;

                default:
                    break;
            }
        }

        public void Combine_All_Image_Information()
        {
            this.all_modelview_matrices.Add(this.modelview_matrices_NF);
            this.all_modelview_matrices.Add(this.modelview_matrices_FF);
            this.all_modelview_matrices.Add(this.modelview_matrices_NN);
            this.all_modelview_matrices.Add(this.modelview_matrices_FN);

            this.all_projection_matrices.Add(this.projection_matrices_NF);
            this.all_projection_matrices.Add(this.projection_matrices_FF);
            this.all_projection_matrices.Add(this.projection_matrices_NN);
            this.all_projection_matrices.Add(this.projection_matrices_FN);

            this.all_indices_pointpairs.Add(this.indices_pointpairs_NF);
            this.all_indices_pointpairs.Add(this.indices_pointpairs_FF);
            this.all_indices_pointpairs.Add(this.indices_pointpairs_NN);
            this.all_indices_pointpairs.Add(this.indices_pointpairs_FN);

            this.all_pixel_label_offset_pairs.Add(this.pixel_label_offset_pairs_NF);
            this.all_pixel_label_offset_pairs.Add(this.pixel_label_offset_pairs_FF);
            this.all_pixel_label_offset_pairs.Add(this.pixel_label_offset_pairs_NN);
            this.all_pixel_label_offset_pairs.Add(this.pixel_label_offset_pairs_FN);

            this.all_far_points.Add(this.far_points_NF_cases);
            this.all_far_points.Add(this.far_points_FF_cases);
            this.all_far_points.Add(this.far_points_NN_cases);
            this.all_far_points.Add(this.far_points_FN_cases);
        }

        public List<Vector4> Get_Initial_Image_Index_List()
        {
            List<Vector4> sequence = new List<Vector4>();

            int num_images = this.num_tasks * 4;

            int condition_count = 0;
            int iterations = 0;
            int cam_count = 0;

            Vector4 image_indices;

            for (int i = 0; i < num_images; i++)
            {
                image_indices = new Vector4(this.index, cam_count, condition_count, 0);

                sequence.Add(image_indices);

                condition_count++;

                cam_count++;

                if (condition_count > 3)
                {
                    condition_count = 0;
                    iterations++;

                    cam_count = iterations;
                }

                if (cam_count > (this.num_tasks - 1))
                {
                    cam_count = 0;
                }
            }

            return sequence;
        }

        private int Get_Shortest_Condition_ListLength()
        {
            int length = this.modelview_matrices_NN.Count;

            if (this.modelview_matrices_FN.Count < length)
            {
                length = this.modelview_matrices_FN.Count;
            }

            if (this.modelview_matrices_NF.Count < length)
            {
                length = this.modelview_matrices_NF.Count;
            }

            if (this.modelview_matrices_FF.Count < length)
            {
                length = this.modelview_matrices_FF.Count;
            }

            return length;
        }

        #endregion

        #endregion
    }
}

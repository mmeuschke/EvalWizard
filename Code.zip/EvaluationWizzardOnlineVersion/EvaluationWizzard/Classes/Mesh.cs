﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EvaluationWizzard.Properties;
using OpenTK;
using OpenTK.Graphics.OpenGL;
using System.IO;

namespace EvaluationWizzard
{
    public class Mesh : RenderItem
    {
        #region - Private Variables -

        private List<Triangle> triangles;

        private List<uint> index_buffer;

        // Bounding Box
        private List<float> mesh_dimensions;
        private List<Vector3> bound_box;

        // VBO Initialization
        private enum VBONames { Pos, Norm, IndexBuffer };

        private int number_vbo = Enum.GetNames(typeof(VBONames)).Length;

        private Shader contour_shader_prog;

        private bool render_contour;

        #endregion

        #region - Constructors -

        public Mesh(List<Triangle> Triangles, List<Vector3> Positions, List<Vector3> Normals)
            : base(Settings.Default.MeshName)
        {
            this.triangles = Triangles;
            this.positions = Positions;
            this.normals = Normals;

            this.render_contour = false;

            this.Center_RenderItem();

            this.mesh_dimensions = new List<float>();

            this.bound_box = this.Determine_Bounding_Box();

            this.index_buffer = new List<uint>();

            this.vao = new uint[1];

            this.vbo = new uint[this.number_vbo];
        }

        #endregion

        #region - Properties -

        public List<Triangle> Triangles
        {
            get { return this.triangles; }
            set { this.triangles = value; }
        }

        public List<Vector3> Bounding_Box
        {
            get { return this.bound_box; }
        }

        public List<float> Dimensions
        {
            get { return this.mesh_dimensions; }
        }

        public bool Render_Contour
        {
            get { return this.render_contour; }
            set { this.render_contour = value; }
        }

        #endregion

        #region - Methods -

        #region - Vertex Processing -

        private List<Vector3> Determine_Bounding_Box()
        {
            float xmin = float.MaxValue;
            float xmax = -float.MaxValue;
            float ymin = float.MaxValue;
            float ymax = -float.MaxValue;
            float zmin = float.MaxValue;
            float zmax = -float.MaxValue;

            List<Vector3> b_box = new List<Vector3>();

            if (this.positions.Count < 1)
            {
                return b_box;
            }

            for (int i = 0; i < this.positions.Count; i++)
            {
                if (this.positions[i].X < xmin)
                {
                    xmin = this.positions[i].X;
                }
                if (this.positions[i].X > xmax)
                {
                    xmax = this.positions[i].X;
                }

                if (this.positions[i].Y < ymin)
                {
                    ymin = this.positions[i].Y;
                }
                if (this.positions[i].Y > ymax)
                {
                    ymax = this.positions[i].Y;
                }

                if (this.positions[i].Z < zmin)
                {
                    zmin = this.positions[i].Z;
                }
                if (this.positions[i].Z > zmax)
                {
                    zmax = this.positions[i].Z;
                }
            }

            this.mesh_dimensions.Add(xmin);
            this.mesh_dimensions.Add(xmax);
            this.mesh_dimensions.Add(ymin);
            this.mesh_dimensions.Add(ymax);
            this.mesh_dimensions.Add(zmin);
            this.mesh_dimensions.Add(zmax);

            b_box.Add(new Vector3(xmin, ymin, zmin));
            b_box.Add(new Vector3(xmax, ymin, zmin));
            b_box.Add(new Vector3(xmax, ymin, zmax));
            b_box.Add(new Vector3(xmin, ymin, zmax));
            b_box.Add(new Vector3(xmax, ymax, zmin));
            b_box.Add(new Vector3(xmin, ymax, zmin));
            b_box.Add(new Vector3(xmin, ymax, zmax));
            b_box.Add(new Vector3(xmax, ymax, zmax));

            return b_box;
        }

        #endregion

        #region - Rendering -

        /// <summary>
        /// Proofs if the mesh is ready to render
        /// </summary>
        public override bool Renderable()
        {
            if (this.vao == null)
            {
                return false;
            }

            if (this.shaderprog == null)
            {
                return false;
            }

            if (this.shaderprog.Prog == 0)
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// Initializes all used VBO's
        /// </summary>
        public override void SetupRender()
        {
            GL.GenVertexArrays(1, out this.vao[0]);
            GL.BindVertexArray(this.vao[0]);

            // vbo [0] = vertex position
            GL.GenBuffers(this.vbo.Length, this.vbo);
            GL.BindBuffer(BufferTarget.ArrayBuffer, this.vbo[(uint)VBONames.Pos]);
            GL.BufferData<Vector3>(BufferTarget.ArrayBuffer, (IntPtr)(this.positions.Count * Vector3.SizeInBytes), this.positions.ToArray(), BufferUsageHint.StaticDraw);

            GL.VertexAttribPointer(0, 3, VertexAttribPointerType.Float, false, 0, 0);
            GL.EnableVertexAttribArray(0);

            // vbo [1] = vertex normal
            GL.BindBuffer(BufferTarget.ArrayBuffer, this.vbo[(uint)VBONames.Norm]);
            GL.BufferData<Vector3>(BufferTarget.ArrayBuffer, (IntPtr)(this.normals.Count * Vector3.SizeInBytes), this.normals.ToArray(), BufferUsageHint.StaticDraw);

            GL.VertexAttribPointer(1, 3, VertexAttribPointerType.Float, false, 0, 0);
            GL.EnableVertexAttribArray(1);

            // vbo[2] = triangle index buffer
            this.index_buffer = this.Create_Index_Buffer(this.triangles);
            GL.BindBuffer(BufferTarget.ElementArrayBuffer, this.vbo[(uint)VBONames.IndexBuffer]);
            GL.BufferData(BufferTarget.ElementArrayBuffer, (IntPtr)(this.index_buffer.Count * sizeof(uint)), this.index_buffer.ToArray(), BufferUsageHint.StaticDraw);

            GL.BindVertexArray(0);

            // Unbind VAO
            GL.BindBuffer(BufferTarget.ArrayBuffer, 0);
            GL.BindBuffer(BufferTarget.ElementArrayBuffer, 0);

            this.Init_Contour_Shader();

            this.Init_Setup = true;

            Console.WriteLine("-> Mesh created");
        }

        /// <summary>
        /// Renders the mesh using triangles
        /// </summary>
        public override void Render()
        {
            if (!this.Renderable())
            {
                return;
            }

            GL.MatrixMode(MatrixMode.Modelview);

            GL.PushMatrix();
            {
                GL.MultMatrix(ref this.transformationMatrix);

                this.shaderprog.EnableShader();
                {
                    GL.GetFloat(GetPName.ModelviewMatrix, out Utility.Trans_Mat_ModelView);
                    GL.GetFloat(GetPName.ProjectionMatrix, out Utility.Trans_Mat_Projection);
                    GL.GetFloat(GetPName.Viewport, out Utility.Trans_Viewport);

                    GL.BindVertexArray(vao[0]);
                    GL.BindBuffer(BufferTarget.ElementArrayBuffer, this.vbo[(uint)VBONames.IndexBuffer]);
                    {
                        GL.DrawElements(PrimitiveType.Triangles, this.index_buffer.Count, DrawElementsType.UnsignedInt, IntPtr.Zero);
                    }
                    GL.BindBuffer(BufferTarget.ElementArrayBuffer, 0);
                    GL.BindVertexArray(0);
                }

                this.shaderprog.DisableShader();
            }

            GL.PopMatrix();

            this.Render_Mesh_Contour();
        }

        private void Render_Mesh_Contour()
        {
            if (this.render_contour)
            {
                GL.MatrixMode(MatrixMode.Modelview);

                GL.PushMatrix();
                {
                    GL.MultMatrix(ref this.transformationMatrix);

                    this.contour_shader_prog.EnableShader();
                    {
                        GL.GetFloat(GetPName.ModelviewMatrix, out Utility.Trans_Mat_ModelView);
                        GL.GetFloat(GetPName.ProjectionMatrix, out Utility.Trans_Mat_Projection);
                        GL.GetFloat(GetPName.Viewport, out Utility.Trans_Viewport);

                        GL.BindVertexArray(vao[0]);
                        GL.BindBuffer(BufferTarget.ElementArrayBuffer, this.vbo[(uint)VBONames.IndexBuffer]);
                        {
                            GL.DrawElements(PrimitiveType.Triangles, this.index_buffer.Count, DrawElementsType.UnsignedInt, IntPtr.Zero);
                        }
                        GL.BindBuffer(BufferTarget.ElementArrayBuffer, 0);
                        GL.BindVertexArray(0);
                    }

                    this.contour_shader_prog.DisableShader();
                }

                GL.PopMatrix();
            }
        }

        public void Init_Contour_Shader()
        {
            string shaderpath = Utility.Get_Relative_Project_Path() + Settings.Default.InitShaderPath + @"\MeshContour\";

            string[] files = Directory.GetFiles(shaderpath);

            this.contour_shader_prog = new Shader(files.ToList());
        }

        public void Translate_Mesh(Vector3 trans)
        {
            for (int i = 0; i < this.positions.Count; i++)
            {
                this.positions[i] = this.positions[i] - trans;
            }
        }

        #endregion

        #region IDisposable Member

        public override void Dispose()
        {
            base.Dispose();

            this.triangles = null;

            this.index_buffer = null;
        }

        #endregion

        #endregion
    }
}

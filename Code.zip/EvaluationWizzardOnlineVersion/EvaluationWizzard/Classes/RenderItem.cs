﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using OpenTK;
using OpenTK.Graphics.OpenGL;
using EvaluationWizzard.Properties;
using System.IO;

namespace EvaluationWizzard
{
    public abstract class RenderItem : IDisposable
    {
        #region - Private Variables -

        // object identification
        protected string name;

        protected Matrix4 transformationMatrix;

        private bool init_setup;
        private bool init_shader;

        // object attributes
        protected List<Vector3> positions;
        protected List<Vector3> normals;

        // center
        protected float meanx;
        protected float meany;
        protected float meanz;

        protected List<string> shader_pathes;
        protected Shader shaderprog;

        protected uint[] vao;
        protected uint[] vbo;

        #endregion

        #region - Constructors -

        public RenderItem(string name = "none")
        {
            this.name = name;

            this.transformationMatrix = Matrix4.Identity;

            this.init_setup = false;
            this.init_shader = false;

            this.positions = new List<Vector3>();
            this.normals = new List<Vector3>();

            this.shader_pathes = new List<string>();
        }

        #endregion

        #region - Properties -

        public string Name
        {
            get { return this.name; }
            set { this.name = value; }
        }

        public Matrix4 TransformationMatrix
        {
            get { return this.transformationMatrix; }
            set { this.transformationMatrix = value; }
        }

        public List<Vector3> Positions
        {
            get { return this.positions; }
            set { this.positions = value; }
        }

        public List<Vector3> Normals
        {
            get { return this.normals; }
            set { this.normals = value; }
        }

        public virtual Shader ShaderProg
        {
            get { return this.shaderprog; }
            set { this.shaderprog = value; }
        }

        public bool IsRenderable
        {
            get { return this.Renderable(); }
        }

        public bool Init_Setup
        {
            get { return this.init_setup; }
            set { this.init_setup = value; }
        }

        public bool Init_Shader
        {
            get { return this.init_shader; }
            set { this.init_shader = value; }
        }

        #endregion

        #region - Methods -

        #region - Rendering -
        /// <summary>
        /// Proofs if a render object is ready to render
        /// </summary>
        public abstract bool Renderable();

        /// <summary>
        /// Initializes all used VBO's
        /// </summary>
        public abstract void SetupRender();

        /// <summary>
        /// Renders the object
        /// </summary>
        public abstract void Render();

        /// <summary>
        /// Create the index buffer for correct rendering order
        /// </summary>
        public virtual List<uint> Create_Index_Buffer(List<Triangle> triangles)
        {
            List<uint> index_buffer = new List<uint>();

            foreach (Triangle tri in triangles)
            {
                index_buffer.Add((uint)tri.VIndex_0);
                index_buffer.Add((uint)tri.VIndex_1);
                index_buffer.Add((uint)tri.VIndex_2);
            }

            return index_buffer;
        }

        /// <summary>
        /// Initialize item for rendering
        /// </summary>
        public void Initialize_Render_Item(List<string> shader_pathes)
        {
            if (this != null)
            {
                if (!this.init_shader)
                {
                    this.ShaderProg = new Shader(shader_pathes);

                    this.init_shader = true;
                }

                if (this.Renderable() && !this.init_setup)
                {
                    this.Clear_Rendering_Members();
                }

                if (!this.init_setup)
                {
                    this.SetupRender();
                }
            }
        }

        public void Initialize_Render_Item()
        {
            if (this != null)
            {
                if (!this.init_shader)
                {
                    this.shader_pathes = this.GetShadersfromXML();

                    this.ShaderProg = new Shader(this.shader_pathes);

                    this.init_shader = true;
                }

                if (this.Renderable())
                {
                    this.Clear_Rendering_Members();
                }

                if (!this.init_setup)
                {
                    this.SetupRender();
                }
            }
        }

        /// <summary>
        /// Reads names of shader files used for current render item from a XML-file
        /// </summary>
        public virtual List<string> GetShadersfromXML()
        {
            List<string> shaderpathes = new List<string>();

            string shaderpath = Utility.Get_Relative_Project_Path() + Settings.Default.InitShaderPath + this.name + @"\";

            XmlDocument doc = new XmlDocument();

            doc.Load(Utility.Get_Relative_Project_Path() + Settings.Default.InitXMLPath + this.name + ".xml");

            XmlNode filesNode = doc.SelectSingleNode("/" + this.name + "/Shaderfiles");

            if (filesNode.HasChildNodes)
            {
                for (int i = 0; i < filesNode.ChildNodes.Count; i++)
                {
                    shaderpathes.Add(Path.Combine(shaderpath, filesNode.ChildNodes[i].Attributes["Name"].Value));
                }
            }

            return shaderpathes;
        }

        public virtual void Update_Render_Item_Shaders(List<string> shader_pathes)
        {
            if (this != null)
            {
                this.ShaderProg = new Shader(shader_pathes);
            }
        }

        public virtual void Update_Render_Item_Shaders()
        {
            if (this != null)
            {
                this.ShaderProg = new Shader(this.GetShadersfromXML());
            }
        }

        /// <summary>
        /// Update content of render item after scalar field data for rendering has been changed
        /// </summary>
        public void Update_Render_Item()
        {
            if (this != null)
            {
                if (this.Renderable())
                {
                    this.Clear_Rendering_Members();
                }

                this.SetupRender();
            }
        }

        #endregion

        #region - Data Processing -

        /// <summary>
        /// Calculates a center point from a given list of positions
        /// </summary>
        public virtual Vector3 Calculate_Center()
        {
            Vector3 center;

            this.meanx = 0;
            this.meany = 0;
            this.meanz = 0;

            foreach (Vector3 point in this.positions)
            {
                this.meanx = this.meanx + point.X;
                this.meany = this.meany + point.Y;
                this.meanz = this.meanz + point.Z;
            }

            this.meanx = this.meanx / this.positions.Count;
            this.meany = this.meany / this.positions.Count;
            this.meanz = this.meanz / this.positions.Count;

            center = new Vector3(this.meanx, this.meany, this.meanz);

            return center;
        }

        /// <summary>
        /// Calculates a center point from a given list of positions
        /// </summary>
        public virtual Vector4 Calculate_Center(List<Vector4> vertices)
        {
            Vector4 center;

            float mean_x = 0;
            float mean_y = 0;
            float mean_z = 0;
            float mean_w = 0;

            foreach (Vector4 point in vertices)
            {
                mean_x = mean_x + point.X;
                mean_y = mean_y + point.Y;
                mean_z = mean_z + point.Z;
                mean_w = mean_w + point.W;
            }

            mean_x = mean_x / vertices.Count;
            mean_y = mean_y / vertices.Count;
            mean_z = mean_z / vertices.Count;
            mean_w = mean_w / vertices.Count;

            center = new Vector4(mean_x, mean_y, mean_z, mean_w);

            return center;
        }

        public virtual List<Vector4> Determine_Bounding_Box(List<Vector4> vertices)
        {
            float min_x = float.MaxValue;
            float max_x = -float.MaxValue;
            float min_y = float.MaxValue;
            float max_y = -float.MaxValue;
            float min_z = float.MaxValue;
            float max_z = -float.MaxValue;

            List<Vector4> b_box = new List<Vector4>();

            if (vertices.Count < 1)
            {
                return b_box;
            }

            for (int i = 0; i < vertices.Count; i++)
            {
                if (vertices[i].X < min_x)
                {
                    min_x = vertices[i].X;
                }
                if (vertices[i].X > max_x)
                {
                    max_x = vertices[i].X;
                }

                if (vertices[i].Y < min_y)
                {
                    min_y = vertices[i].Y;
                }
                if (vertices[i].Y > max_y)
                {
                    max_y = vertices[i].Y;
                }

                if (vertices[i].Z < min_z)
                {
                    min_z = vertices[i].Z;
                }
                if (vertices[i].Z > max_z)
                {
                    max_z = vertices[i].Z;
                }
            }

            b_box.Add(new Vector4(min_x, min_y, min_z,1));
            b_box.Add(new Vector4(max_x, min_y, min_z,1));
            b_box.Add(new Vector4(max_x, min_y, max_z,1));
            b_box.Add(new Vector4(min_x, min_y, max_z,1));
            b_box.Add(new Vector4(max_x, max_y, min_z,1));
            b_box.Add(new Vector4(min_x, max_y, min_z,1));
            b_box.Add(new Vector4(min_x, max_y, max_z,1));
            b_box.Add(new Vector4(max_x, max_y, max_z,1));

            return b_box;
        }

        /// <summary>
        /// Centers object around a given center point
        /// </summary>
        public virtual void Center_RenderItem()
        {
            Vector3 center = this.Calculate_Center();

            for (int i = 0; i < this.positions.Count; i++)
            {
                this.positions[i] = this.positions[i] - center;
            }
        }

        #endregion

        #region - Data Export -

        public virtual void Export_to_OBJ(string path)
        {
            Console.WriteLine("Export renderitem");
        }

        #endregion

        #region - Clear -

        public virtual void Dispose()
        {
            if (this.vbo != null)
            {
                GL.DeleteBuffers(this.vbo.Length, this.vbo);
            }

            if (this.vao != null)
            {
                for (int i = 0; i < this.vao.Length; i++)
                {
                    GL.DeleteVertexArray(this.vao[i]);
                }
            }

            this.vao = null;

            this.shaderprog = null;

            this.name = "none";

            this.init_setup = false;
            this.init_shader = false;

            this.positions = null;

            this.normals = null;

            Console.WriteLine("-> Render Item:\t\tdisposed");
        }

        /// <summary>
        /// Clear buffer objects for redraw
        /// </summary>
        public virtual void Clear_Rendering_Members()
        {
            if (this.vbo != null)
            {
                GL.DeleteBuffers(this.vbo.Length, this.vbo);
            }

            if (this.vao != null)
            {
                for (int i = 0; i < this.vao.Length; i++)
                {
                    GL.DeleteVertexArray(this.vao[i]);
                }
            }
        }

        #endregion

        #endregion
    }
}

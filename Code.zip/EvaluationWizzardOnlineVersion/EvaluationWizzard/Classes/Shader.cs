﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenTK;
using OpenTK.Graphics.OpenGL;
using System.IO;

namespace EvaluationWizzard
{
    public class Shader : IDisposable
    {
        #region - Private Variables -

        private int prog;

        private List<string> shader_pathes;

        // Standard locs
        private int pr_matrix_loc;
        private int mv_matrix_loc;
        private int viewport_loc;
        private int look_at_loc;

        // Shading locs
        private int clipping_range_loc;

        #endregion

        #region - Constructors -

        public Shader(List<string> pathes)
        {
            this.shader_pathes = pathes;

            this.SetupProgram();
        }

        #endregion

        #region - Properties -

        public int Prog
        {
            get { return this.prog; }
            set { this.prog = value; }
        }

        #endregion

        #region - Methods -

        private static void SetupShader(string path, ref int prog)
        {
            int shader = 0;

            StreamReader shader_reader = new StreamReader(path);

            string shader_source = shader_reader.ReadToEnd();

            shader_reader.Close();

            if (path.EndsWith(".vert"))
            {
                shader = GL.CreateShader(ShaderType.VertexShader);
            }
            else if (path.EndsWith(".tesc"))
            {
                shader = GL.CreateShader(ShaderType.TessControlShader);
            }
            else if (path.EndsWith(".tese"))
            {
                shader = GL.CreateShader(ShaderType.TessEvaluationShader);
            }
            else if (path.EndsWith(".geom"))
            {
                shader = GL.CreateShader(ShaderType.GeometryShader);
            }
            else if (path.EndsWith(".frag"))
            {
                shader = GL.CreateShader(ShaderType.FragmentShader);
            }
            else if (path.EndsWith(".comp"))
            {
                shader = GL.CreateShader(ShaderType.ComputeShader);
            }

            if (shader == 0)
            {
                Console.WriteLine("## Shader:\t\t\tUnsupported Shader Type\n");

                return;
            }

            GL.ShaderSource(shader, shader_source);
            GL.CompileShader(shader);

            GL.AttachShader(prog, shader);

            string log = GL.GetShaderInfoLog(shader);

            if (log.Length > 0)
            {
                Console.WriteLine("-> Shader: " + path + "\t\t\tShader Info:\n" + log);
            }

            GL.DeleteShader(shader);
        }

        private void SetupProgram()
        {
            this.prog = GL.CreateProgram();

            for (int i = 0; i < this.shader_pathes.Count; i++)
            {
                Shader.SetupShader(this.shader_pathes[i], ref this.prog);
            }

            GL.LinkProgram(this.prog);

            GL.UseProgram(this.prog);

            // Setup basic render variables
            this.Setup_Basic_Variables();

            this.Setup_Shading_Variables();

            GL.UseProgram(0);
#if DEBUG
            // DEBUG OUTPUT
            if (pr_matrix_loc != -1)
            {
                Console.WriteLine("-> Shader:\t\t\tFound: PR Matrix Uniform");
            }

            if (mv_matrix_loc != -1)
            {
                Console.WriteLine("-> Shader:\t\t\tFound: MV Matrix Uniform");
            }

            string log = GL.GetProgramInfoLog(this.prog);

            if (log.Length > 0)
            {
                Console.WriteLine("-> Shader:\t\t\tShader Prog Info:\n" + log);
            }
#endif
        }

        private void Setup_Basic_Variables()
        {
            this.pr_matrix_loc = this.GetUniformLocation("pr_matrix");
            this.mv_matrix_loc = this.GetUniformLocation("mv_matrix");
            this.viewport_loc = this.GetUniformLocation("Viewport");
            this.look_at_loc = this.GetUniformLocation("lookAt");
        }

        private void Setup_Shading_Variables()
        {
            this.clipping_range_loc = this.GetUniformLocation("clipping_range");
        }

        /// <summary>
        /// Gets a Uniform Location of the actual shader program
        /// </summary>
        /// <param name="uniformName"></param>
        /// <returns></returns>
        public int GetUniformLocation(string uniformName)
        {
            int uniformLoc = GL.GetUniformLocation(this.prog, uniformName);

            Console.WriteLine("-> Shader:\t\tUniform Location of {0} is {1}", uniformName, uniformLoc);

            return uniformLoc;
        }

        public void EnableShader()
        {
            GL.UseProgram(this.prog);

            GL.GetFloat(GetPName.ModelviewMatrix, out Utility.Mat_ModelView);
            GL.GetFloat(GetPName.ProjectionMatrix, out Utility.Mat_Projection);
            GL.GetFloat(GetPName.Viewport, out Utility.Viewport);

            GL.GetFloat(GetPName.ModelviewMatrix, Utility.MVEntries);
            Utility.Look_At_Pos = new Vector3(Utility.MVEntries[2], Utility.MVEntries[6], Utility.MVEntries[10]);

            GL.UniformMatrix4(this.mv_matrix_loc, false, ref Utility.Mat_ModelView);
            GL.UniformMatrix4(this.pr_matrix_loc, false, ref Utility.Mat_Projection);
            GL.Uniform4(this.viewport_loc, ref Utility.Viewport);

            GL.Uniform3(this.look_at_loc, ref Utility.Look_At_Pos);
            GL.Uniform2(this.clipping_range_loc, ref  Utility.DepthNearFar);
        }

        public void DisableShader()
        {
            GL.UseProgram(0);
        }

        #endregion

        #region IDisposable Member

        public void Dispose()
        {
            Console.WriteLine("-> Shader:\t\t\tdisposing (" + this.prog + ")");

            GL.DeleteProgram(this.prog);
        }

        #endregion
    }
}

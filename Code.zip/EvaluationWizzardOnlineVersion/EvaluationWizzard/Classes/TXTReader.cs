﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EvaluationWizzard
{
    public class TXTReader : Reader
    {
        #region - Private Variables -

        private List<int> indices;

        private List<string> meta_info;

        #endregion

        #region - Constructors -

        public TXTReader()
            : base("TXTReader")
        {
            this.indices = new List<int>();

            this.meta_info = new List<string>();
        }

        #endregion

        #region - Properties -

        public List<int> Indices
        {
            get { return this.indices; }
            set { this.indices = value; }
        }

        public List<string> Meta_Info
        {
            get { return this.meta_info; }
            set { this.meta_info = value; }
        }

        #endregion

        #region - Methods -

        public override bool Load(string filename)
        {
            try
            {
                if (filename.Contains("Endpoint_Indices"))
                {
                    this.Read_Indices(filename);

                    return true;
                }
                else if (filename.Contains("Meta"))
                {
                    this.Read_MetaInformation(filename);

                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("## Error on Textfile Load: " + e.ToString());

                return false;
            }
        }

        private void Read_Indices(string filename)
        {
            if (this.indices.Count > 0)
            {
                this.indices.Clear();
            }

            StreamReader file = new StreamReader(filename);

            string line;

            char[] splitChars = { ' ' };

            int val = 0;

            while (!file.EndOfStream)
            {
                line = file.ReadLine();

                string[] parameters = line.Split(splitChars, StringSplitOptions.RemoveEmptyEntries);

                if (parameters.Length > 0)
                {
                    val = int.Parse(parameters[0], Utility.NumberFormat);

                    this.indices.Add(val);
                }
            }
        }

        private void Read_MetaInformation(string filename)
        {
            if (this.meta_info.Count > 0)
            {
                this.meta_info.Clear();
            }

            StreamReader file = new StreamReader(filename);

            string line;

            while (!file.EndOfStream)
            {
                line = file.ReadLine();

                this.meta_info.Add(line);
            }
        }

        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenTK;

namespace EvaluationWizzard
{
    public class Camera
    {
        #region - Private Variables -

        private Vector3 eyep;
        private Vector3 eyep_kart;
        private Vector3 up_vec;

        private Vector3 initial_eyep;
        private Vector3 center;

        private float near_plane;
        private float far_plane;

        private Vector3 old_mouse_pos;

        #endregion

        #region - Constructors -

        public Camera(Vector3 Pos, Vector3 Center, Vector3 UpVec, float NearPlane, float FarPlane)
        {
            this.eyep = Pos;
            this.eyep_kart = Utility.ConvertToCartCoord(Pos);
            this.up_vec = UpVec;
            this.initial_eyep = Pos;
            this.center = Center;
            this.near_plane = NearPlane;
            this.far_plane = FarPlane;
            this.old_mouse_pos = Vector3.Zero;
        }

        #endregion

        #region - Properties -

        public Vector3 EyePos
        {
            get { return this.eyep; }
            set { this.eyep = value; }
        }

        public Vector3 EyePos_Kart
        {
            get { return this.eyep_kart; }
            set { this.eyep_kart = value; }
        }

        public Vector3 Up_Vector
        {
            get { return this.up_vec; }
            set { this.up_vec = value; }
        }

        public float EyePos_X
        {
            get { return this.eyep.X; }
            set { this.eyep.X = value; }
        }

        public float EyePos_Y
        {
            get { return this.eyep.Y; }
            set { this.eyep.Y = value; }
        }

        public float EyePos_Z
        {
            get { return this.eyep.Z; }
            set { this.eyep.Z = value; }
        }

        public float Near_Plane
        {
            get { return this.near_plane; }
            set { this.near_plane = value; }
        }

        public float Far_Plane
        {
            get { return this.far_plane; }
            set { this.far_plane = value; }
        }

        public Vector3 Center
        {
            get { return this.center; }
            set { this.center = value; }
        }

        public float Center_X
        {
            set { this.center.X = value; }
        }

        public float Center_Y
        {
            set { this.center.Y = value; }
        }

        public float Center_Z
        {
            set { this.center.Z = value; }
        }

        public Vector3 OldMousePos
        {
            get { return this.old_mouse_pos; }
            set { this.old_mouse_pos = value; }
        }

        #endregion

        #region - Methods -

        #endregion
    }
}

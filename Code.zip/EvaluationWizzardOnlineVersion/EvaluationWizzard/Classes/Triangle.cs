﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenTK;

namespace EvaluationWizzard
{
    public class Triangle
    {
        #region - Private Variables -

        // vertecis positions
        private Vector3 vposition_0;
        private Vector3 vposition_1;
        private Vector3 vposition_2;

        private Vector3 tri_normal;

        private List<Vector2> edges;

        private List<int> neighbor_triangle_ids;

        // vertecis index
        private int vindex_0;
        private int vindex_1;
        private int vindex_2;

        // center
        private Vector3 center;

        // normals index
        private int nindex_0;
        private int nindex_1;
        private int nindex_2;

        // texture coordinates index
        private int tindex_0;
        private int tindex_1;
        private int tindex_2;

        #endregion

        #region - Constructors -

        public Triangle()
        {
            this.vposition_0 = Vector3.Zero;
            this.vposition_1 = Vector3.Zero;
            this.vposition_2 = Vector3.Zero;

            this.vindex_0 = 0;
            this.vindex_1 = 0;
            this.vindex_2 = 0;

            this.nindex_0 = 0;
            this.nindex_1 = 0;
            this.nindex_2 = 0;

            this.tindex_0 = 0;
            this.tindex_1 = 0;
            this.tindex_2 = 0;

            this.center = Vector3.Zero;

            this.edges = new List<Vector2>();
        }

        public Triangle(int Index_V0, int Index_V1, int Index_V2,
                        int Index_N0, int Index_N1, int Index_N2,
                        int Index_T0, int Index_T1, int Index_T2,
                        Vector3 pos_0, Vector3 pos_1, Vector3 pos_2)
        {
            this.vposition_0 = pos_0;
            this.vposition_1 = pos_1;
            this.vposition_2 = pos_2;

            this.tri_normal = this.Calculate_Triangle_Normal();

            this.vindex_0 = Index_V0;
            this.vindex_1 = Index_V1;
            this.vindex_2 = Index_V2;

            this.nindex_0 = Index_N0;
            this.nindex_1 = Index_N1;
            this.nindex_2 = Index_N2;

            this.tindex_0 = Index_T0;
            this.tindex_1 = Index_T1;
            this.tindex_2 = Index_T2;

            this.center = (this.vposition_0 + this.vposition_1 + this.vposition_2) / 3.0f;

            this.edges = this.Get_Edges();

            this.neighbor_triangle_ids = new List<int>();
        }

        #endregion

        #region - Properties -

        public int VIndex_0
        {
            get { return this.vindex_0; }
            set { this.vindex_0 = value; }
        }

        public int VIndex_1
        {
            get { return this.vindex_1; }
            set { this.vindex_1 = value; }
        }

        public int VIndex_2
        {
            get { return this.vindex_2; }
            set { this.vindex_2 = value; }
        }

        public Vector3 VPosition_0
        {
            get { return this.vposition_0; }
            set { this.vposition_0 = value; }
        }

        public Vector3 VPosition_1
        {
            get { return this.vposition_1; }
            set { this.vposition_1 = value; }
        }

        public Vector3 VPosition_2
        {
            get { return this.vposition_2; }
            set { this.vposition_2 = value; }
        }

        public Vector3 Tri_Normal
        {
            get { return this.tri_normal; }
            set { this.tri_normal = value; }
        }

        public Vector3 Center
        {
            get { return this.center; }
            set { this.center = value; }
        }

        public int NIndex_0
        {
            get { return this.nindex_0; }
            set { this.nindex_0 = value; }
        }

        public int NIndex_1
        {
            get { return this.nindex_1; }
            set { this.nindex_1 = value; }
        }

        public int NIndex_2
        {
            get { return this.nindex_2; }
            set { this.nindex_2 = value; }
        }

        public int TIndex_0
        {
            get { return this.tindex_0; }
            set { this.tindex_0 = value; }
        }

        public int TIndex_1
        {
            get { return this.tindex_1; }
            set { this.tindex_1 = value; }
        }

        public int TIndex_2
        {
            get { return this.tindex_2; }
            set { this.tindex_2 = value; }
        }

        public List<Vector2> Edges
        {
            get { return this.edges; }
            set { this.edges = value; }
        }

        public List<int> Neighbor_Triangle_IDs
        {
            get { return this.neighbor_triangle_ids; }
            set { this.neighbor_triangle_ids = value; }
        }

        #endregion

        #region - Methods -

        public bool Contain_Index(int index)
        {
            if (this.vindex_0 == index || this.vindex_1 == index || this.vindex_2 == index)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public List<int> Return_Subset_Indices_as_List(int index)
        {
            List<int> indices = new List<int>();

            if (this.vindex_0 == index || this.vindex_1 == index || this.vindex_2 == index)
            {
                if (this.vindex_0 != index)
                {
                    indices.Add(vindex_0);
                }

                if (this.vindex_1 != index)
                {
                    indices.Add(vindex_1);
                }

                if (this.vindex_2 != index)
                {
                    indices.Add(vindex_2);
                }
            }

            return indices;
        }

        public List<Vector2> Get_Edges()
        {
            List<Vector2> edges = new List<Vector2>();

            edges.Add(new Vector2(this.vindex_0, this.vindex_1));
            edges.Add(new Vector2(this.vindex_0, this.vindex_2));
            edges.Add(new Vector2(this.vindex_1, this.vindex_2));

            return edges;
        }

        public bool Is_Adjacent(Triangle tri)
        {
            int counter = 0;

            int[] indices = new int[] { this.vindex_0, this.vindex_1, this.vindex_2 };

            if (indices.Contains(tri.vindex_0))
            {
                counter++;
            }

            if (indices.Contains(tri.vindex_1))
            {
                counter++;
            }

            if (indices.Contains(tri.vindex_2))
            {
                counter++;
            }

            if (counter > 1)
            {
                return true;
            }

            return false;
        }

        public List<int> Get_Point_Ids()
        {
            List<int> ids = new List<int>();
            ids.Add(this.vindex_0);
            ids.Add(this.vindex_1);
            ids.Add(this.vindex_2);

            return ids;
        }

        private Vector3 Calculate_Triangle_Normal()
        {
            Vector3 edge_1 = Vector3.Zero;
            Vector3 edge_2 = Vector3.Zero;

            Vector3 normal = Vector3.Zero;

            edge_1 = (vposition_1 - vposition_0);
            edge_2 = (vposition_2 - vposition_0);

            normal = Vector3.Cross(edge_1, edge_2);

            normal.Normalize();

            return normal;
        }

        #endregion
    }
}

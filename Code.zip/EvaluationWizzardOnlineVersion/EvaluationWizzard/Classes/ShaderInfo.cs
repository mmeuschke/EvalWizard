﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EvaluationWizzard
{
    public class ShaderInfo
    {
        #region - Private Variables -

        private string name;

        private bool vertCheck;
        private bool geomCheck;
        private bool fragCheck;

        private List<string> shaders_files;
        private List<string> glyph_shaders_files;

        private bool use_glyph_shaders;

        private bool render_contour;

        #endregion

        #region - Constructors -

        public ShaderInfo(string Name)
        {
            this.name = Name;

            this.vertCheck = false;
            this.geomCheck = false;
            this.fragCheck = false;

            this.shaders_files = new List<string>();
            this.glyph_shaders_files = new List<string>();

            this.use_glyph_shaders = false;
            this.render_contour = false;
        }

        #endregion

        #region - Properties -

        public string Name
        {
            get { return this.name; }
            set { this.name = value; }
        }

        public List<string> Shader_Files
        {
            get { return this.shaders_files; }
            set { this.shaders_files = value; }
        }

        public List<string> Glyph_Shader_Files
        {
            get { return this.glyph_shaders_files; }
            set { this.glyph_shaders_files = value; }
        }

        public bool Use_Glyphs
        {
            get { return this.use_glyph_shaders; }
            set { this.use_glyph_shaders = value; }
        }

        public bool Render_Contour
        {
            get { return this.render_contour; }
            set { this.render_contour = value; }
        }

        public bool Vert_Check
        {
            get { return this.vertCheck; }
            set { this.vertCheck = value; }
        }

        public bool Geom_Check
        {
            get { return this.geomCheck; }
            set { this.geomCheck = value; }
        }

        public bool Frag_Check
        {
            get { return this.fragCheck; }
            set { this.fragCheck = value; }
        }

        #endregion

        #region - Methods -

        public bool Check_Shader()
        {
            for (int i = 0; i < this.shaders_files.Count; i++)
            {
                if (this.shaders_files[i].EndsWith(".vert"))
                {
                    this.vertCheck = true;
                }
                else if (this.shaders_files[i].EndsWith(".geom"))
                {
                    this.geomCheck = true;
                }
                else if (this.shaders_files[i].EndsWith(".frag"))
                {
                    this.fragCheck = true;
                }
                else
                {
                    MessageBox.Show("Error: Shader " + this.name + " contains non shader files.", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    return false;
                }
            }

            for (int i = 0; i < this.glyph_shaders_files.Count; i++)
            {
                if (this.glyph_shaders_files[i].EndsWith(".vert") || this.glyph_shaders_files[i].EndsWith(".geom") || this.glyph_shaders_files[i].EndsWith(".frag"))
                {
                    continue;
                }
                else
                {
                    MessageBox.Show("Error: Shader " + this.name + " contains non shader files.", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    return false;
                }
            }

            if (!(this.vertCheck) || !(this.fragCheck))
            {
                MessageBox.Show("WARNING: shader could not be loaded", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);

                return false;
            }
            else
            {
                return true;
            }
        }

        #endregion
    }
}

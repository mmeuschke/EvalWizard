﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenTK;

namespace EvaluationWizzard
{
    public class Utility
    {
        #region - Private Variables -

        // number controling
        public static readonly NumberFormatInfo NumberFormat = (new CultureInfo("en-US")).NumberFormat;

        // Standard Rendering Matrices 
        public static Matrix4 Mat_ModelView;
        public static Matrix4 Mat_Projection;
        public static Vector4 Viewport;

        public static float[] MVEntries = new float[16];
        public static Vector3 Look_At_Pos;

        public static Matrix4 Trans_Mat_ModelView;
        public static Matrix4 Trans_Mat_Projection;
        public static Vector4 Trans_Viewport;

        // Shading Parameters

        public static Vector2 DepthNearFar = new Vector2(0,1);

        #endregion

        #region - Constructors -

        #endregion

        #region - Properties -

        #endregion

        #region - Methods -

        public static Vector3 ConvertToCartCoord(Vector3 polar)
        {
            Vector3 cartcoord = Vector3.Zero;

            cartcoord.X = polar.X * (float)Math.Sin(polar.Y) * (float)Math.Sin(polar.Z);

            cartcoord.Y = polar.X * (float)Math.Cos(polar.Y);

            cartcoord.Z = polar.X * (float)Math.Sin(polar.Y) * (float)Math.Cos(polar.Z);

            return cartcoord;
        }

        public static Vector3 ConvertToPolarCoord(Vector3 kart)
        {
            Vector3 polar_coords = Vector3.Zero;

            polar_coords.X = (float)Math.Sqrt(Math.Pow(kart.X, 2) + Math.Pow(kart.Y, 2) + Math.Pow(kart.Z, 2));

            polar_coords.Y = (float)Math.Acos((kart.Y / polar_coords.X));

            polar_coords.Z = (float)Math.Atan2(kart.X, kart.Z);

            return polar_coords;
        }

        public static Vector2 ConvertToPolarCoord(Vector2 kart)
        {
            Vector2 polar_coords = Vector2.Zero;

            float radius = (float)Math.Sqrt(Math.Pow(kart.X, 2) + Math.Pow(kart.Y, 2));

            double phihelp = Math.Acos(Math.Abs(kart.X) / radius);

            double phi = 0;

            if (kart.Y > 0.0)
            {
                phi = Math.Acos(kart.X / radius);
            }
            else if (kart.X < 0.0 && kart.Y > 0.0)
            {
                phi = Math.Acos(kart.X / radius);
            }
            else if (kart.X < 0.0 && kart.Y < 0.0)
            {
                phi = Math.PI + phihelp;
            }
            else
            {
                phi = 2.0 * Math.PI - phihelp;
            }

            polar_coords.X = radius;
            polar_coords.Y = (float)phi;

            return polar_coords;
        }

        public static Vector3 Vector_Matrix_Multiplikation(Matrix3 m, Vector3 v)
        {
            Vector3 result = new Vector3();

            //result.X = m.M11 * v.X + m.M21 * v.Y + m.M31 * v.Z;
            //result.Y = m.M12 * v.X + m.M22 * v.Y + m.M32 * v.Z;
            //result.Z = m.M13 * v.X + m.M23 * v.Y + m.M33 * v.Z;

            result.X = m.M11 * v.X + m.M12 * v.Y + m.M13 * v.Z;
            result.Y = m.M21 * v.X + m.M22 * v.Y + m.M23 * v.Z;
            result.Z = m.M31 * v.X + m.M32 * v.Y + m.M33 * v.Z;

            return result;
        }

        public static Vector4 Vector_Matrix_Multiplikation(Matrix4 m, Vector4 v)
        {
            Vector4 result = new Vector4();

            //result.X = m.M11 * v.X + m.M21 * v.Y + m.M31 * v.Z + m.M41 * v.W;
            //result.Y = m.M12 * v.X + m.M22 * v.Y + m.M32 * v.Z + m.M42 * v.W;
            //result.Z = m.M13 * v.X + m.M23 * v.Y + m.M33 * v.Z + m.M43 * v.W;
            //result.W = m.M14 * v.X + m.M24 * v.Y + m.M34 * v.Z + m.M44 * v.W;

            result.X = m.M11 * v.X + m.M12 * v.Y + m.M13 * v.Z + m.M14 * v.W;
            result.Y = m.M21 * v.X + m.M22 * v.Y + m.M23 * v.Z + m.M24 * v.W;
            result.Z = m.M31 * v.X + m.M32 * v.Y + m.M33 * v.Z + m.M34 * v.W;
            result.W = m.M41 * v.X + m.M42 * v.Y + m.M43 * v.Z + m.M44 * v.W;

            return result;
        }

        public static Matrix4 Get_Rotation_Matrix(Vector3 rot_axis, float angle)
        {
            float m11, m12, m13, m21, m22, m23, m31, m32, m33;

            m11 = (float)(Math.Pow(rot_axis.X, 2) * (1.0 - Math.Cos(angle)) + Math.Cos(angle));
            m12 = (float)((rot_axis.X * rot_axis.Y) * (1.0 - Math.Cos(angle)) - (rot_axis.Z * Math.Sin(angle)));
            m13 = (float)((rot_axis.X * rot_axis.Z) * (1.0 - Math.Cos(angle)) + (rot_axis.Y * Math.Sin(angle)));

            m21 = (float)((rot_axis.Y * rot_axis.X) * (1.0 - Math.Cos(angle)) + (rot_axis.Z * Math.Sin(angle)));
            m22 = (float)(Math.Pow(rot_axis.Y, 2) * (1.0 - Math.Cos(angle)) + Math.Cos(angle));
            m23 = (float)((rot_axis.Y * rot_axis.Z) * (1.0 - Math.Cos(angle)) - (rot_axis.X * Math.Sin(angle)));

            m31 = (float)((rot_axis.Z * rot_axis.X) * (1.0 - Math.Cos(angle)) - (rot_axis.Y * Math.Sin(angle)));
            m32 = (float)((rot_axis.Z * rot_axis.Y) * (1.0 - Math.Cos(angle)) + (rot_axis.X * Math.Sin(angle)));
            m33 = (float)(Math.Pow(rot_axis.Z, 2) * (1.0 - Math.Cos(angle)) + Math.Cos(angle));

            Vector4 row_0 = new Vector4(m11, m21, m31, 0);
            Vector4 row_1 = new Vector4(m12, m22, m32, 0);
            Vector4 row_2 = new Vector4(m13, m23, m33, 0);
            Vector4 row_3 = new Vector4(0, 0, 0, 1);

            Matrix4 rot_mat = new Matrix4(row_0, row_1, row_2, row_3);

            return rot_mat;
        }

        public static float Degrees_to_Radians(float angle_degrees)
        {
            float angle_rad = (float)(2.0 * Math.PI / 360.0) * angle_degrees;

            return angle_rad;
        }

        /// <summary>
        /// Get relative project path up to the first path level
        /// </summary>
        public static string Get_Relative_Project_Path()
        {
            string projectPath = Environment.CurrentDirectory;

            string projectname = "EvaluationWizzard";

            string[] direc = projectPath.Split('\\');

            string path = direc[0];

            for (int i = 1; i < direc.Length; i++)
            {
                if (direc[i] == projectname)
                {
                    path += @"\" + direc[i];

                    break;
                }
                else
                {
                    path += @"\" + direc[i];
                }
            }

            return path;
        }

        /// <summary>
        /// Calculates the quantil of a given percentage value p for an ordered list of values
        /// </summary>
        public static float GetQuantile(List<float> list, float p)
        {
            float quantilValue = Calculate_Quantile(list, p);

            return quantilValue;
        }

        /// <summary>
        /// Calculates the quantil of a given percentage value quantile for an ordered list of values
        /// </summary>
        private static float Calculate_Quantile(List<float> list, float quantile)
        {
            float result;

            if (quantile >= 1.0f)
            {
                result = Utility.Calculate_Quantile(list, 0.999999f);

                return result;
            }

            if (quantile <= 0.0f)
            {
                return 0.0f;
            }

            // Get roughly the index
            float index = quantile * list.Count();

            // Get the remainder of that index value if exists
            float remainder = index % 1;

            int indexnp;
            int indexnp1;

            if (remainder.Equals(0))
            {
                // Get the integer value of that index
                index = (float)Math.Floor(index) - 1;

                indexnp = (int)index;
                indexnp1 = (int)index + 1;

                result = 0.5f * (list.ElementAt(indexnp) + list.ElementAt(indexnp1));
            }
            else
            {
                index = (float)Math.Ceiling(index) - 1;

                result = list.ElementAt((int)index);
            }

            return result;
        }

        public static void Dispose()
        {
            Utility.Mat_ModelView = Matrix4.Identity;
            Utility.Mat_Projection = Matrix4.Identity;
            Utility.Viewport = Vector4.UnitX;

            Utility.MVEntries = new float[16];
            Utility.Look_At_Pos = Vector3.Zero;

            Utility.Trans_Mat_ModelView = Matrix4.Identity;
            Utility.Trans_Mat_Projection = Matrix4.Identity;
            Utility.Trans_Viewport = Vector4.Zero;

            Console.WriteLine("-> Utility:\t\tdisposed");
        }

        #endregion
    }
}

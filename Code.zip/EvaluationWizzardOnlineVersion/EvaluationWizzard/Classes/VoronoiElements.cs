﻿using System;
using System.Collections.Generic;

namespace VoronoiObject
{
    public class Point
    {
        #region - Private Variables -

        public double x, y;

        #endregion

        #region - Constructors -

        public Point()
        {
        }

        #endregion

        #region - Properties -

        #endregion

        #region - Methods -

        public void setPoint(double x, double y)
        {
            this.x = x;
            this.y = y;
        }

        #endregion
    }
	
	// use for sites and vertecies
	public class Site
	{
        #region - Private Variables -

        public Point coord;
        public int sitenbr;

        #endregion

        #region - Constructors -

        public Site()
        {
            coord = new Point();
        }

        #endregion

        #region - Properties -

        #endregion

        #region - Methods -

        #endregion
    }
	
	public class Edge
    {
        #region - Private Variables -

        public double a = 0, b = 0, c = 0;
        public Site[] ep;
        public Site[] reg;
        public int edgenbr;

        #endregion

        #region - Constructors -

        public Edge()
        {
            ep = new Site[2];
            reg = new Site[2];
        }

        #endregion

        #region - Properties -

        #endregion

        #region - Methods -

        #endregion
	}
	
	public class Halfedge
    {
        #region - Private Variables -

        public Halfedge ELleft, ELright;
        public Edge ELedge;
        public bool deleted;
        public int ELpm;
        public Site vertex;
        public double ystar;
        public Halfedge PQnext;

        #endregion

        #region - Constructors -

        public Halfedge()
        {
            PQnext = null;
        }

        #endregion

        #region - Properties -

        #endregion

        #region - Methods -

        #endregion
	}
	
	public class GraphEdge
    {
        #region - Private Variables -

        public double x1, y1, x2, y2;
        public int site1, site2;

        #endregion

        #region - Constructors -

        #endregion

        #region - Properties -

        #endregion

        #region - Methods -

        #endregion
	}
	
	public class SiteSorterYX : IComparer<Site>
    {
        #region - Private Variables -

        #endregion

        #region - Constructors -

        #endregion

        #region - Properties -

        #endregion

        #region - Methods -

        public int Compare(Site p1, Site p2)
        {
            Point s1 = p1.coord;
            Point s2 = p2.coord;
            if (s1.y < s2.y) return -1;
            if (s1.y > s2.y) return 1;
            if (s1.x < s2.x) return -1;
            if (s1.x > s2.x) return 1;

            return 0;
        }
        #endregion
	}
}

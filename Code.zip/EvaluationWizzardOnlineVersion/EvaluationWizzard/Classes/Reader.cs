﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenTK;

namespace EvaluationWizzard
{
    public abstract class Reader : IDisposable
    {
        #region - Private Variables -

        protected string name;

        protected List<Vector3> positions;
        protected List<Vector3> normals;
        protected List<Vector3> texturecoords;

        protected List<Triangle> triangles;

        #endregion

        #region - Constructors -

        public Reader(string name = "none")
        {
            this.name = name;

            this.positions = new List<Vector3>();
            this.normals = new List<Vector3>();

            this.triangles = new List<Triangle>();

            Console.WriteLine("-> Reader:\t\tReader Created");
        }

        #endregion

        #region - Properties -

        public List<Vector3> Positions
        {
            get { return this.positions; }
            set { this.positions = value; }
        }

        public List<Vector3> Normals
        {
            get { return this.normals; }
            set { this.normals = value; }
        }

        public List<Vector3> TexureCoords
        {
            get { return this.texturecoords; }
            set { this.texturecoords = value; }
        }

        public List<Triangle> Triangles
        {
            get { return this.triangles; }
            set { this.triangles = value; }
        }

        #endregion

        #region - Methods -

        public abstract bool Load(string filename);

        public virtual void Calculate_Triangle_Normals_per_Vertex()
        {
            Vector3 edge_1 = Vector3.Zero;
            Vector3 edge_2 = Vector3.Zero;

            Vector4 normal = Vector4.Zero;

            List<Vector4> vertex_normals = new List<Vector4>();

            for (int i = 0; i < this.positions.Count; i++)
            {
                vertex_normals.Add(Vector4.Zero);
            }

            float tri_area = 0;

            foreach (Triangle tri in this.Triangles)
            {
                edge_1 = (this.positions[tri.VIndex_1] - this.positions[tri.VIndex_0]);
                edge_2 = (this.positions[tri.VIndex_2] - this.positions[tri.VIndex_0]);

                normal.Xyz = Vector3.Cross(edge_1, edge_2);

                tri_area = normal.Xyz.Length;

                normal.W = tri_area;

                vertex_normals[tri.VIndex_0] += normal;
                vertex_normals[tri.VIndex_1] += normal;
                vertex_normals[tri.VIndex_2] += normal;
            }

            Vector4 new_norm;

            for (int j = 0; j < vertex_normals.Count; j++)
            {
                if (vertex_normals[j].W > 0)
                {
                    new_norm = new Vector4((vertex_normals[j].Xyz / vertex_normals[j].W), 1);
                }
                else
                {
                    new_norm = new Vector4(vertex_normals[j].Xyz, 1);
                }


                if (new_norm.Xyz != Vector3.Zero)
                {
                    this.normals.Add(new Vector3(new_norm.Xyz.Normalized()));
                }
                else
                {
                    this.normals.Add(new Vector3(new_norm.Xyz));
                }
            }
        }

        public virtual void Dispose()
        {
            this.positions = null;
            this.normals = null;
            this.texturecoords = null;
            this.triangles = null;
        }

        #endregion
    }
}

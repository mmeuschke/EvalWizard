﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenTK;

namespace EvaluationWizzard
{
    public class OBJReader : Reader
    {
        #region - Private Variables -

        #endregion

        #region - Constructors -

        public OBJReader()
            : base("OBJReader")
        {
        }

        #endregion

        #region - Properties -

        #endregion

        #region - Methods -

        public override bool Load(string filename)
        {
            try
            {
                this.Load_Data_Item(filename);

                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// Loads all standard elements of an obj-File
        /// </summary>
        private void Load_Data_Item(string filename)
        {
            StreamReader file = new StreamReader(filename);

            string line;

            char[] splitChars = { ' ' };

            float v1 = 0;
            float v2 = 0;
            float v3 = 0;

            List<Vector3> points = new List<Vector3>();
            List<Vector3> normals = new List<Vector3>();
            List<Vector3> texcods = new List<Vector3>();

            while (!file.EndOfStream)
            {
                line = file.ReadLine();

                string[] parameters = line.Split(splitChars, StringSplitOptions.RemoveEmptyEntries);

                if (line.StartsWith("v ")) // Vertex
                {
                    v1 = float.Parse(parameters[1], Utility.NumberFormat);
                    v2 = float.Parse(parameters[2], Utility.NumberFormat);
                    v3 = float.Parse(parameters[3], Utility.NumberFormat);

                    points.Add(new Vector3(v1, v2, v3));
                }
                else if (line.StartsWith("vt ")) // TexCoord
                {
                    if (parameters.Length == 3) // 2D Texture Coords
                    {
                        v1 = float.Parse(parameters[1], Utility.NumberFormat);
                        v2 = float.Parse(parameters[2], Utility.NumberFormat);
                        v3 = 0;
                        texcods.Add(new Vector3(v1, v2, v3));
                    }
                    else // 3D Texture Coords
                    {
                        v1 = float.Parse(parameters[1], Utility.NumberFormat);
                        v2 = float.Parse(parameters[2], Utility.NumberFormat);
                        v3 = float.Parse(parameters[3], Utility.NumberFormat);
                        texcods.Add(new Vector3(v1, v2, v3));
                    }
                }

                else if (line.StartsWith("vn "))  // Normal
                {
                    v1 = float.Parse(parameters[1], Utility.NumberFormat);
                    v2 = float.Parse(parameters[2], Utility.NumberFormat);
                    v3 = float.Parse(parameters[3], Utility.NumberFormat);
                    normals.Add(new Vector3(v1, v2, v3));
                }
                else if (line.StartsWith("f ")) // Face
                {
                    // distinction between normal obj standard and matlab obj files
                    // normal obj standard 
                    if (line.Contains('/'))
                    {
                        string[] singleparameters;
                        List<string> attributes = new List<string>();

                        foreach (string item in parameters)
                        {
                            singleparameters = item.Split('/');

                            foreach (string singlevalue in singleparameters)
                            {
                                attributes.Add(singlevalue);
                            }
                        }

                        this.Generate_Face_Object(attributes.ToArray());
                    }
                    else
                    {
                        //matlab obj files
                        this.Triangles.Add(Get_MatlabObj_Triangle(parameters));
                    }
                }
            }

            file.Close();

            if (points.Count > 0)
            {
                this.positions = points;
            }

            if (normals.Count > 0)
            {
                this.normals = normals;
            }

            if (texcods.Count > 0)
            {
                this.texturecoords = texcods;
            }

            if (normals.Count < 1 && this.triangles.Count != 0)
            {
                this.Calculate_Triangle_Normals_per_Vertex();
            }
        }

        private void Generate_Face_Object(string[] parameters)
        {
            if (parameters.Length < 12) // triangles
            {
                this.triangles.Add(this.Get_StandardObj_Triangle(parameters));
            }
            else // quads
            {
                List<Triangle> tris = this.Get_Triangles_from_Quad(parameters);

                this.triangles.Add(tris[0]);
                this.triangles.Add(tris[1]);
            }
        }

        private Triangle Get_StandardObj_Triangle(string[] parameters)
        {
            Triangle tri = new Triangle();

            tri.VIndex_0 = int.Parse(parameters[1]) - 1;
            tri.VIndex_1 = int.Parse(parameters[4]) - 1;
            tri.VIndex_2 = int.Parse(parameters[7]) - 1;

            tri.TIndex_0 = tri.VIndex_0;
            tri.TIndex_1 = tri.VIndex_1;
            tri.TIndex_2 = tri.VIndex_2;

            tri.NIndex_0 = int.Parse(parameters[3]) - 1;
            tri.NIndex_1 = int.Parse(parameters[6]) - 1;
            tri.NIndex_2 = int.Parse(parameters[9]) - 1;

            return tri;
        }

        private Triangle Get_MatlabObj_Triangle(string[] parameters)
        {
            Triangle tri = new Triangle();

            tri.VIndex_0 = int.Parse(parameters[1]) - 1;
            tri.VIndex_1 = int.Parse(parameters[2]) - 1;
            tri.VIndex_2 = int.Parse(parameters[3]) - 1;

            tri.TIndex_0 = tri.VIndex_0;
            tri.TIndex_1 = tri.VIndex_1;
            tri.TIndex_2 = tri.VIndex_2;

            tri.NIndex_0 = tri.VIndex_0;
            tri.NIndex_1 = tri.VIndex_1;
            tri.NIndex_2 = tri.VIndex_2;

            return tri;
        }

        private List<Triangle> Get_Triangles_from_Quad(string[] parameters)
        {
            List<Triangle> triangles = new List<Triangle>();

            triangles.Capacity = 2;

            Triangle tri_first = new Triangle();

            tri_first.VIndex_0 = int.Parse(parameters[1]) - 1;
            tri_first.VIndex_1 = int.Parse(parameters[4]) - 1;
            tri_first.VIndex_2 = int.Parse(parameters[7]) - 1;

            tri_first.TIndex_0 = int.Parse(parameters[2]) - 1;
            tri_first.TIndex_1 = int.Parse(parameters[5]) - 1;
            tri_first.TIndex_2 = int.Parse(parameters[8]) - 1;

            tri_first.NIndex_0 = int.Parse(parameters[3]) - 1;
            tri_first.NIndex_1 = int.Parse(parameters[6]) - 1;
            tri_first.NIndex_2 = int.Parse(parameters[9]) - 1;

            triangles.Add(tri_first);

            Triangle tri_snd = new Triangle();

            tri_snd.VIndex_0 = int.Parse(parameters[7]) - 1;
            tri_snd.VIndex_1 = int.Parse(parameters[10]) - 1;
            tri_snd.VIndex_2 = int.Parse(parameters[1]) - 1;

            tri_snd.TIndex_0 = int.Parse(parameters[8]) - 1;
            tri_snd.TIndex_1 = int.Parse(parameters[11]) - 1;
            tri_snd.TIndex_2 = int.Parse(parameters[2]) - 1;

            tri_snd.NIndex_0 = int.Parse(parameters[9]) - 1;
            tri_snd.NIndex_1 = int.Parse(parameters[12]) - 1;
            tri_snd.NIndex_2 = int.Parse(parameters[3]) - 1;

            triangles.Add(tri_snd);

            return triangles;
        }

        #endregion

        #region IDisposable Member

        public override void Dispose()
        {
            base.Dispose();
        }

        #endregion
    }
}

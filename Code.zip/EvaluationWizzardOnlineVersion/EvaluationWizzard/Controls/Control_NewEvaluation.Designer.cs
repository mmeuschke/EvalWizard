﻿namespace EvaluationWizzard
{
    partial class Control_NewEvaluation
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.GrpBx_Study_Parameters = new System.Windows.Forms.GroupBox();
            this.Btn_ChooseResultDirectory = new System.Windows.Forms.Button();
            this.TxtBx_ResultDirectory = new System.Windows.Forms.TextBox();
            this.Lbl_ResultsDirectory = new System.Windows.Forms.Label();
            this.Nmrc_UpDown_NumberTasks = new System.Windows.Forms.NumericUpDown();
            this.Lbl_NumTasks = new System.Windows.Forms.Label();
            this.GrpBx_DatasetSelection = new System.Windows.Forms.GroupBox();
            this.LstBx_ExistentDatasetPath = new System.Windows.Forms.ListBox();
            this.Btn_LoadDatasetExistent = new System.Windows.Forms.Button();
            this.Lbl_DataLocations = new System.Windows.Forms.Label();
            this.GrpBx_EvaluationSettings = new System.Windows.Forms.GroupBox();
            this.GrpBx_Shader_Selection = new System.Windows.Forms.GroupBox();
            this.Btn_Add_Shader = new System.Windows.Forms.Button();
            this.VScll_ShaderSelection = new System.Windows.Forms.VScrollBar();
            this.Btn_GenerateEvaluation = new System.Windows.Forms.Button();
            this.ReDrawTimer = new System.Windows.Forms.Timer(this.components);
            this.GrpBx_DataRendering = new System.Windows.Forms.GroupBox();
            this.PaintControl = new OpenTK.GLControl();
            this.GrpBx_Study_Parameters.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Nmrc_UpDown_NumberTasks)).BeginInit();
            this.GrpBx_DatasetSelection.SuspendLayout();
            this.GrpBx_EvaluationSettings.SuspendLayout();
            this.GrpBx_Shader_Selection.SuspendLayout();
            this.GrpBx_DataRendering.SuspendLayout();
            this.SuspendLayout();
            // 
            // GrpBx_Study_Parameters
            // 
            this.GrpBx_Study_Parameters.Controls.Add(this.Btn_ChooseResultDirectory);
            this.GrpBx_Study_Parameters.Controls.Add(this.TxtBx_ResultDirectory);
            this.GrpBx_Study_Parameters.Controls.Add(this.Lbl_ResultsDirectory);
            this.GrpBx_Study_Parameters.Controls.Add(this.Nmrc_UpDown_NumberTasks);
            this.GrpBx_Study_Parameters.Controls.Add(this.Lbl_NumTasks);
            this.GrpBx_Study_Parameters.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GrpBx_Study_Parameters.Location = new System.Drawing.Point(7, 27);
            this.GrpBx_Study_Parameters.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.GrpBx_Study_Parameters.Name = "GrpBx_Study_Parameters";
            this.GrpBx_Study_Parameters.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.GrpBx_Study_Parameters.Size = new System.Drawing.Size(453, 117);
            this.GrpBx_Study_Parameters.TabIndex = 0;
            this.GrpBx_Study_Parameters.TabStop = false;
            this.GrpBx_Study_Parameters.Text = "Evaluation Parameters";
            // 
            // Btn_ChooseResultDirectory
            // 
            this.Btn_ChooseResultDirectory.Location = new System.Drawing.Point(362, 84);
            this.Btn_ChooseResultDirectory.Name = "Btn_ChooseResultDirectory";
            this.Btn_ChooseResultDirectory.Size = new System.Drawing.Size(64, 24);
            this.Btn_ChooseResultDirectory.TabIndex = 22;
            this.Btn_ChooseResultDirectory.Text = "...";
            this.Btn_ChooseResultDirectory.UseVisualStyleBackColor = true;
            this.Btn_ChooseResultDirectory.Click += new System.EventHandler(this.Btn_ChooseResultDirectory_Click);
            // 
            // TxtBx_ResultDirectory
            // 
            this.TxtBx_ResultDirectory.Location = new System.Drawing.Point(33, 84);
            this.TxtBx_ResultDirectory.Name = "TxtBx_ResultDirectory";
            this.TxtBx_ResultDirectory.Size = new System.Drawing.Size(323, 24);
            this.TxtBx_ResultDirectory.TabIndex = 21;
            // 
            // Lbl_ResultsDirectory
            // 
            this.Lbl_ResultsDirectory.AutoSize = true;
            this.Lbl_ResultsDirectory.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_ResultsDirectory.Location = new System.Drawing.Point(31, 65);
            this.Lbl_ResultsDirectory.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Lbl_ResultsDirectory.Name = "Lbl_ResultsDirectory";
            this.Lbl_ResultsDirectory.Size = new System.Drawing.Size(106, 16);
            this.Lbl_ResultsDirectory.TabIndex = 20;
            this.Lbl_ResultsDirectory.Text = "Result Directory:";
            // 
            // Nmrc_UpDown_NumberTasks
            // 
            this.Nmrc_UpDown_NumberTasks.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nmrc_UpDown_NumberTasks.Location = new System.Drawing.Point(146, 26);
            this.Nmrc_UpDown_NumberTasks.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.Nmrc_UpDown_NumberTasks.Name = "Nmrc_UpDown_NumberTasks";
            this.Nmrc_UpDown_NumberTasks.Size = new System.Drawing.Size(120, 22);
            this.Nmrc_UpDown_NumberTasks.TabIndex = 19;
            this.Nmrc_UpDown_NumberTasks.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.Nmrc_UpDown_NumberTasks.ValueChanged += new System.EventHandler(this.Nmrc_UpDown_NumberTasks_ValueChanged);
            // 
            // Lbl_NumTasks
            // 
            this.Lbl_NumTasks.AutoSize = true;
            this.Lbl_NumTasks.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_NumTasks.Location = new System.Drawing.Point(31, 28);
            this.Lbl_NumTasks.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Lbl_NumTasks.Name = "Lbl_NumTasks";
            this.Lbl_NumTasks.Size = new System.Drawing.Size(108, 16);
            this.Lbl_NumTasks.TabIndex = 18;
            this.Lbl_NumTasks.Text = "Number of tasks:";
            // 
            // GrpBx_DatasetSelection
            // 
            this.GrpBx_DatasetSelection.Controls.Add(this.LstBx_ExistentDatasetPath);
            this.GrpBx_DatasetSelection.Controls.Add(this.Btn_LoadDatasetExistent);
            this.GrpBx_DatasetSelection.Controls.Add(this.Lbl_DataLocations);
            this.GrpBx_DatasetSelection.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GrpBx_DatasetSelection.Location = new System.Drawing.Point(7, 154);
            this.GrpBx_DatasetSelection.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.GrpBx_DatasetSelection.Name = "GrpBx_DatasetSelection";
            this.GrpBx_DatasetSelection.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.GrpBx_DatasetSelection.Size = new System.Drawing.Size(453, 195);
            this.GrpBx_DatasetSelection.TabIndex = 1;
            this.GrpBx_DatasetSelection.TabStop = false;
            this.GrpBx_DatasetSelection.Text = "Dataset Selection";
            // 
            // LstBx_ExistentDatasetPath
            // 
            this.LstBx_ExistentDatasetPath.FormattingEnabled = true;
            this.LstBx_ExistentDatasetPath.HorizontalScrollbar = true;
            this.LstBx_ExistentDatasetPath.ItemHeight = 18;
            this.LstBx_ExistentDatasetPath.Location = new System.Drawing.Point(33, 51);
            this.LstBx_ExistentDatasetPath.Name = "LstBx_ExistentDatasetPath";
            this.LstBx_ExistentDatasetPath.Size = new System.Drawing.Size(323, 130);
            this.LstBx_ExistentDatasetPath.TabIndex = 11;
            this.LstBx_ExistentDatasetPath.KeyDown += new System.Windows.Forms.KeyEventHandler(this.LstBx_ExistentDatasetPath_KeyDown);
            // 
            // Btn_LoadDatasetExistent
            // 
            this.Btn_LoadDatasetExistent.Location = new System.Drawing.Point(362, 104);
            this.Btn_LoadDatasetExistent.Name = "Btn_LoadDatasetExistent";
            this.Btn_LoadDatasetExistent.Size = new System.Drawing.Size(64, 24);
            this.Btn_LoadDatasetExistent.TabIndex = 10;
            this.Btn_LoadDatasetExistent.Text = "...";
            this.Btn_LoadDatasetExistent.UseVisualStyleBackColor = true;
            this.Btn_LoadDatasetExistent.Click += new System.EventHandler(this.Btn_LoadDatasetExistent_Click);
            // 
            // Lbl_DataLocations
            // 
            this.Lbl_DataLocations.AutoSize = true;
            this.Lbl_DataLocations.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_DataLocations.Location = new System.Drawing.Point(31, 32);
            this.Lbl_DataLocations.Name = "Lbl_DataLocations";
            this.Lbl_DataLocations.Size = new System.Drawing.Size(99, 16);
            this.Lbl_DataLocations.TabIndex = 9;
            this.Lbl_DataLocations.Text = "Locations(.obj):";
            // 
            // GrpBx_EvaluationSettings
            // 
            this.GrpBx_EvaluationSettings.Controls.Add(this.GrpBx_Shader_Selection);
            this.GrpBx_EvaluationSettings.Controls.Add(this.GrpBx_Study_Parameters);
            this.GrpBx_EvaluationSettings.Controls.Add(this.GrpBx_DatasetSelection);
            this.GrpBx_EvaluationSettings.Location = new System.Drawing.Point(3, 3);
            this.GrpBx_EvaluationSettings.Name = "GrpBx_EvaluationSettings";
            this.GrpBx_EvaluationSettings.Size = new System.Drawing.Size(467, 636);
            this.GrpBx_EvaluationSettings.TabIndex = 2;
            this.GrpBx_EvaluationSettings.TabStop = false;
            this.GrpBx_EvaluationSettings.Text = "Evaluation Setup";
            // 
            // GrpBx_Shader_Selection
            // 
            this.GrpBx_Shader_Selection.Controls.Add(this.Btn_Add_Shader);
            this.GrpBx_Shader_Selection.Controls.Add(this.VScll_ShaderSelection);
            this.GrpBx_Shader_Selection.Location = new System.Drawing.Point(7, 357);
            this.GrpBx_Shader_Selection.Name = "GrpBx_Shader_Selection";
            this.GrpBx_Shader_Selection.Size = new System.Drawing.Size(453, 270);
            this.GrpBx_Shader_Selection.TabIndex = 2;
            this.GrpBx_Shader_Selection.TabStop = false;
            this.GrpBx_Shader_Selection.Text = "Shader Selection";
            // 
            // Btn_Add_Shader
            // 
            this.Btn_Add_Shader.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Btn_Add_Shader.Location = new System.Drawing.Point(362, 234);
            this.Btn_Add_Shader.Name = "Btn_Add_Shader";
            this.Btn_Add_Shader.Size = new System.Drawing.Size(64, 30);
            this.Btn_Add_Shader.TabIndex = 21;
            this.Btn_Add_Shader.Tag = "2";
            this.Btn_Add_Shader.Text = "Add";
            this.Btn_Add_Shader.UseVisualStyleBackColor = true;
            this.Btn_Add_Shader.Click += new System.EventHandler(this.Btn_Add_Shader_Click);
            // 
            // VScll_ShaderSelection
            // 
            this.VScll_ShaderSelection.Dock = System.Windows.Forms.DockStyle.Right;
            this.VScll_ShaderSelection.Location = new System.Drawing.Point(429, 22);
            this.VScll_ShaderSelection.Name = "VScll_ShaderSelection";
            this.VScll_ShaderSelection.Size = new System.Drawing.Size(21, 245);
            this.VScll_ShaderSelection.TabIndex = 0;
            // 
            // Btn_GenerateEvaluation
            // 
            this.Btn_GenerateEvaluation.Location = new System.Drawing.Point(300, 645);
            this.Btn_GenerateEvaluation.Name = "Btn_GenerateEvaluation";
            this.Btn_GenerateEvaluation.Size = new System.Drawing.Size(163, 36);
            this.Btn_GenerateEvaluation.TabIndex = 2;
            this.Btn_GenerateEvaluation.Text = "Generate Evaluation";
            this.Btn_GenerateEvaluation.UseVisualStyleBackColor = true;
            this.Btn_GenerateEvaluation.Click += new System.EventHandler(this.Btn_GenerateEvaluation_Click);
            // 
            // ReDrawTimer
            // 
            this.ReDrawTimer.Enabled = true;
            this.ReDrawTimer.Interval = 15;
            this.ReDrawTimer.Tick += new System.EventHandler(this.ReDrawTimer_Tick);
            // 
            // GrpBx_DataRendering
            // 
            this.GrpBx_DataRendering.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GrpBx_DataRendering.Controls.Add(this.PaintControl);
            this.GrpBx_DataRendering.Location = new System.Drawing.Point(476, 3);
            this.GrpBx_DataRendering.Name = "GrpBx_DataRendering";
            this.GrpBx_DataRendering.Size = new System.Drawing.Size(659, 678);
            this.GrpBx_DataRendering.TabIndex = 3;
            this.GrpBx_DataRendering.TabStop = false;
            this.GrpBx_DataRendering.Text = "Visualization";
            // 
            // PaintControl
            // 
            this.PaintControl.BackColor = System.Drawing.Color.Silver;
            this.PaintControl.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.PaintControl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PaintControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PaintControl.Location = new System.Drawing.Point(3, 22);
            this.PaintControl.Margin = new System.Windows.Forms.Padding(6, 8, 6, 8);
            this.PaintControl.Name = "PaintControl";
            this.PaintControl.Size = new System.Drawing.Size(653, 653);
            this.PaintControl.TabIndex = 1;
            this.PaintControl.VSync = false;
            this.PaintControl.Load += new System.EventHandler(this.PaintControl_Load);
            this.PaintControl.Paint += new System.Windows.Forms.PaintEventHandler(this.PaintControl_Paint);
            this.PaintControl.KeyDown += new System.Windows.Forms.KeyEventHandler(this.PaintControl_KeyDown);
            this.PaintControl.MouseMove += new System.Windows.Forms.MouseEventHandler(this.PaintControl_MouseMove);
            this.PaintControl.Resize += new System.EventHandler(this.PaintControl_Resize);
            // 
            // Control_NewEvaluation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.Btn_GenerateEvaluation);
            this.Controls.Add(this.GrpBx_DataRendering);
            this.Controls.Add(this.GrpBx_EvaluationSettings);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Control_NewEvaluation";
            this.Size = new System.Drawing.Size(1138, 690);
            this.Load += new System.EventHandler(this.Control_NewEvaluation_Load);
            this.GrpBx_Study_Parameters.ResumeLayout(false);
            this.GrpBx_Study_Parameters.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Nmrc_UpDown_NumberTasks)).EndInit();
            this.GrpBx_DatasetSelection.ResumeLayout(false);
            this.GrpBx_DatasetSelection.PerformLayout();
            this.GrpBx_EvaluationSettings.ResumeLayout(false);
            this.GrpBx_Shader_Selection.ResumeLayout(false);
            this.GrpBx_DataRendering.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox GrpBx_Study_Parameters;
        private System.Windows.Forms.GroupBox GrpBx_DatasetSelection;
        private System.Windows.Forms.NumericUpDown Nmrc_UpDown_NumberTasks;
        private System.Windows.Forms.Label Lbl_NumTasks;
        private System.Windows.Forms.Label Lbl_DataLocations;
        private System.Windows.Forms.Button Btn_LoadDatasetExistent;
        private System.Windows.Forms.GroupBox GrpBx_EvaluationSettings;
        private System.Windows.Forms.Button Btn_ChooseResultDirectory;
        private System.Windows.Forms.TextBox TxtBx_ResultDirectory;
        private System.Windows.Forms.Label Lbl_ResultsDirectory;
        private System.Windows.Forms.Button Btn_GenerateEvaluation;
        private System.Windows.Forms.Timer ReDrawTimer;
        private System.Windows.Forms.GroupBox GrpBx_Shader_Selection;
        private System.Windows.Forms.VScrollBar VScll_ShaderSelection;
        private System.Windows.Forms.Button Btn_Add_Shader;
        private System.Windows.Forms.ListBox LstBx_ExistentDatasetPath;
        private System.Windows.Forms.GroupBox GrpBx_DataRendering;
        public OpenTK.GLControl PaintControl;
    }
}

﻿namespace EvaluationWizzard
{
    partial class Control_LoadEvaluation
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Grp_Bx_Statistical_Results = new System.Windows.Forms.GroupBox();
            this.Pct_Bx_Time = new System.Windows.Forms.PictureBox();
            this.Pct_Bx_Confidence = new System.Windows.Forms.PictureBox();
            this.Pct_Bx_Correctness = new System.Windows.Forms.PictureBox();
            this.Grp_Bx_MetaData = new System.Windows.Forms.GroupBox();
            this.Txt_bx_MetaData = new System.Windows.Forms.TextBox();
            this.Grp_Bx_Statistical_Results.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Pct_Bx_Time)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pct_Bx_Confidence)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pct_Bx_Correctness)).BeginInit();
            this.Grp_Bx_MetaData.SuspendLayout();
            this.SuspendLayout();
            // 
            // Grp_Bx_Statistical_Results
            // 
            this.Grp_Bx_Statistical_Results.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Grp_Bx_Statistical_Results.Controls.Add(this.Pct_Bx_Time);
            this.Grp_Bx_Statistical_Results.Controls.Add(this.Pct_Bx_Confidence);
            this.Grp_Bx_Statistical_Results.Controls.Add(this.Pct_Bx_Correctness);
            this.Grp_Bx_Statistical_Results.Location = new System.Drawing.Point(4, 254);
            this.Grp_Bx_Statistical_Results.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Grp_Bx_Statistical_Results.Name = "Grp_Bx_Statistical_Results";
            this.Grp_Bx_Statistical_Results.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Grp_Bx_Statistical_Results.Size = new System.Drawing.Size(1130, 431);
            this.Grp_Bx_Statistical_Results.TabIndex = 1;
            this.Grp_Bx_Statistical_Results.TabStop = false;
            this.Grp_Bx_Statistical_Results.Text = "Statistical Results";
            // 
            // Pct_Bx_Time
            // 
            this.Pct_Bx_Time.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Pct_Bx_Time.Location = new System.Drawing.Point(758, 27);
            this.Pct_Bx_Time.Name = "Pct_Bx_Time";
            this.Pct_Bx_Time.Size = new System.Drawing.Size(365, 396);
            this.Pct_Bx_Time.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Pct_Bx_Time.TabIndex = 2;
            this.Pct_Bx_Time.TabStop = false;
            // 
            // Pct_Bx_Confidence
            // 
            this.Pct_Bx_Confidence.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Pct_Bx_Confidence.Location = new System.Drawing.Point(383, 27);
            this.Pct_Bx_Confidence.Name = "Pct_Bx_Confidence";
            this.Pct_Bx_Confidence.Size = new System.Drawing.Size(365, 396);
            this.Pct_Bx_Confidence.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Pct_Bx_Confidence.TabIndex = 1;
            this.Pct_Bx_Confidence.TabStop = false;
            // 
            // Pct_Bx_Correctness
            // 
            this.Pct_Bx_Correctness.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.Pct_Bx_Correctness.Location = new System.Drawing.Point(7, 27);
            this.Pct_Bx_Correctness.Name = "Pct_Bx_Correctness";
            this.Pct_Bx_Correctness.Size = new System.Drawing.Size(365, 396);
            this.Pct_Bx_Correctness.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Pct_Bx_Correctness.TabIndex = 0;
            this.Pct_Bx_Correctness.TabStop = false;
            // 
            // Grp_Bx_MetaData
            // 
            this.Grp_Bx_MetaData.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Grp_Bx_MetaData.Controls.Add(this.Txt_bx_MetaData);
            this.Grp_Bx_MetaData.Location = new System.Drawing.Point(4, 5);
            this.Grp_Bx_MetaData.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Grp_Bx_MetaData.Name = "Grp_Bx_MetaData";
            this.Grp_Bx_MetaData.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Grp_Bx_MetaData.Size = new System.Drawing.Size(1130, 239);
            this.Grp_Bx_MetaData.TabIndex = 0;
            this.Grp_Bx_MetaData.TabStop = false;
            this.Grp_Bx_MetaData.Text = "Evaluation Summary";
            // 
            // Txt_bx_MetaData
            // 
            this.Txt_bx_MetaData.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Txt_bx_MetaData.Location = new System.Drawing.Point(4, 24);
            this.Txt_bx_MetaData.Multiline = true;
            this.Txt_bx_MetaData.Name = "Txt_bx_MetaData";
            this.Txt_bx_MetaData.Size = new System.Drawing.Size(1122, 210);
            this.Txt_bx_MetaData.TabIndex = 0;
            // 
            // Control_LoadEvaluation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.Grp_Bx_Statistical_Results);
            this.Controls.Add(this.Grp_Bx_MetaData);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Control_LoadEvaluation";
            this.Size = new System.Drawing.Size(1138, 690);
            this.Load += new System.EventHandler(this.Control_LoadEvaluation_Load);
            this.Resize += new System.EventHandler(this.Control_LoadEvaluation_Resize);
            this.Grp_Bx_Statistical_Results.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Pct_Bx_Time)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pct_Bx_Confidence)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pct_Bx_Correctness)).EndInit();
            this.Grp_Bx_MetaData.ResumeLayout(false);
            this.Grp_Bx_MetaData.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox Grp_Bx_Statistical_Results;
        private System.Windows.Forms.GroupBox Grp_Bx_MetaData;
        private System.Windows.Forms.PictureBox Pct_Bx_Time;
        private System.Windows.Forms.PictureBox Pct_Bx_Confidence;
        private System.Windows.Forms.PictureBox Pct_Bx_Correctness;
        private System.Windows.Forms.TextBox Txt_bx_MetaData;



    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OpenTK;
using OpenTK.Graphics.OpenGL;
using System.IO;
using System.Text.RegularExpressions;
using System.Xml;
using EvaluationWizzard.Properties;
using MathWorks.MATLAB.NET.Arrays;
using VesselTree;
using System.Drawing.Imaging;


namespace EvaluationWizzard
{
    public partial class Control_NewEvaluation : UserControl
    {
        #region - Private Variables -

        // camera
        private Camera cam_mesh;
        private float zooming;

        // evaluation parameters
        private int numTasks;
        private string pathToEvaluation;
        private string pathToTasks;
        private string pathToResults;
        private bool study_parameters_correct;

        // dataset parameters
        private List<string> pathes_to_vesseltrees;
        private List<string> pathes_to_indexlists;

        // shader handling
        private List<ShaderInfo> existent_shader_techniques;
        private List<ShaderInfo> selected_shader_techniques;

        private int act_shader;

        // evaluation object
        private Optimal_Viewpoints eval_object;

        private bool loaded;

        // Rendering of calculated images
        private bool render_images;

        private Matrix4 render_ModelView;
        private Matrix4 render_Projection;

        private Bitmap image_plus;
        private Bitmap image_lozenge;

        #endregion

        #region - Constructors -

        public Control_NewEvaluation()
        {
            this.InitializeComponent();

            this.pathes_to_vesseltrees = new List<string>();

            this.pathes_to_indexlists = new List<string>();

            this.cam_mesh = new Camera(Utility.ConvertToPolarCoord(new Vector3(0, 0, 200)), Vector3.Zero, Vector3.UnitY, -10.1f, 1000.0f);

            this.zooming = -0.16f;

            this.Read_Landmark_Images();

            this.numTasks = (int)this.Nmrc_UpDown_NumberTasks.Value;
            this.pathToEvaluation = "";
            this.pathToTasks = "";
            this.pathToResults = "";
            this.study_parameters_correct = false;

            this.existent_shader_techniques = new List<ShaderInfo>();

            this.selected_shader_techniques = new List<ShaderInfo>();

            this.act_shader = 0; // first comparitive technique

            this.loaded = false;

            this.render_images = false;

            this.render_ModelView = Matrix4.LookAt(this.cam_mesh.EyePos_Kart, this.cam_mesh.Center, this.cam_mesh.Up_Vector);
            this.render_Projection = Matrix4.CreateOrthographic((0.006f - this.zooming) * (float)this.PaintControl.ClientSize.Width, (0.006f - this.zooming) * (float)this.PaintControl.ClientSize.Height, this.cam_mesh.Near_Plane, this.cam_mesh.Far_Plane);
        }

        #endregion

        #region - Properties -

        public bool Render_Images
        {
            get { return this.render_images; }
            set { this.render_images = value; }
        }

        public Matrix4 Render_MV
        {
            get { return this.render_ModelView; }
            set { this.render_ModelView = value; }
        }

        public Matrix4 Render_PR
        {
            get { return this.render_Projection; }
            set { this.render_Projection = value; }
        }

        public int Act_Shader
        {
            get { return this.act_shader; }
            set { this.act_shader = value; }
        }

        #endregion

        #region - Methods -

        #region - Initialization -

        private void Control_NewEvaluation_Load(object sender, EventArgs e)
        {
            this.Read_Existent_Shader();

            this.Init_Shader_Selection();
        }

        private void Init_Shader_Selection()
        {
            for (int i = 0; i < this.existent_shader_techniques.Count; i++)
            {
                CheckBox new_shader = new CheckBox();

                new_shader.Text = this.existent_shader_techniques[i].Name;

                new_shader.Tag = this.existent_shader_techniques[i].Name;

                new_shader.Size = new System.Drawing.Size(new_shader.Text.Length * 30, new_shader.Height);

                new_shader.Location = new Point(7, (i*60) + 30);

                new_shader.CheckedChanged += new EventHandler(this.Chck_Bx_ShaderSeclection_CheckedChanged);

                this.GrpBx_Shader_Selection.Controls.Add(new_shader);

                if (this.existent_shader_techniques[i].Glyph_Shader_Files.Count > 0)
                {
                    CheckBox new_glyph_shader = new CheckBox();

                    new_glyph_shader.Text = "Glyphs";

                    new_glyph_shader.Tag = this.existent_shader_techniques[i].Name + "_Glyphs";

                    new_glyph_shader.Size = new System.Drawing.Size(new_glyph_shader.Text.Length * 30, new_glyph_shader.Height);

                    new_glyph_shader.ForeColor = Color.SteelBlue;

                    new_glyph_shader.Location = new Point(25, (i * 60) + 55);

                    new_glyph_shader.Enabled = false;

                    new_glyph_shader.CheckedChanged += new EventHandler(this.Chck_Bx_GlyphShaderSeclection_CheckedChanged);

                    this.GrpBx_Shader_Selection.Controls.Add(new_glyph_shader);
                }
            }
        }

        private void Read_Existent_Shader()
        {
            string path = Utility.Get_Relative_Project_Path();

            string xml_path = path + Settings.Default.InitXMLPath + "MeshShaders.xml";
            string shader_path = path + Settings.Default.InitShaderPath;

            if (File.Exists(xml_path))
            {
                XmlDocument doc = new XmlDocument();

                doc.Load(xml_path);

                XmlNode filesNode = doc.SelectSingleNode("/MeshShaders");

                if (filesNode.HasChildNodes)
                {
                    XmlNodeList shader = filesNode.ChildNodes;
                    XmlNodeList shader_files;

                    string name, type, file_path, file_name;

                    int contour;

                    for (int i = 0; i < shader.Count; i++)
                    {
                        name = shader[i].Attributes["Name"].Value;

                        ShaderInfo shader_tech = new ShaderInfo(name);

                        if (shader[i].HasChildNodes)
                        {
                            shader_files = shader[i].ChildNodes;

                            for (int j= 0; j < shader_files.Count; j++)
                            {
                                type = shader_files[j].Attributes["Name"].Value;
                                file_path = shader_files[j].Attributes["Path"].Value;

                                if (type == "Mesh")
                                {
                                    contour = Int32.Parse(shader_files[j].Attributes["Contour"].Value);

                                    if (contour > 0)
                                    {
                                        shader_tech.Render_Contour = true;
                                    }
                                    if (shader_files[j].HasChildNodes)
                                    {
                                        for (int k = 0; k < shader_files[j].ChildNodes.Count; k++)
                                        {
                                            file_name = file_path + shader_files[j].ChildNodes[k].Attributes["Name"].Value;

                                            shader_tech.Shader_Files.Add(file_name);
                                        }
                                    }
                                }
                                else if (type == "Glyph")
                                {
                                    if (shader_files[j].HasChildNodes)
                                    {
                                        for (int k = 0; k < shader_files[j].ChildNodes.Count; k++)
                                        {
                                            file_name = file_path + shader_files[j].ChildNodes[k].Attributes["Name"].Value;

                                            shader_tech.Glyph_Shader_Files.Add(file_name);
                                        }
                                    }
                                }
                            }
                        }

                        this.existent_shader_techniques.Add(shader_tech);
                    }
                }
            }
            else
            {
                MessageBox.Show("WARNING: no standard shader techniques existent", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        #endregion

        #region - Rendering -

        /// <summary>
        /// Initializes the rendering
        /// </summary>
        private void PaintControl_Load(object sender, EventArgs e)
        {
            GL.ClearColor(Color.White);
            GL.Enable(EnableCap.DepthTest);

            GL.BlendFunc(BlendingFactorSrc.SrcAlpha, BlendingFactorDest.OneMinusSrcAlpha);

            this.SetupViewport();

            this.Setup_Camera_Mesh();

            this.PaintControl.MouseWheel += new MouseEventHandler(this.PaintControl_MouseWheel);

            // GL is Ready
            this.loaded = true;
        }

        /// <summary>
        /// Setup viewport of render control
        /// </summary>
        private void SetupViewport()
        {
            int w = PaintControl.ClientSize.Width;
            int h = PaintControl.ClientSize.Height;

            GL.Viewport(0, 0, w, h); // Use all of the glControl painting area
        }

        /// <summary>
        /// Setup orthografic camera
        /// </summary>
        public void Setup_Camera_Mesh()
        {
            if (this.render_images)
            {
                GL.MatrixMode(MatrixMode.Projection);

                GL.LoadIdentity();

                GL.MultMatrix(ref this.render_Projection);

                GL.MatrixMode(MatrixMode.Modelview);

                GL.LoadIdentity();

                GL.MultMatrix(ref this.render_ModelView);
            }
            else
            {
                GL.MatrixMode(MatrixMode.Projection);

                GL.LoadIdentity();

                Matrix4 projection = Matrix4.CreateOrthographic((0.006f - this.zooming) * (float)this.PaintControl.ClientSize.Width, (0.006f - this.zooming) * (float)this.PaintControl.ClientSize.Height, this.cam_mesh.Near_Plane, this.cam_mesh.Far_Plane);

                GL.MultMatrix(ref projection);

                GL.MatrixMode(MatrixMode.Modelview);

                GL.LoadIdentity();

                Matrix4 modelview = Matrix4.LookAt(this.cam_mesh.EyePos_Kart, this.cam_mesh.Center, this.cam_mesh.Up_Vector);

                GL.MultMatrix(ref modelview);
            }
        }

        private void PaintControl_Resize(object sender, EventArgs e)
        {
            this.SetupViewport();
        }

        /// <summary>
        /// Render function
        /// </summary>
        private void PaintControl_Paint(object sender, PaintEventArgs e)
        {
            try
            {
                if (!this.loaded)
                {
                    return;
                }

                GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);

                this.Setup_Camera_Mesh();

                Vector3 viewDir = Utility.Look_At_Pos - this.cam_mesh.EyePos_Kart;

                viewDir.Normalize();

                float d = viewDir.X * this.cam_mesh.EyePos_Kart.X + viewDir.Y * this.cam_mesh.EyePos_Kart.Y + viewDir.Z * this.cam_mesh.EyePos_Kart.Z;

                this.ComputedepthNearFar(viewDir, d, out Utility.DepthNearFar);

                if (this.selected_shader_techniques.Count > 0)
                {
                    if (this.eval_object != null && this.eval_object.Act_Vessel_Tree != null)
                    {
                        if (!this.eval_object.Act_Vessel_Tree.Init_Setup || !this.eval_object.Act_Vessel_Tree.Init_Shader)
                        {
                            this.eval_object.Act_Vessel_Tree.Initialize_Render_Item(this.selected_shader_techniques[this.act_shader].Shader_Files);
                            this.eval_object.Act_Vessel_Tree.Render_Contour = this.selected_shader_techniques[this.act_shader].Render_Contour;
                        }

                        this.eval_object.Act_Vessel_Tree.Render();
                    }

                    if (this.eval_object != null && this.eval_object.Act_Vessel_Tree_Landmarks != null && this.selected_shader_techniques[this.act_shader].Use_Glyphs)
                    {
                        if (!this.eval_object.Act_Vessel_Tree_Landmarks.Init_Setup || !this.eval_object.Act_Vessel_Tree_Landmarks.Init_Shader)
                        {
                            this.eval_object.Act_Vessel_Tree_Landmarks.Initialize_Render_Item(this.selected_shader_techniques[this.act_shader].Glyph_Shader_Files);
                        }

                        this.eval_object.Act_Vessel_Tree_Landmarks.Render();
                    }
                }

                this.PaintControl.SwapBuffers();
            }
            catch (Exception)
            {
                Console.WriteLine("Exception Paint");

                throw;
            }
            

            //----FBOTest-------

            //if (!this.init_framebuffer)
            //{
            //    this.SetUp_Framebuffer();
            //}

            //GL.BindFramebuffer(FramebufferTarget.Framebuffer, this.FBOHandle);

            //GL.Viewport(0, 0, this.PaintControl.Width, this.PaintControl.Height);

            //GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);
            //GL.ClearColor(1.0f, 1.0f, 1.0f, 1.0f);

            //this.Setup_Camera_Mesh();

            //GL.Begin(PrimitiveType.Lines);
            //{
            //    GL.Color3(Color.DarkRed);
            //    GL.Vertex3(Vector3.Zero);
            //    GL.Vertex3(10 * Vector3.UnitX);

            //    GL.Color3(Color.Green);
            //    GL.Vertex3(Vector3.Zero);
            //    GL.Vertex3(10 * Vector3.UnitY);

            //    GL.Color3(Color.Blue);
            //    GL.Vertex3(Vector3.Zero);
            //    GL.Vertex3(10 * Vector3.UnitZ);
            //}
            //GL.End();

            //if (this.eval_object != null && this.eval_object.Vessel_Tree != null)
            //{
            //    if (!this.eval_object.Vessel_Tree.Init_Setup || !this.eval_object.Vessel_Tree.Init_Shader)
            //    {
            //        this.eval_object.Vessel_Tree.Initialize_Render_Item(this.own_shaders);
            //    }

            //    this.eval_object.Vessel_Tree.Render();
            //}

            //if (this.eval_object != null && this.eval_object.Vessel_Landmarks != null)
            //{
            //    if (!this.eval_object.Vessel_Landmarks.Init_Setup || !this.eval_object.Vessel_Landmarks.Init_Shader)
            //    {
            //        this.eval_object.Vessel_Landmarks.Initialize_Render_Item();
            //    }

            //    this.eval_object.Vessel_Landmarks.Render();
            //}

            //GL.BindFramebuffer(FramebufferTarget.Framebuffer, 0); // disable rendering into the FBO

            //GL.Viewport(0, 0, this.PaintControl.Width, this.PaintControl.Height);

            //GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);

            //GL.BindTexture(TextureTarget.Texture2D, this.DepthTexture);

            //this.Setup_Camera_Mesh();

            //int size = 10;

            //GL.Begin(PrimitiveType.Quads);
            //GL.TexCoord2(0.0, 0.0);
            //GL.Vertex3(-size, -size, 0.0);

            //GL.TexCoord2(0.0, 1.0);
            //GL.Vertex3(size, -size, 0.0);

            //GL.TexCoord2(1.0, 1.0);
            //GL.Vertex3(size, size, 0.0);

            //GL.TexCoord2(1.0, 0.0);
            //GL.Vertex3(-size, size, 0.0);

            //GL.End();

            //GL.BindTexture(TextureTarget.Texture2D, 0);


            //this.PaintControl.SwapBuffers();

        }

        /// <summary>
        /// Redraw of whole scene
        /// </summary>
        private void ReDrawTimer_Tick(object sender, EventArgs e)
        {
            this.PaintControl.Invalidate();
        }

        /// <summary>
        /// Generates and saves a screenshot of the current scene
        /// </summary>
        public void Take_Screenshot(string filename, ImageFormat format, Vector2 fst_label_pos, Vector2 snd_label_pos)
        {
            float[] px = new float[this.PaintControl.ClientSize.Width * this.PaintControl.ClientSize.Height * 4];

            Bitmap b_map = new Bitmap(this.PaintControl.ClientSize.Width, this.PaintControl.ClientSize.Height);
            GL.ReadPixels(0, 0, this.PaintControl.ClientSize.Width, this.PaintControl.ClientSize.Height, OpenTK.Graphics.OpenGL.PixelFormat.Rgba, PixelType.Float, px);

            int i = 0;
            int j = 0;

            int length = (px.Length / 4);

            int r = 0;
            int g = 0;
            int b = 0;
            int a = 0;

            for (int k = 0; k < length; k++)
            {
                j = k / this.PaintControl.ClientSize.Width;
                i = k % this.PaintControl.ClientSize.Width;

                j = (this.PaintControl.ClientSize.Height - 1) - j;

                r = (int)(px[k * 4] * 255);
                g = (int)(px[(k * 4) + 1] * 255);
                b = (int)(px[(k * 4) + 2] * 255);
                a = (int)(px[(k * 4) + 3] * 255);

                b_map.SetPixel(i, j, Color.FromArgb(a, r, g, b));
            }

            this.Draw_Landmark_Image(ref b_map, fst_label_pos, ref this.image_plus);
            this.Draw_Landmark_Image(ref b_map, snd_label_pos, ref this.image_lozenge);

            b_map.Save(filename, format);
        }

        private void Draw_Landmark_Image(ref Bitmap b_map_screenshot, Vector2 label_pos, ref Bitmap landmark_image)
        {
            int pixel_radius = landmark_image.Width / 2;

            int start_x = (int)label_pos.X - pixel_radius;
            int end_x = (int)label_pos.X + pixel_radius;

            int start_y = (int)label_pos.Y - pixel_radius;
            int end_y = (int)label_pos.Y + pixel_radius;

            if (start_x < 0)
            {
                start_x = 0;
            }
            if (start_y < 0)
            {
                start_y = 0;
            }

            if (end_x >= this.PaintControl.ClientSize.Width)
            {
                end_x = this.PaintControl.ClientSize.Width-1;
            }
            if (end_y >= this.PaintControl.ClientSize.Height)
            {
                end_y = this.PaintControl.ClientSize.Height-1;
            }

            int count_w = 0;
            int count_h = 0;

            int r = 0;
            int g = 0;
            int b = 0;
            int a = 0;

            int new_h = start_y;

            for (int h = start_y; h <= end_y; h++)
            {
                count_w = 0;

                for (int w = start_x; w <= end_x; w++)
                {
                    new_h = (this.PaintControl.ClientSize.Height - 1) - h;

                    r = (int)landmark_image.GetPixel(count_w, count_h).R;
                    g = (int)landmark_image.GetPixel(count_w, count_h).G;
                    b = (int)landmark_image.GetPixel(count_w, count_h).B;
                    a = (int)landmark_image.GetPixel(count_w, count_h).A;

                    if (!(r == 255) || !(g == 255) || !(b == 255))
                    {
                        b_map_screenshot.SetPixel(w, new_h, landmark_image.GetPixel(count_w, (landmark_image.Height - 1)-count_h));
                    }

                    if (count_w < (landmark_image.Width - 1))
                    {
                        count_w++;
                    }
                }

                if (count_h < (landmark_image.Height - 1))
                {
                    count_h++;
                }
            }
        }

        public void Read_Landmark_Images()
        {
            string path = Utility.Get_Relative_Project_Path() + Settings.Default.InitImagePath;

            this.image_plus = new Bitmap(path + "Plus.png");
            this.image_lozenge = new Bitmap(path + "Lozenge.png");
        }

        private void ComputedepthNearFar(Vector3 viewDir, float d, out Vector2 depthNearFar)
        {
            float depthNear = 0;
            float depthFar = 1;

            depthNearFar = new Vector2(depthNear, depthFar);

            if (this.eval_object == null)
            {
                return;
            }

            depthNear = viewDir.X * this.eval_object.Act_Vessel_Tree.Dimensions[0] + viewDir.Y * this.eval_object.Act_Vessel_Tree.Dimensions[2] + viewDir.Z * this.eval_object.Act_Vessel_Tree.Dimensions[4] - d;
	        
            depthFar = depthNear;

	        for (int i = 0; i < 2; i++)
	        {
	        	for (int j = 0; j < 2; j++)
	        	{
	        		for (int k = 0; k < 2; k++)
	        		{
                        float viewDirDotBB = viewDir[0] * this.eval_object.Act_Vessel_Tree.Dimensions[i] + viewDir[1] * this.eval_object.Act_Vessel_Tree.Dimensions[2 + j] + viewDir[2] * this.eval_object.Act_Vessel_Tree.Dimensions[4 + k] - d;

                        if (viewDirDotBB > depthFar)
                        {
                            depthFar = viewDirDotBB;
                        }

                        if (viewDirDotBB < depthNear)
                        {
                            depthNear = viewDirDotBB;
                        }
	        		}
	        	}
	        }

            depthNearFar = new Vector2(depthNear, depthFar);
        }

        #endregion

        #region - Events -

        #region - Mouse Control -

        /// <summary>
        /// 3D Camera Control via Mouse Interaction --> Zooming
        /// </summary>
        private void PaintControl_MouseWheel(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            this.zooming = this.zooming + e.Delta * 0.000001f;

            if (this.zooming < -1f)
            {
                this.zooming = -0.05f;
            }
            else if (this.zooming > 0.005f)
            {
                this.zooming = 0.005f;
            }
        }

        /// <summary>
        /// 3D Camera Control via Mouse Interaction --> Rotation
        /// </summary>
        private void PaintControl_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                this.cam_mesh.EyePos_Z = this.cam_mesh.EyePos.Z + (this.cam_mesh.OldMousePos.X - e.X) * 0.002f;

                if (this.cam_mesh.EyePos_Z > (2 * Math.PI))
                {
                    this.cam_mesh.EyePos_Z = 0;
                }
                if (this.cam_mesh.EyePos_Z < 0)
                {
                    this.cam_mesh.EyePos_Z = (float)(2 * Math.PI);
                }

                if (this.cam_mesh.EyePos.Y + (this.cam_mesh.OldMousePos.Y - e.Y) * 0.002f > 0 && this.cam_mesh.EyePos.Y + (this.cam_mesh.OldMousePos.Y - e.Y) * 0.002f < Math.PI)
                {
                    this.cam_mesh.EyePos_Y = this.cam_mesh.EyePos.Y + (this.cam_mesh.OldMousePos.Y - e.Y) * 0.002f;
                }

                this.cam_mesh.EyePos_Kart = Utility.ConvertToCartCoord(this.cam_mesh.EyePos);
            }
            else if (e.Button == MouseButtons.Left)
            {
                this.cam_mesh.Center_Y = this.cam_mesh.Center.Y + (this.cam_mesh.OldMousePos.Y - e.Y) * 0.008f;
            }

            this.cam_mesh.OldMousePos = new Vector3(e.X, e.Y, this.cam_mesh.OldMousePos.Z);
        }

        #endregion

        #region - Key Interaction -

        private void PaintControl_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F1)
            {
                this.Update_Shaders();
            }
        }

        private void LstBx_ExistentDatasetPath_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
            {
                this.Remove_Selected_Dataset();
            }
        }

        private void Update_Shaders()
        {
            if (this.eval_object.Act_Vessel_Tree != null)
            {
                this.eval_object.Act_Vessel_Tree.Update_Render_Item_Shaders(this.selected_shader_techniques[this.act_shader].Shader_Files);
            }

            if (this.eval_object.Act_Vessel_Tree_Landmarks != null && this.selected_shader_techniques[this.act_shader].Glyph_Shader_Files.Count > 0)
            {
                this.eval_object.Act_Vessel_Tree_Landmarks.Update_Render_Item_Shaders(this.selected_shader_techniques[this.act_shader].Glyph_Shader_Files);
            }
        }

        #endregion

        #region - Evaluation Parameters -

        private void Btn_ChooseResultDirectory_Click(object sender, EventArgs e)
        {
            this.study_parameters_correct = this.SetStorageLocation();

            this.TxtBx_ResultDirectory.Text = this.pathToEvaluation;
        }

        private void Nmrc_UpDown_NumberTasks_ValueChanged(object sender, EventArgs e)
        {
            this.numTasks = (int)this.Nmrc_UpDown_NumberTasks.Value;
        }

        private bool SetStorageLocation()
        {
            //select directory to store evaluation
            FolderBrowserDialog fbd = new FolderBrowserDialog();

            string res_dir = Utility.Get_Relative_Project_Path() + @"\Data\Studies";

            if (Directory.Exists(res_dir))
	        {
                fbd.SelectedPath = res_dir;
            }

            fbd.Description = "Choose a directory to store the evaluation.";

            DialogResult res = fbd.ShowDialog();

            if (res == DialogResult.OK)
            {
                this.pathToEvaluation = fbd.SelectedPath;

                //store screenshots
                this.pathToTasks = pathToEvaluation + @"\Images";

                if (!Directory.Exists(pathToTasks))
                {
                    DirectoryInfo dinf = Directory.CreateDirectory(pathToTasks); 
                }
                else
                {
                    MessageBox.Show(this, "Directory already exists. Please select a new destination.", "Error", MessageBoxButtons.OK);

                    this.SetStorageLocation();
                }

                //store ground truth for images
                this.pathToResults = pathToEvaluation + @"\Results";

                if (!Directory.Exists(pathToResults))
                {
                    DirectoryInfo dinf = Directory.CreateDirectory(this.pathToResults);
                }
                else
                {
                    MessageBox.Show(this, "Directory already exists. Please select a new destination.", "Error", MessageBoxButtons.OK);

                    this.SetStorageLocation();
                }
            }

            return true;
        }

        #endregion

        #region - Dataset Selection -

        private void Btn_LoadDatasetExistent_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog _fileDialog = new FolderBrowserDialog();

            string data_dir = Utility.Get_Relative_Project_Path() + @"\Data\Liver";

            if (Directory.Exists(data_dir))
            {
                _fileDialog.SelectedPath = data_dir;
            }

            DialogResult res = _fileDialog.ShowDialog();

            if (res == DialogResult.OK)
            {
                try
                {
                    this.Read_Data(_fileDialog.SelectedPath);
                    this.LstBx_ExistentDatasetPath.Items.Add(_fileDialog.SelectedPath);
                }
                catch (System.IO.FileNotFoundException)
                {
                    MessageBox.Show("WARNING: file does not exist", "ERROR: Loading Dataset", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
            if (res == DialogResult.Cancel)
            {
                return;
            }
        }

        private void Remove_Selected_Dataset()
        {
            if (this.LstBx_ExistentDatasetPath.SelectedIndices.Count > 0)
            {
                string message = "Do you really want to remove this dataset from selection?";
                string caption = "Delete Dataset";
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                DialogResult result;

                result = MessageBox.Show(message, caption, buttons);

                if (result == System.Windows.Forms.DialogResult.Yes)
                {
                    int index = this.LstBx_ExistentDatasetPath.SelectedIndex;

                    this.LstBx_ExistentDatasetPath.Items.RemoveAt(index);

                    this.pathes_to_vesseltrees.RemoveAt(index);
                    this.pathes_to_indexlists.RemoveAt(index);
                } 
            }
        }

        #endregion

        #region - Shader Selection -

        private void Btn_Add_Shader_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog _fileDialog = new FolderBrowserDialog();

            _fileDialog.SelectedPath = Utility.Get_Relative_Project_Path() + Settings.Default.InitShaderPath;

             DialogResult res = _fileDialog.ShowDialog();

             if (res == DialogResult.OK)
             {
                 try
                 {
                     string[] files = Directory.GetFiles(_fileDialog.SelectedPath);

                     string name = _fileDialog.SelectedPath.Substring(_fileDialog.SelectedPath.LastIndexOf('\\') + 1);

                     bool shader_exists = false;

                     for (int i = 0; i < this.existent_shader_techniques.Count; i++)
                     {
                         if (this.existent_shader_techniques[i].Name == name)
                         {
                             shader_exists = true;
                         }
                     }

                     if (!shader_exists)
                     {
                         ShaderInfo new_shader = new ShaderInfo(name);

                         new_shader.Shader_Files = files.ToList();

                         List<string> glyph_shader;

                         bool glyph_shader_selected = this.Select_Glyph_Shader(out glyph_shader);

                         new_shader.Glyph_Shader_Files = glyph_shader;

                         this.Add_Shader_to_Selection(name, this.existent_shader_techniques.Count, glyph_shader_selected);

                         this.Add_Selected_Shader_to_XML_File(new_shader);

                         this.existent_shader_techniques.Add(new_shader);
                     }
                     else
                     {
                         MessageBox.Show("Shader already exists in selection", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                     }
                     
                 }
                 catch (Exception)
                 {
                     MessageBox.Show("New shader cold not be loaded", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                 }
             }
        }

        private bool Select_Glyph_Shader(out List<string> glyph_shader)
        {
            string message = "Do you also want to load shader for glyphs?";
            string caption = "Glyph Shader Selection";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result;

            result = MessageBox.Show(message, caption, buttons);

            glyph_shader = new List<string>();

            if (result == System.Windows.Forms.DialogResult.Yes)
            {
                FolderBrowserDialog _fileDialog = new FolderBrowserDialog();

                _fileDialog.SelectedPath = Utility.Get_Relative_Project_Path() + Settings.Default.InitShaderPath;

                DialogResult res = _fileDialog.ShowDialog();

                if (res == DialogResult.OK)
                {
                    try
                    {
                        string[] files = Directory.GetFiles(_fileDialog.SelectedPath);

                        glyph_shader = files.ToList();

                        return true;
                    }
                    catch (Exception)
                    {
                        MessageBox.Show("Glyph shader cold not be loaded", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }

            return false;
        }

        private void Add_Selected_Shader_to_XML_File(ShaderInfo new_shader)
        {
            string path = Utility.Get_Relative_Project_Path();

            string xml_path = path + Settings.Default.InitXMLPath + "MeshShaders.xml";

            if (File.Exists(xml_path))
            {
                XmlDocument doc = new XmlDocument();

                doc.Load(xml_path);

                XmlNode rootnode = doc.SelectSingleNode("/MeshShaders");

                XmlNode shaderNode = doc.CreateElement("Shader");       // Shader technique
                XmlAttribute shadername = doc.CreateAttribute("Name");
                shadername.InnerText = new_shader.Name;
                shaderNode.Attributes.Append(shadername);
                rootnode.AppendChild(shaderNode);

                XmlNode meshtypeNode = doc.CreateElement("Type");       // Mesh shader files

                XmlAttribute meshtypename = doc.CreateAttribute("Name");
                meshtypename.InnerText = "Mesh";
                meshtypeNode.Attributes.Append(meshtypename);

                XmlAttribute meshcontname = doc.CreateAttribute("Contour");
                meshcontname.InnerText = "0";

                if (new_shader.Render_Contour)
                {
                    meshcontname.InnerText = "1";
                }
                meshtypeNode.Attributes.Append(meshcontname);

                XmlAttribute meshdirec = doc.CreateAttribute("Path");
                meshdirec.InnerText = "";

                if (new_shader.Shader_Files.Count > 0)
                {
                    meshdirec.InnerText = new_shader.Shader_Files[0].Substring(0, new_shader.Shader_Files[0].LastIndexOf('\\') + 1);
                }

                meshtypeNode.Attributes.Append(meshdirec);

                shaderNode.AppendChild(meshtypeNode);

                for (int i = 0; i < new_shader.Shader_Files.Count; i++) // Add individual mesh shaders 
                {
                    XmlNode fileNode = doc.CreateElement("File");
                    XmlAttribute filename = doc.CreateAttribute("Name");
                    filename.InnerText = new_shader.Shader_Files[i].Substring(new_shader.Shader_Files[i].LastIndexOf('\\') + 1);
                    fileNode.Attributes.Append(filename);
                    meshtypeNode.AppendChild(fileNode);
                }

                XmlNode glyphtypeNode = doc.CreateElement("Type");          // Glyph shader files

                XmlAttribute glyphtypename = doc.CreateAttribute("Name");
                glyphtypename.InnerText = "Glyph";
                glyphtypeNode.Attributes.Append(glyphtypename);
                shaderNode.AppendChild(glyphtypeNode);

                XmlAttribute glyphdirec = doc.CreateAttribute("Path");
                glyphdirec.InnerText = "";

                if (new_shader.Glyph_Shader_Files.Count > 0)
                {
                    glyphdirec.InnerText = new_shader.Glyph_Shader_Files[0].Substring(0, new_shader.Glyph_Shader_Files[0].LastIndexOf('\\') + 1);
                }
                
                glyphtypeNode.Attributes.Append(glyphdirec);

                for (int i = 0; i < new_shader.Glyph_Shader_Files.Count; i++) // Add individual mesh shaders 
                {
                    XmlNode fileNode = doc.CreateElement("File");
                    XmlAttribute filename = doc.CreateAttribute("Name");
                    filename.InnerText = new_shader.Glyph_Shader_Files[i].Substring(new_shader.Glyph_Shader_Files[i].LastIndexOf('\\') + 1);
                    fileNode.Attributes.Append(filename);
                    glyphtypeNode.AppendChild(fileNode);
                }

                doc.Save(xml_path);
            }
        }

        private void Add_Shader_to_Selection(string name, int shader_count, bool use_shaders)
        {
            CheckBox new_shader = new CheckBox();

            new_shader.Text = name;

            new_shader.Tag = name;

            new_shader.Size = new System.Drawing.Size(new_shader.Text.Length * 30, new_shader.Height);

            new_shader.Location = new Point(7, (shader_count * 60) + 30);

            new_shader.CheckedChanged += new EventHandler(this.Chck_Bx_ShaderSeclection_CheckedChanged);

            this.GrpBx_Shader_Selection.Controls.Add(new_shader);

            if (use_shaders)
            {
                CheckBox new_glyph_shader = new CheckBox();

                new_glyph_shader.Text = "Glyphs";

                new_glyph_shader.Tag = name + "_Glyphs";

                new_glyph_shader.Size = new System.Drawing.Size(new_glyph_shader.Text.Length * 30, new_glyph_shader.Height);

                new_glyph_shader.ForeColor = Color.SteelBlue;

                new_glyph_shader.Location = new Point(25, (shader_count * 60) + 55);

                new_glyph_shader.Enabled = false;

                new_glyph_shader.CheckedChanged += new EventHandler(this.Chck_Bx_GlyphShaderSeclection_CheckedChanged);

                this.GrpBx_Shader_Selection.Controls.Add(new_glyph_shader);
            }
        }

        private void Chck_Bx_ShaderSeclection_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                CheckBox act_chbx = (CheckBox)sender;

                string tag = act_chbx.Tag.ToString();

                if (act_chbx.Checked)
                {
                    int index = this.Get_Shader_Object_by_Name(tag, this.existent_shader_techniques);

                    if (index != -1)
                    {
                        ShaderInfo sel_shader = this.existent_shader_techniques[index];

                        bool existent = false;

                        for (int i = 0; i < this.selected_shader_techniques.Count; i++)
                        {
                            if (this.selected_shader_techniques[i].Name == sel_shader.Name)
                            {
                                existent = true;
                            }
                        }

                        if (!existent)
                        {
                            this.selected_shader_techniques.Add(sel_shader);
                        }

                        this.Activate_Glyph_Checkbox(tag + "_Glyphs");
                    }
                }
                else
                {
                    int index = this.Get_Shader_Object_by_Name(tag, this.selected_shader_techniques);

                    if (index != -1)
                    {
                        this.selected_shader_techniques.RemoveAt(index);

                        this.Deactivate_Glyph_Checkbox(tag + "_Glyphs");
                    }
                }
            }
            catch (Exception)
            {
            }
        }

        private int Get_Shader_Object_by_Name(string name, List<ShaderInfo> shaders)
        {
            int index = -1;

            if (shaders != null)
            {
                for (int i = 0; i < shaders.Count; i++)
                {
                    if (name == shaders[i].Name)
                    {
                        return i;
                    }
                }
            }

            return index;
        }

        private void Activate_Glyph_Checkbox(string name)
        {
            foreach (Control item in this.GrpBx_Shader_Selection.Controls)
            {
                if (item is CheckBox)
                {
                    if (item.Tag.ToString() == name)
                    {
                        ((CheckBox)item).Enabled = true;

                        ((CheckBox)item).Checked = true;
                    }
                }
            }
        }

        private void Deactivate_Glyph_Checkbox(string name)
        {
            foreach (Control item in this.GrpBx_Shader_Selection.Controls)
            {
                if (item is CheckBox)
                {
                    if (item.Tag.ToString() == name)
                    {
                        ((CheckBox)item).Enabled = false;

                        ((CheckBox)item).Checked = false;
                    }
                }
            }
        }

        private void Chck_Bx_GlyphShaderSeclection_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                 CheckBox act_chbx = (CheckBox)sender;

                 string tag = act_chbx.Tag.ToString();

                 string objectname = tag.Substring(0, tag.LastIndexOf('_'));

                 if (act_chbx.Checked)
                 {
                     int index = this.Get_Shader_Object_by_Name(objectname, this.existent_shader_techniques);

                     if (index != -1)
                     {
                         for (int i = 0; i < this.selected_shader_techniques.Count; i++)
                         {
                             if (this.selected_shader_techniques[i].Name == objectname)
                             {
                                 this.selected_shader_techniques[i].Use_Glyphs = true;
                             }
                         }
                     }
                 }
                 else
                 {
                     int index = this.Get_Shader_Object_by_Name(objectname, this.selected_shader_techniques);

                     if (index != -1)
                     {
                         this.selected_shader_techniques[index].Use_Glyphs = false;
                     }
                 }
            }
            catch (Exception)
            {
            }
        }

        #endregion

        #region - Generate Evaluation -

        private void Btn_GenerateEvaluation_Click(object sender, EventArgs e)
        {
            List<Mesh> vessel_objects;
            List<Landmarks> vessel_landmarks;

            if (!this.Check_StudyParameters())
            {
                return;
            }

            if (!this.Check_Data(out vessel_objects, out vessel_landmarks))
            {
                return;
            }

            if (!this.Check_Shader())
            {
                return;
            }

            this.eval_object = new Optimal_Viewpoints(vessel_objects, vessel_landmarks, this.numTasks, (this.image_plus.Width/2));

            this.eval_object.Parent_Control = this;

            this.eval_object.Determine_Study_images();

            this.Save_Images();
        }

        private bool Check_StudyParameters()
        {
            if (numTasks < 1)
            {
                MessageBox.Show("WARNING: number of tasks not selected", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);

                return false;
            }

            if (!this.study_parameters_correct)
            {
                MessageBox.Show("WARNING: no target directory selected", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);

                return false;
            }

            return true;
        }

        private bool Check_Data(out List<Mesh> vessel_objects, out List<Landmarks> vessel_landmarks)
        {
            vessel_objects = new List<Mesh>();

            vessel_landmarks = new List<Landmarks>();

            for (int i = 0; i < this.pathes_to_vesseltrees.Count; i++)
            {
                if (this.pathes_to_vesseltrees[i].Length > 2)
                {
                    vessel_objects.Add(this.Read_Data_Mesh(this.pathes_to_vesseltrees[i]));

                    if (this.pathes_to_indexlists[i].Length > 2)
                    {
                        vessel_landmarks.Add(this.Read_Landmarks(vessel_objects.Last(), this.pathes_to_indexlists[i]));
                    }
                    else
                    {
                        vessel_landmarks.Add(this.Calculate_Vessel_Endpoints(vessel_objects.Last()));
                    }
                }
            }
            

            if (vessel_objects.Count < 1)
            {
                MessageBox.Show("WARNING: no vessel object loaded", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);

                return false;
            }

            if (vessel_landmarks.Count < 1)
            {
                MessageBox.Show("WARNING: no vessel landmarks loaded", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);

                return false;
            }

            if (vessel_objects.Count != vessel_landmarks.Count)
            {
                MessageBox.Show("WARNING: vessel object or landmarks not correct loaded", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);

                return false;
            }

            return true;
        }

        private bool Check_Shader()
        {
            if (this.selected_shader_techniques.Count < 1)
            {
                MessageBox.Show("You have to select at least one shader", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);

                return false;
            }

            for (int i = 0; i < this.selected_shader_techniques.Count; i++)
            {
                if (!this.selected_shader_techniques[i].Check_Shader())
                {
                    MessageBox.Show("Shader: " + this.selected_shader_techniques[i].Name + "is not correct", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    return false;
                }
            }
            return true;
        }

        public void Get_Pixels_Depth(int pixel_xp1, int pixel_yp1, int pixel_xp2, int pixel_yp2, out float depth_p1_screen, out float depth_p2_screen)
        {
            float[] pixels = this.Get_Framebuffer_Content();

            if (pixel_xp1 < 0 || pixel_xp1 > this.PaintControl.ClientSize.Width || pixel_yp1 < 0 || pixel_yp1 > this.PaintControl.ClientSize.Height)
            {
                depth_p1_screen = -1;
            }
            else
            {
                int index_1 = ((pixel_yp1) * this.PaintControl.ClientSize.Width) + (pixel_xp1);

                depth_p1_screen = pixels[index_1];
            }

            if (pixel_xp2 < 0 || pixel_xp2 > this.PaintControl.ClientSize.Width || pixel_yp2 < 0 || pixel_yp2 > this.PaintControl.ClientSize.Height)
            {
                depth_p2_screen = -1;
            }
            else
            {
                int index_2 = ((pixel_yp2) * this.PaintControl.ClientSize.Width) + (pixel_xp2);

                depth_p2_screen = pixels[index_2];
            }
        }

        public float[] Get_Framebuffer_Content()
        {
            float[] pixels = new float[(this.PaintControl.ClientSize.Width + 1) * (this.PaintControl.ClientSize.Height + 1)];
            GL.ReadBuffer(ReadBufferMode.None);
            GL.ReadPixels(0, 0, this.PaintControl.ClientSize.Width, this.PaintControl.ClientSize.Height, OpenTK.Graphics.OpenGL.PixelFormat.DepthComponent, PixelType.Float, pixels);

            return pixels;
        }

        #endregion

        #endregion

        #region - Result Handling -

        private void Save_Images()
        {
            if (!Directory.Exists(this.pathToTasks))
            {
                DirectoryInfo dinf = Directory.CreateDirectory(this.pathToTasks);
            }

            if (!Directory.Exists(this.pathToResults))
            {
                DirectoryInfo dinf = Directory.CreateDirectory(this.pathToResults);
            }

            this.eval_object.Generate_Images(this.pathToTasks, this.pathToResults, this.selected_shader_techniques.Count);
        }

        #endregion

        #region - Read Data -

        private void Read_Data(string path)
        {
            string[] files = Directory.GetFiles(path);

            string mesh_path = "";
            string landmark_path = "";

            for (int i = 0; i < files.Length; i++)
            {
                if (files[i].EndsWith("obj"))
                {
                    mesh_path = files[i];
                }
                else if (files[i].EndsWith("txt"))
                {
                    landmark_path = files[i];
                }
            }

            this.pathes_to_vesseltrees.Add(mesh_path);
            this.pathes_to_indexlists.Add(landmark_path);
        }

        private Mesh Read_Data_Mesh(string act_path)
        {
            OBJReader reader = new OBJReader();

            reader.Load(act_path);

            return new Mesh(reader.Triangles, reader.Positions, reader.Normals);
        }

        private Landmarks Read_Landmarks(Mesh act_mesh, string act_path)
        {
            TXTReader reader = new TXTReader();

            reader.Load(act_path);

            List<int> endpoint_ids = reader.Indices;

            List<Vector3> endpoints, endnormals;

            this.Get_Endpoint_Positions(act_mesh, endpoint_ids, out endpoints, out endnormals);

            return new Landmarks(endpoints, endnormals);
        }

        public Landmarks Calculate_Vessel_Endpoints(Mesh act_mesh)
        {
            double[,] points = new double[3, act_mesh.Positions.Count];
            double[,] triangles = new double[3, act_mesh.Triangles.Count];

            for (int i = 0; i < act_mesh.Positions.Count; i++)
            {
                points.SetValue(act_mesh.Positions[i].X, 0, i);
                points.SetValue(act_mesh.Positions[i].Y, 1, i);
                points.SetValue(act_mesh.Positions[i].Z, 2, i);
            }

            //triangle indices have to start with 1, since matlab starts counting from 1
            for (int i = 0; i < act_mesh.Triangles.Count; i++)
            {
                triangles.SetValue(act_mesh.Triangles[i].VIndex_0 + 1, 0, i);
                triangles.SetValue(act_mesh.Triangles[i].VIndex_1 + 1, 1, i);
                triangles.SetValue(act_mesh.Triangles[i].VIndex_2 + 1, 2, i);
            }

            VesselTree.VesselEndpoints end_points = new VesselTree.VesselEndpoints();

            MWNumericArray endpoint_ids = (MWNumericArray)end_points.calculate_vessel_endpoints((MWNumericArray)points, (MWNumericArray)triangles);

            List<int> indices = new List<int>();

            double act_in = 0;
            int act_index = 0;

            for (int i = 1; i <= endpoint_ids.Dimensions[1]; i++)
            {
                act_in = (double)endpoint_ids[1, i];

                act_index = (int)act_in - 1;

                indices.Add(act_index);
            }

            List<Vector3> endpoints, endnormals;

            this.Get_Endpoint_Positions(act_mesh, indices, out endpoints, out endnormals);

            Landmarks new_mesh_landmarks = new Landmarks(endpoints, endnormals);

            int index = this.pathes_to_vesseltrees.Last().LastIndexOf('\\');

            string index_path = this.pathes_to_vesseltrees.Last().Substring(0, index);

            this.Export_Endpoint_Indices(indices, index_path);

            return new_mesh_landmarks;
        }

        /// <summary>
        /// Determines 3D position and normal of endpoints based on an index list containing endpoint indices
        /// </summary>
        private void Get_Endpoint_Positions(Mesh act_mesh, List<int> endpoint_ids, out List<Vector3> endpoints, out List<Vector3> endnormals)
        {
            endpoints = new List<Vector3>();
            endnormals = new List<Vector3>();

            if (act_mesh == null)
            {
                return;
            }

            if ((endpoint_ids.Count < 1) || (act_mesh.Positions.Count < 1) || (act_mesh.Normals.Count < 1))
            {
                Console.WriteLine("No end points existent");

                return;
            }

            int actid;

            for (int i = 0; i < endpoint_ids.Count; i++)
            {
                actid = endpoint_ids[i];

                endpoints.Add(act_mesh.Positions[actid]);
                endnormals.Add(act_mesh.Normals[actid]);
            }
        }

        #endregion

        #region - Export Data -

        private void Export_Endpoint_Indices(List<int> indices, string path)
        {
            string file_dir = path + @"\Endpoint_Indices.txt";

            file_dir.LastIndexOf('\\');

            string lineindex;

            using (StreamWriter sw = File.CreateText(file_dir))
            {
                for (int i = 0; i < indices.Count; i++)
                {
                    lineindex = indices[i].ToString();

                    sw.WriteLine(lineindex);
                }

                sw.Flush();

                sw.Close();
            }
        }

        public void Export_Images()
        {
            if (this.eval_object != null)
            {
                string pathImageInfo = this.pathToEvaluation + @"\ImageInfo";

                this.eval_object.Export_Image_Information(pathImageInfo);
            }
        }

        #endregion

        #endregion 
    }
}

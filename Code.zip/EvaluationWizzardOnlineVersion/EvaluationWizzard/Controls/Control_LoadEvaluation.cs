﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;

namespace EvaluationWizzard
{
    public partial class Control_LoadEvaluation : UserControl
    {
        #region - Private Variables -

        private string selected_study;

        #endregion

        #region - Constructors -

        public Control_LoadEvaluation()
        {
            this.InitializeComponent();
        }

        #endregion

        #region - Properties -

        #endregion

        #region - Methods -

        /// <summary>
        /// Initializes the analysis and depiction of the study results
        /// </summary>
        private void Control_LoadEvaluation_Load(object sender, EventArgs e)
        {
            FolderBrowserDialog _fileDialog = new FolderBrowserDialog();

            string data_path = Utility.Get_Relative_Project_Path() + @"\Data\Studies";

            if (Directory.Exists(data_path))
            {
                _fileDialog.SelectedPath = data_path;
            }

            DialogResult res = _fileDialog.ShowDialog();

            if (res == DialogResult.OK)
            {
                try
                {
                    this.selected_study = _fileDialog.SelectedPath;

                    this.Perform_Analysis();

                    this.Read_MetaData();

                    this.Read_Result_Images();
                }
                catch (System.IO.FileNotFoundException)
                {
                    MessageBox.Show("WARNING: file does not exist", "ERROR: Loading Dataset", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
            if (res == DialogResult.Cancel)
            {
                return;
            }
        }

        private void Control_LoadEvaluation_Resize(object sender, EventArgs e)
        {
            int w = Grp_Bx_Statistical_Results.Width;

            int wp = w / 3;

            this.Pct_Bx_Correctness.Width = wp;

            this.Pct_Bx_Confidence.Width = wp;
            this.Pct_Bx_Confidence.Location = new Point(this.Pct_Bx_Correctness.Location.X + 3 + wp, this.Pct_Bx_Confidence.Location.Y);

            this.Pct_Bx_Time.Width = wp;
            this.Pct_Bx_Time.Location = new Point(this.Pct_Bx_Confidence.Location.X + 3 + wp, this.Pct_Bx_Time.Location.Y);
        }

        private bool Perform_Analysis()
        {
            string act_folder = this.selected_study + @"\Results";

            if (Directory.Exists(act_folder))
            {
                string[] files = Directory.GetFiles(act_folder);

                for (int i = 0; i < files.Length; i++)
                {
                    if (files[i].EndsWith(".py"))
                    {
                        this.Run_Python_Analysis(files[i]);

                        return true;
                    }
                }
            }

            return false;
        }

        private void Run_Python_Analysis(string fileName)
        {
            Process p = new Process();

            string pythonpath = Utility.Get_Relative_Project_Path() + @"\Dependencies\python.exe";

            if (Directory.Exists(pythonpath))
            {
                p.StartInfo = new ProcessStartInfo(pythonpath, fileName)
                {
                    RedirectStandardInput = true,
                    UseShellExecute = false
                };

                p.Start();
                p.WaitForExit();
            }
        }

        private void Read_MetaData()
        {
            string act_folder = this.selected_study + @"\Results";

            if (Directory.Exists(act_folder))
            {
                string[] files = Directory.GetFiles(act_folder);

                for (int i = 0; i < files.Length; i++)
                {
                    if (files[i].EndsWith(".txt"))
                    {
                        this.Read_MetaData_from_File(files[i]);

                        return;
                    }
                }
            }
        }

        private void Read_MetaData_from_File(string fileName)
        {
            TXTReader reader = new TXTReader();

            reader.Load(fileName);

            List<string> meta_infos = reader.Meta_Info;

            for (int i = 0; i < meta_infos.Count; i++)
            {
                this.Txt_bx_MetaData.AppendText("\u2022 '" + meta_infos[i] + "\r\n" + "\r\n");
            }
        }

        private void Read_Result_Images()
        {
            string act_folder = this.selected_study + @"\Results";

            List<string> images = new List<string>();

            if (Directory.Exists(act_folder))
            {
                string[] files = Directory.GetFiles(act_folder);

                for (int i = 0; i < files.Length; i++)
                {
                    if (files[i].EndsWith(".png"))
                    {
                        images.Add(files[i]);
                    }
                }
            }

            if (images.Count ==3)
            {
                this.Set_Images(images);
            }
        }

        private void Set_Images(List<string> images_pathes)
        {
            Pct_Bx_Correctness.Image = Image.FromFile(images_pathes[0]);
            Pct_Bx_Confidence.Image = Image.FromFile(images_pathes[1]);
            Pct_Bx_Time.Image = Image.FromFile(images_pathes[2]);
        }

        #endregion 
    }
}

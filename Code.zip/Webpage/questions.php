<?php
session_start();
$files = glob("images/*.*");
if (!isset($_POST['curImage']))
{
    $GLOBALS['currentImage']=0;
    $results=array(
    $_POST['activity'],
    $_POST['experience'],
    $_POST['vision'],
    $_POST['age'],
    $_POST['gender']);

  
    $_SESSION['resultsSession']=$results;
} else {
    $GLOBALS['currentImage']=$_POST['curImage']+1;
    $results=$_SESSION['resultsSession'];
    
    $results[]=$_POST['option1'];
    $results[]=$_POST['option2'];
    $results[]=$_POST['time'];
    
    $_SESSION['resultsSession']=$results;  
}
?>


<!DOCTYPE html>
<html>
    <head>
    <link rel="stylesheet" href="style.css">
</head>
<body bgcolor=#FFFFFF onLoad="onLoad()">
    

<script type="text/javascript">
     
    
    var time1;
	var time2;

    function onLoad()
	{
    	time1 = new Date();
	}

	 function saveAndCheckForm()
    {
        if (document.getElementById('na').checked ||
		    document.getElementById('+').checked ||
			document.getElementById('#').checked) {
			time2 = new Date();
			document.getElementById('time').value = (time2 - time1)/1000;
        }
        checkForm()
    }

    function checkForm()
    {
        /*if (document.getElementById('na').checked) {
            document.getElementById('submitbutton').disabled = false;
            document.getElementById('Question2').style.display = "none";
        }
        else*/ 
			if (document.querySelectorAll('input[type="radio"]:checked').length == 2) {
            document.getElementById('submitbutton').disabled = false;
            document.getElementById('Question2').style.display = "table";
        }
        else {
		    document.getElementById('submitbutton').disabled = true;
            document.getElementById('Question2').style.display = "table";
        }
    }
</script>
  
<div align="center">
<?php 
$task=$GLOBALS['currentImage']+1;
echo '<h2><font face="VERDANA,ARIAL,HELVETICA"> Task '.$task.' / '.count($files).'</font></h2>'; 
?>
</div>
<div align="center">
<?php 
echo '<img src="'.$files[$currentImage].'" height=400" alt="Picture"></div>'."&nbsp;&nbsp;";
?>
<?php
if($GLOBALS['currentImage']+1<count($files))
{
    echo '<form action="questions.php" method="post">';
} else {
    echo '<form action="end.php" method="post">';
}
?>
<table id="Question1" align="center" width="750"> <th colspan='3'>
    <div align='left'><h3>Which vessel appears further away?</h3></div>
</th><tr> <td></td> <td></td> <td></td> </tr><tr>
    <td width='250'><label class="container2" h1 style="background-color:rgb(141,211,199);">1</h1><input type="radio" name="option1" id="1" value="1" onClick="saveAndCheckForm()"><span class="checkmark"></span></td>
    <td width='250'><label class="container2" h1 style="background-color:rgb(128,177,211);">2</h1><input type="radio" name="option1" id="2" value="2" onClick="saveAndCheckForm()"><span class="checkmark"></span></td>
    <td width='250'><label class="container2" h1 style="background-color:rgb(253,180,98);">3</h1><input type="radio" name="option1" id="3" value="3" onClick="saveAndCheckForm()"><span class="checkmark"></span></td>
    <tr> <td></td> <td></td> <td></td> </tr><tr> <td></td> <td></td> <td></td> </tr><tr> <td></td> <td></td> <td></td> </tr><tr> <td></td> <td></td> <td></td> </tr></tr></table>
    

<table id="Question2" align="center" width="750"> <th colspan='5'><div align='left'><h3>How certain are you?</h3></div></th><tr> <td></td> <td></td> <td></td> <td></td> <td></td> </tr><tr>
    <td width='150'><label class="container2">++ <input type="radio" name="option2" value="1" onClick="checkForm()"><span class="checkmark"></span> </td>
    <td width='150'><label class="container2">+ <input type="radio" name="option2" value="2" onClick="checkForm()"><span class="checkmark"></span> </td>
    <td width='150'><label class="container2">o <input type="radio" name="option2" value="3" onClick="checkForm()"><span class="checkmark"></span> </td>
    <td width='150'><label class="container2">- <input type="radio" name="option2" value="4" onClick="checkForm()"><span class="checkmark"></span> </td>
    <td width='150'><label class="container2">-- <input type="radio" name="option2" value="5" onClick="checkForm()"><span class="checkmark"></span> </td>
</tr></table>
<table align = "center" width="750"> 
<tr>
    <?php echo '<input type=\'hidden\' name=\'curImage\' value=\' '.$GLOBALS['currentImage'].'\' >'  ?>
    <input type='hidden' name='time' id='time' value='0'><th>
    <div align='left'><input id='submitbutton' type='submit' name='submit' value='Submit' disabled = "disabled"> </form></div></th> </tr></table>

</body>
</html>
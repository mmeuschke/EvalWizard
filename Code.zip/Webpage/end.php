<?php
session_start();

if (isset($_POST['comments']))
{
    $results=$_SESSION['resultsSession'];
    $results[]=$_POST['comments'];
        $file = fopen("results.csv", "a") or die("Unable to open file!");
        fputcsv($file,$results);
        fclose($file);
}
else
{
    $results=$_SESSION['resultsSession'];
    
    $results[]=$_POST['option1'];
    $results[]=$_POST['option2'];
    $results[]=$_POST['time'];
    
    $_SESSION['resultsSession']=$results;
}
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <link rel="stylesheet" href="style.css">
        <title>End</title>
    </head>
    <body bgcolor=#FFFFFF>
        <h1>Thank you for your contribution to our research!</h1>

<?php 
if (!isset($_POST['comments']))
{
 echo '<div class="container">
  <form action="end.php" method="post"> 

      <label for="comments">Comments</label>
      <textarea id="comments" name="comments" placeholder="Write something.." style="height:200px"></textarea>
        <input type="submit" value="Submit">
  </form>
</div>';}
?>
    </body>
</html>

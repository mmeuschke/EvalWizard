<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
          <link rel="stylesheet" href="style.css">
        <title></title>
    </head>
    <body bgcolor=#FFFFFF>
        
<h3>Contact Form</h3>
<script language="JavaScript">

function check()
{
	if (document.contact.activity.value=="not specified")
	{
		alert("Please, enter an activity!");
		return(false);
	}
	if (document.contact.experience.value=="not specified")
	{
		alert("Please, enter your experience!");
		return(false);
	}

	if (document.contact.vision.value=="not specified")
	{
		alert("Please, enter if you have a color vision problem!");
		return(false);
	}

    if (document.contact.age.value<6 || document.contact.age.value>99)
	{
		alert("Please, enter your age!");
		return(false);
	}

    if (document.contact.gender.value=="not specified")
	{
		alert("Please, enter your gender!");
		return(false);
	}
    	
   
	return true;
}
</script>
    <div class="container">
    <form name="contact" action="questions.php" method="post" onSubmit="return check();">
  
    <label for="activity">Select a background that best suits you</label>
    <select id="activity" name="activity">
        <option value="not specified">Select..</option>
        <option value="Computer Science">Computer Science</option>
        <option value="Mathematics" >Mathematics</option>
        <option value="Science" >Science (Physics, Chemistry, Biology,...)</option>
        <option value="Engineering" >Engineering</option>
        <option value="Design or Art">Design or Art</option>
        <option value="Medicine (Radiology)" >Medicine (Radiology)</option>
        <option value="Medicine (Surgery)" >Medicine (Surgery)</option>
        <option value="Medicine (other)" >Medicine (other)</option>
        <option value="Humanities" >Humanities </option>
        <option value="Economics" >Economics</option>
        <option value="Law" >Law</option>
        <option value="Other" >Other</option>
    </select>    <label for="experience">Experience</label>
    <select id="experience" name="experience">
        <option value="not specified">Select..</option>
        <option value="yes">I have experience with the visualization of vessels</option>
        <option value="no" >I have no experience with the visualization of vessels</option>
    </select>    <label for="vision">Are you aware of having a color vision problem?</label>
    <select id="vision" name="vision">
        <option value="not specified">Select..</option>
        <option value="no">I have no color vision problems</option>
        <option value="yes" >I have color vision problems</option>
    </select>    <label for="age">Age</label>
    <input type="text" id="age" name="age" placeholder="Your age..">    <label for="gender">Gender</label>
    <select id="gender" name="gender">
        <option value="not specified">Select..</option>
        <option value="male">Male</option>
        <option value="female" >Female</option>
    </select>
      
    <input type="submit" value="Submit">
  </form>
</div>
</body>
</html>
